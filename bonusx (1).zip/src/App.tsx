import React, { useState, useEffect } from 'react';
import { api, getSessionToken, setSessionToken } from './lib/api';
import { User, Notification } from './types';

// Import All Modular Panels
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import AuthPage from './components/AuthPage';

// User space panels
import DashboardUser from './components/DashboardUser';
import MissionsUser from './components/MissionsUser';
import MyBonusUser from './components/MyBonusUser';
import LeaderboardUser from './components/LeaderboardUser';
import ReferralUser from './components/ReferralUser';
import SettingsUser from './components/SettingsUser';

// Admin space panels
import DashboardAdmin from './components/DashboardAdmin';
import UsersAdmin from './components/UsersAdmin';
import SubmissionsAdmin from './components/SubmissionsAdmin';
import MissionsAdmin from './components/MissionsAdmin';
import RewardsAdmin from './components/RewardsAdmin';
import WithdrawalsAdmin from './components/WithdrawalsAdmin';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  
  // Navigation
  const [activeMenu, setActiveMenu] = useState('home');
  const [isAdminView, setIsAdminView] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const fetchSession = async () => {
    const token = getSessionToken();
    if (!token) {
      setLoading(false);
      return;
    }

    try {
      const data = await api.me();
      setUser(data.user);
      
      // If admin, default to admin-dashboard
      if (data.user.isAdmin) {
        setIsAdminView(true);
        setActiveMenu('admin-dashboard');
      } else {
        setIsAdminView(false);
        setActiveMenu('home');
      }

      await refreshNotifications();
    } catch (err) {
      console.error('Session invalide ou expirée.', err);
      setSessionToken(null);
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const refreshNotifications = async () => {
    try {
      const data = await api.getNotifications();
      setNotifications(data.notifications);
    } catch (err) {
      console.error('Impossible de charger les notifications.', err);
    }
  };

  useEffect(() => {
    fetchSession();
  }, []);

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
    if (loggedInUser.isAdmin) {
      setIsAdminView(true);
      setActiveMenu('admin-dashboard');
    } else {
      setIsAdminView(false);
      setActiveMenu('home');
    }
    refreshNotifications();
  };

  const handleLogout = () => {
    setSessionToken(null);
    setUser(null);
    setIsAdminView(false);
    setActiveMenu('home');
    setNotifications([]);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center gap-4">
        <div className="w-10 h-10 border-4 border-brand-cyan/20 border-t-brand-cyan rounded-full animate-spin shadow-[0_0_15px_rgba(0,229,255,0.4)]" />
        <span className="text-xs text-gray-400 font-mono uppercase tracking-widest animate-pulse">Initialisation de BonusX...</span>
      </div>
    );
  }

  // Not logged in -> Show Authentication Portal
  if (!user) {
    return <AuthPage onLoginSuccess={handleLoginSuccess} />;
  }

  // Helper to render user or admin menus
  const renderActiveContent = () => {
    if (isAdminView) {
      switch (activeMenu) {
        case 'admin-dashboard':
          return <DashboardAdmin />;
        case 'admin-users':
          return <UsersAdmin />;
        case 'admin-submissions':
          return <SubmissionsAdmin />;
        case 'admin-missions':
          return <MissionsAdmin />;
        case 'admin-rewards':
          return <RewardsAdmin />;
        case 'admin-withdrawals':
          return <WithdrawalsAdmin />;
        case 'admin-transactions':
          return <DashboardAdmin />; // Statistics include the full audit ledger
        case 'admin-settings':
          return <SettingsUser user={user} onUserUpdate={setUser} />;
        default:
          return <DashboardAdmin />;
      }
    } else {
      switch (activeMenu) {
        case 'home':
          return (
            <DashboardUser 
              user={user} 
              onUserUpdate={setUser} 
              onTriggerNotificationRefresh={refreshNotifications} 
              onNavigate={setActiveMenu}
            />
          );
        case 'missions':
          return (
            <MissionsUser 
              user={user} 
              onTriggerNotificationRefresh={refreshNotifications} 
            />
          );
        case 'bonus':
          return (
            <MyBonusUser 
              user={user} 
              onUserUpdate={setUser} 
              onTriggerNotificationRefresh={refreshNotifications} 
            />
          );
        case 'leaderboard':
          return <LeaderboardUser />;
        case 'referrals':
          return <ReferralUser user={user} />;
        case 'settings':
          return <SettingsUser user={user} onUserUpdate={setUser} />;
        default:
          return (
            <DashboardUser 
              user={user} 
              onUserUpdate={setUser} 
              onTriggerNotificationRefresh={refreshNotifications} 
              onNavigate={setActiveMenu}
            />
          );
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 flex font-sans antialiased">
      
      {/* Navigation Drawer Sidebar */}
      <Sidebar 
        user={user}
        activeMenu={activeMenu}
        setActiveMenu={(menu) => {
          setActiveMenu(menu);
          setSidebarOpen(false); // Auto-close on mobile selection
        }}
        isAdminView={isAdminView}
        setIsAdminView={setIsAdminView}
        onLogout={handleLogout}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
      />

      {/* Main Core View Area */}
      <div className="flex-1 min-w-0 pl-0 md:pl-64 flex flex-col min-h-screen relative">
        
        {/* Neon top lights background decoration */}
        <div className="absolute top-0 right-1/4 w-1/3 h-[300px] bg-radial-cyan pointer-events-none" />

        {/* Global Header */}
        <Header 
          user={user}
          onUserUpdate={setUser}
          notifications={notifications}
          onNotificationsRead={refreshNotifications}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        />

        {/* Inner Panel Wrapper */}
        <main className="flex-1 p-4 md:p-8 pt-24 md:pt-28 pb-12 overflow-x-hidden max-w-7xl mx-auto w-full relative z-10">
          {renderActiveContent()}
        </main>

      </div>

    </div>
  );
}
