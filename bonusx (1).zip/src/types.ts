export interface User {
  id: string;
  email: string;
  username: string;
  xp: number;
  level: number;
  usdcBalance: number;
  walletAddress?: string;
  isBlocked: boolean;
  isAdmin: boolean;
  referralCode: string;
  referredBy?: string; // referralCode of referrer
  createdAt: string;
  lastGaugeClaimAt?: string;
  lastGaugeClaims?: { [currency: string]: string };
  lastSpinAt?: string;
  lastQuizAt?: string;
  lastPredictionAt?: string;
  predictionChoice?: 'UP' | 'DOWN';
  predictionBtcPrice?: number;
  predictionResult?: 'pending' | 'won' | 'lost';
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  rewardUsdc: number;
  rewardXp: number;
  category: 'social' | 'video' | 'quiz' | 'crypto' | 'other';
  actionUrl: string;
  isActive: boolean;
  createdAt: string;
}

export interface UserMission {
  id: string;
  userId: string;
  missionId: string;
  proofText: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  processedAt?: string;
  adminComment?: string;
}

export interface Withdrawal {
  id: string;
  userId: string;
  amountUsdc: number;
  walletAddress: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
  processedAt?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  amountUsdc: number;
  type: 'bonus_claim' | 'mission_reward' | 'withdrawal' | 'admin_adjustment' | 'referral_bonus';
  description: string;
  createdAt: string;
}

export interface LevelConfig {
  level: number;
  xpRequired: number;
  rewardUsdc: number;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  isRead: boolean;
  type: 'info' | 'success' | 'alert' | 'bonus_available';
  createdAt: string;
}

export interface ReferralStats {
  referralCode: string;
  referralsCount: number;
  totalEarnedUsdc: number;
  referredUsers: {
    username: string;
    level: number;
    joinedAt: string;
    earnedForReferrer: number;
  }[];
}

export interface LeaderboardUser {
  id: string;
  username: string;
  level: number;
  xp: number;
  usdcBalance: number;
}
