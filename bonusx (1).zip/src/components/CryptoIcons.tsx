import React from 'react';

interface IconProps {
  className?: string;
  size?: number;
}

export function BtcIcon({ className = '', size = 24 }: IconProps) {
  return (
    <svg
      viewBox="0 0 64 64"
      width={size}
      height={size}
      className={`shrink-0 ${className}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="32" cy="32" r="32" fill="#F7931A" />
      <path
        d="M19 15h11.5c4.7 0 7.8 2.2 7.8 6 0 2.8-1.7 4.7-4.2 5.4 3.2.6 5.4 2.8 5.4 6.2 0 4.6-3.8 6.9-9 6.9H19V15zm5.5 10.5h5.5c2 0 3.2-.8 3.2-2.3s-1.2-2.2-3.2-2.2h-5.5v4.5zm0 10.2h6.3c2.2 0 3.5-1 3.5-2.6 0-1.6-1.3-2.5-3.5-2.5h-6.3v5.1z"
        fill="white"
      />
      <path
        d="M27.5 10v5m4.5-5v5m-4.5 29v5m4.5-5v5"
        stroke="white"
        strokeWidth="3.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function UsdtIcon({ className = '', size = 24 }: IconProps) {
  return (
    <svg
      viewBox="0 0 64 64"
      width={size}
      height={size}
      className={`shrink-0 ${className}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="32" cy="32" r="32" fill="#26A17B" />
      {/* Tether T and ring icon */}
      <path
        d="M17 18h30v6H35v22h-6V24H17v-6z"
        fill="white"
      />
      <path
        d="M32 10c12.15 0 22 4.03 22 9s-9.85 9-22 9-22-4.03-22-9 9.85-9 22-9zm0 5c-9.39 0-17 2.24-17 5s7.61 5 17 5 17-2.24 17-5-7.61-5-17-5z"
        fill="white"
        opacity="0.85"
      />
    </svg>
  );
}

export function EthIcon({ className = '', size = 24 }: IconProps) {
  return (
    <svg
      viewBox="0 0 64 64"
      width={size}
      height={size}
      className={`shrink-0 ${className}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="32" cy="32" r="32" fill="#627EEA" />
      <g fill="white">
        <path d="M32 10l-12 20 12 7 12-7-12-20z" opacity="0.8" />
        <path d="M32 10l-12 20 12 7v-27z" />
        <path d="M32 39.5l-12-6 12-16 12 16-12 6z" opacity="0.6" />
        <path d="M32 40.5l-12-6 12 16 12-16-12 6z" opacity="0.8" />
        <path d="M32 40.5v16l12-16-12 6z" />
      </g>
    </svg>
  );
}

export function SolIcon({ className = '', size = 24 }: IconProps) {
  return (
    <svg
      viewBox="0 0 64 64"
      width={size}
      height={size}
      className={`shrink-0 ${className}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="32" cy="32" r="32" fill="#14F195" />
      <g fill="black">
        {/* Solana logo layers */}
        <path d="M44 18H20l-4 4h24l4-4zM24 28h24l4-4H28l-4 4zM44 38H20l-4 4h24l4-4z" fill="#000" />
      </g>
    </svg>
  );
}
