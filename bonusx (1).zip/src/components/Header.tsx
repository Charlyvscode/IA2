import React, { useState, useEffect } from 'react';
import { Bell, Wallet, Check, AlertCircle, Info, Gift, LogIn, Languages, Menu } from 'lucide-react';
import { User, Notification, LevelConfig } from '../types';
import { api } from '../lib/api';
import { useLanguage } from '../lib/LanguageContext';
import { BtcIcon, UsdtIcon } from './CryptoIcons';

interface HeaderProps {
  user: User;
  onUserUpdate: (updatedUser: User) => void;
  notifications: Notification[];
  onNotificationsRead: () => void;
  onToggleSidebar?: () => void;
}

export default function Header({
  user,
  onUserUpdate,
  notifications,
  onNotificationsRead,
  onToggleSidebar
}: HeaderProps) {
  const { language, setLanguage, t } = useLanguage();
  const [showNotifications, setShowNotifications] = useState(false);
  const [walletInput, setWalletInput] = useState('');
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [levelConfigs, setLevelConfigs] = useState<LevelConfig[]>([]);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    // Fetch level configs to calculate progress bar
    if (user.isAdmin) return;
    
    // Simple mock or API level configs
    setLevelConfigs([
      { level: 1, xpRequired: 0, rewardUsdc: 0 },
      { level: 2, xpRequired: 300, rewardUsdc: 2.0 },
      { level: 3, xpRequired: 800, rewardUsdc: 5.0 },
      { level: 4, xpRequired: 1500, rewardUsdc: 10.0 },
      { level: 5, xpRequired: 2500, rewardUsdc: 15.0 },
      { level: 6, xpRequired: 4000, rewardUsdc: 25.0 },
      { level: 7, xpRequired: 6000, rewardUsdc: 40.0 },
      { level: 8, xpRequired: 9000, rewardUsdc: 60.0 },
      { level: 9, xpRequired: 13000, rewardUsdc: 100.0 },
      { level: 10, xpRequired: 20000, rewardUsdc: 200.0 }
    ]);
  }, [user]);

  // Calculate XP Progress Bar percentages
  const currentLvlConfig = levelConfigs.find(c => c.level === user.level) || { level: 1, xpRequired: 0 };
  const nextLvlConfig = levelConfigs.find(c => c.level === user.level + 1) || null;
  
  let progressPercentage = 100;
  let xpRemaining = 0;
  
  if (nextLvlConfig) {
    const range = nextLvlConfig.xpRequired - currentLvlConfig.xpRequired;
    const progress = user.xp - currentLvlConfig.xpRequired;
    progressPercentage = Math.min(Math.max((progress / range) * 100, 0), 100);
    xpRemaining = nextLvlConfig.xpRequired - user.xp;
  }

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const handleConnectWallet = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    
    if (!walletInput.startsWith('0x') || walletInput.length !== 42) {
      setErrorMsg(t('header.wallet_invalid'));
      return;
    }

    try {
      const res = await api.updateWallet(walletInput);
      if (res.success) {
        onUserUpdate(res.user);
        setSuccessMsg(t('header.wallet_success'));
        setTimeout(() => {
          setShowWalletModal(false);
          setSuccessMsg('');
        }, 1500);
      }
    } catch (err: any) {
      setErrorMsg(err.message || t('common.error'));
    }
  };

  const handleDisconnectWallet = async () => {
    try {
      const res = await api.updateWallet('');
      if (res.success) {
        onUserUpdate(res.user);
        setWalletInput('');
        setSuccessMsg(t('header.wallet_disconnected_msg'));
        setTimeout(() => setSuccessMsg(''), 2000);
      }
    } catch (err: any) {
      setErrorMsg(t('common.error'));
    }
  };

  const handleMarkAsRead = async () => {
    try {
      await api.markNotificationsAsRead();
      onNotificationsRead();
      setShowNotifications(false);
    } catch (err) {
      console.error('Erreur notifications', err);
    }
  };

  return (
    <header className="h-20 bg-gray-950/40 backdrop-blur-md border-b border-gray-900 px-4 md:px-8 flex items-center justify-between fixed top-0 right-0 left-0 md:left-64 z-20">
      
      {/* Mobile hamburger toggle */}
      <button
        type="button"
        onClick={onToggleSidebar}
        className="md:hidden mr-2 p-2 rounded-xl bg-gray-900 border border-gray-800 text-gray-300 hover:text-white transition cursor-pointer"
      >
        <Menu size={18} />
      </button>

      {/* Search / XP Progress Bar (Desktop only) */}
      <div className="hidden md:flex flex-1 max-w-md">
        {!user.isAdmin ? (
          <div className="flex flex-col gap-1.5 w-full">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-gray-400">{t('common.level').toUpperCase()} <span className="text-brand-cyan font-bold">{user.level}</span></span>
              <span className="text-gray-500">
                {user.xp} XP / {nextLvlConfig ? `${nextLvlConfig.xpRequired} XP` : t('common.max')}
              </span>
            </div>
            <div className="w-full h-2 bg-gray-900 rounded-full overflow-hidden border border-gray-800">
              <div 
                className="h-full bg-gradient-to-r from-brand-blue to-brand-cyan shadow-[0_0_10px_rgba(0,229,255,0.5)] transition-all duration-500 rounded-full"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
            {nextLvlConfig && (
              <span className="text-[9px] text-gray-500 font-mono">
                {t('header.level_up_progress', { xp: xpRemaining, nextLevel: user.level + 1 })}
              </span>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <div className="py-1 px-3.5 rounded-lg bg-indigo-950/40 border border-indigo-500/30 text-xs font-mono text-indigo-400">
              {t('common.admin_panel')}
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons & Notifications */}
      <div className="flex items-center gap-2 md:gap-5 ml-auto md:ml-0">
        
        {/* Language Selection Toggle */}
        <div className="flex bg-gray-900/60 rounded-xl p-0.5 border border-gray-800/80 shadow-inner">
          <button
            onClick={() => setLanguage('fr')}
            className={`px-2 md:px-3 py-1 text-[10px] md:text-xs font-bold rounded-lg transition-all duration-150 ${
              language === 'fr'
                ? 'bg-gradient-to-r from-brand-blue to-brand-cyan text-gray-950 font-bold shadow-[0_0_12px_rgba(0,229,255,0.4)]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            FR
          </button>
          <button
            onClick={() => setLanguage('en')}
            className={`px-2 md:px-3 py-1 text-[10px] md:text-xs font-bold rounded-lg transition-all duration-150 ${
              language === 'en'
                ? 'bg-gradient-to-r from-brand-blue to-brand-cyan text-gray-950 font-bold shadow-[0_0_12px_rgba(0,229,255,0.4)]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            EN
          </button>
        </div>

        {/* Wallet Connection */}
        {!user.isAdmin && (
          <div>
            {user.walletAddress ? (
              <button
                onClick={() => {
                  setWalletInput(user.walletAddress || '');
                  setShowWalletModal(true);
                }}
                id="wallet-connected-indicator-btn"
                className="flex items-center gap-1.5 py-1.5 px-2 md:px-3 rounded-xl bg-brand-cyan/10 hover:bg-brand-cyan/20 border border-brand-cyan/30 text-[10px] md:text-xs text-brand-cyan font-mono transition duration-150 cursor-pointer"
              >
                <Wallet size={12} />
                <span className="hidden xs:inline">
                  {user.walletAddress.substring(0, 4)}...{user.walletAddress.slice(-3)}
                </span>
                <span className="xs:hidden">
                  Wallet
                </span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setWalletInput('');
                  setShowWalletModal(true);
                }}
                id="wallet-connect-btn"
                className="flex items-center gap-1.5 py-1.5 px-2.5 md:px-3.5 rounded-xl bg-gray-900 hover:bg-gray-800 border border-gray-800 text-[10px] md:text-xs text-white transition duration-150 cursor-pointer font-medium"
              >
                <Wallet size={12} className="text-gray-400" />
                <span className="hidden xs:inline">{t('common.connect_wallet')}</span>
                <span className="xs:hidden">Connect</span>
              </button>
            )}
          </div>
        )}

        {/* Notifications Bell */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            id="notifications-bell-btn"
            className="w-8 h-8 md:w-10 md:h-10 rounded-xl bg-gray-900 hover:bg-gray-800 border border-gray-800 flex items-center justify-center relative text-gray-300 hover:text-white transition cursor-pointer"
          >
            <Bell size={15} />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 md:w-5 md:h-5 bg-brand-cyan rounded-full text-[9px] md:text-[10px] font-bold text-gray-950 flex items-center justify-center animate-bounce border border-gray-950 shadow-[0_0_8px_rgba(0,229,255,0.6)]">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications Dropdown Panel */}
          {showNotifications && (
            <div className="absolute right-0 mt-3 w-80 glass-card rounded-2xl border border-gray-800 shadow-2xl p-4 z-40 max-h-[420px] overflow-y-auto">
              <div className="flex items-center justify-between pb-3 border-b border-gray-800/60 mb-2">
                <h4 className="font-display font-bold text-sm text-white">{t('header.notifications_title')}</h4>
                {unreadCount > 0 && (
                  <button
                    onClick={handleMarkAsRead}
                    id="mark-all-read-btn"
                    className="text-[11px] text-brand-cyan hover:underline cursor-pointer font-medium"
                  >
                    {t('header.mark_all_read')}
                  </button>
                )}
              </div>

              <div className="space-y-2 mt-2">
                {notifications.length === 0 ? (
                  <div className="text-center py-6 text-xs text-gray-500">
                    {t('header.no_notifications')}
                  </div>
                ) : (
                  [...notifications].reverse().map((notif) => {
                    const getIcon = () => {
                      switch (notif.type) {
                        case 'success':
                          return <Check className="text-green-400" size={14} />;
                        case 'alert':
                          return <AlertCircle className="text-red-400" size={14} />;
                        case 'bonus_available':
                          return <Gift className="text-brand-cyan" size={14} />;
                        default:
                          return <Info className="text-blue-400" size={14} />;
                      }
                    };

                    const getBg = () => {
                      if (!notif.isRead) return 'bg-white/5 border border-white/5';
                      return 'bg-transparent border border-transparent';
                    };

                    return (
                      <div 
                        key={notif.id} 
                        className={`p-2.5 rounded-xl transition ${getBg()} flex gap-2.5 items-start text-xs`}
                      >
                        <div className="mt-0.5 p-1 rounded-lg bg-gray-900 border border-gray-800">
                          {getIcon()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-white truncate">{notif.title}</p>
                          <p className="text-gray-400 text-[11px] leading-relaxed mt-0.5 break-words">{notif.message}</p>
                          <span className="text-[9px] text-gray-500 font-mono mt-1 block">
                            {new Date(notif.createdAt).toLocaleDateString(t('header.time_format'), {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Balance Header Panel (Quick Stats) */}
        {!user.isAdmin && (
          <div className="flex items-center gap-2">
            {/* USDT Balance */}
            <div className="h-10 px-3 bg-green-500/10 rounded-xl border border-green-500/20 flex items-center gap-2 shadow-[0_0_15px_rgba(38,161,123,0.05)]">
              <UsdtIcon size={14} />
              <span className="font-display font-black text-white text-xs tracking-tight">
                {user.usdcBalance.toFixed(2)} <span className="text-gray-400 font-mono font-normal">USDT</span>
              </span>
            </div>

            {/* BTC Balance */}
            <div className="h-10 px-3 bg-amber-500/10 rounded-xl border border-amber-500/20 flex items-center gap-2 shadow-[0_0_15px_rgba(247,147,26,0.05)]">
              <BtcIcon size={14} />
              <span className="font-display font-black text-white text-xs tracking-tight font-mono">
                {(user.usdcBalance / 65000).toFixed(6)} <span className="text-gray-400 font-sans font-normal">BTC</span>
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Wallet Connection Modal */}
      {showWalletModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md glass-card rounded-2xl border border-gray-800 p-6 shadow-2xl relative">
            <h3 className="font-display font-bold text-lg text-white mb-2 flex items-center gap-2">
              <Wallet className="text-brand-cyan" />
              <span>{user.walletAddress ? t('common.wallet_connected') : t('header.wallet_modal_title')}</span>
            </h3>
            <p className="text-xs text-gray-400 mb-6">
              {t('header.wallet_modal_desc')}
            </p>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-lg bg-red-950/30 border border-red-500/30 text-xs text-red-400 flex items-center gap-2">
                <AlertCircle size={14} />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="mb-4 p-3 rounded-lg bg-green-950/30 border border-green-500/30 text-xs text-green-400 flex items-center gap-2">
                <Check size={14} />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleConnectWallet} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                  Adresse Publique de Réception
                </label>
                <input
                  type="text"
                  placeholder={t('header.wallet_placeholder')}
                  value={walletInput}
                  onChange={(e) => setWalletInput(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white font-mono placeholder-gray-600 focus:outline-none focus:border-brand-cyan transition"
                  required
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowWalletModal(false)}
                  id="close-wallet-modal-btn"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-gray-900 hover:bg-gray-800 text-xs font-semibold text-white transition cursor-pointer"
                >
                  {t('common.close')}
                </button>
                {user.walletAddress ? (
                  <button
                    type="button"
                    onClick={handleDisconnectWallet}
                    id="disconnect-wallet-btn"
                    className="flex-1 py-2.5 px-4 rounded-xl bg-red-950/30 hover:bg-red-950/50 border border-red-900/40 text-xs font-semibold text-red-400 transition cursor-pointer"
                  >
                    {t('common.disconnect')}
                  </button>
                ) : (
                  <button
                    type="submit"
                    id="save-wallet-btn"
                    className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-brand-blue to-brand-cyan hover:brightness-110 text-xs font-semibold text-white transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    <LogIn size={14} />
                    <span>{t('common.save')}</span>
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      )}


    </header>
  );
}
