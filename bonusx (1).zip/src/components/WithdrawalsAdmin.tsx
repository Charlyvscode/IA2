import React, { useState, useEffect } from 'react';
import { Clock, Check, X, AlertCircle, Coins, Wallet, CheckCircle2 } from 'lucide-react';
import { Withdrawal } from '../types';
import { api } from '../lib/api';

export default function WithdrawalsAdmin() {
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);

  const fetchWithdrawals = async () => {
    try {
      const res = await api.getAdminWithdrawals();
      // Sort: pending first, then newest
      const sorted = res.withdrawals.sort((a: any, b: any) => {
        if (a.status === 'pending' && b.status !== 'pending') return -1;
        if (a.status !== 'pending' && b.status === 'pending') return 1;
        return new Date(b.requestedAt).getTime() - new Date(a.requestedAt).getTime();
      });
      setWithdrawals(sorted);
    } catch (err) {
      console.error('Erreur admin withdrawals fetch', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWithdrawals();
  }, []);

  const handleProcessWithdrawal = async (id: string, action: 'approve' | 'reject') => {
    const confirmation = window.confirm(`Voulez-vous vraiment ${action === 'approve' ? 'APPROUVER et payer' : 'REJETER'} cette demande de retrait ?`);
    if (!confirmation) return;

    setProcessingId(id);
    try {
      await api.processWithdrawal(id, action);
      fetchWithdrawals();
    } catch (err: any) {
      alert(err.message || 'Une erreur est survenue.');
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Title */}
      <div>
        <h2 className="font-display font-bold text-2xl text-white">Gestion des Retraits</h2>
        <p className="text-xs text-gray-400">Examinez les demandes de paiements USDC initiées par les utilisateurs. Validez pour envoyer ou déclinez pour recréditer leur solde.</p>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-3">
          <div className="w-8 h-8 border-2 border-brand-cyan/20 border-t-brand-cyan rounded-full animate-spin" />
          <span className="text-xs text-gray-500 font-mono uppercase tracking-widest">Calcul des retraits en suspens...</span>
        </div>
      ) : (
        <div className="glass-card rounded-2xl p-6 border border-gray-800/80 shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-gray-400">
              <thead>
                <tr className="border-b border-gray-900 text-[10px] uppercase font-mono tracking-wider text-gray-500">
                  <th className="py-3.5 px-4">Utilisateur</th>
                  <th className="py-3.5 px-4">Montant Retrait</th>
                  <th className="py-3.5 px-4">Portefeuille Polygon</th>
                  <th className="py-3.5 px-4">Date de Demande</th>
                  <th className="py-3.5 px-4">Statut</th>
                  <th className="py-3.5 px-4 text-center">Décision administrative</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-900/60">
                {withdrawals.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-12 text-gray-600 font-mono">
                      Aucun retrait enregistré dans la base.
                    </td>
                  </tr>
                ) : (
                  withdrawals.map((w) => (
                    <tr key={w.id} className={`hover:bg-white/2 transition ${w.status === 'pending' ? 'bg-yellow-500/2' : ''}`}>
                      
                      {/* User Info */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7.5 h-7.5 rounded-full bg-gray-950 border border-gray-800 flex items-center justify-center font-bold text-brand-cyan text-[10px]">
                            {w.user ? w.user.username.substring(0, 2).toUpperCase() : '??'}
                          </div>
                          <div>
                            <p className="font-semibold text-white truncate">{w.user ? w.user.username : 'Utilisateur Supprimé'}</p>
                            <p className="text-[10px] text-gray-500 font-mono">{w.user ? w.user.email : ''}</p>
                          </div>
                        </div>
                      </td>

                      {/* Amount USDC */}
                      <td className="py-3.5 px-4 font-mono font-bold text-red-400">
                        -{w.amountUsdc.toFixed(2)} USDC
                      </td>

                      {/* Polygon Address */}
                      <td className="py-3.5 px-4 font-mono text-[11px]">
                        <span className="text-gray-300 font-semibold">{w.walletAddress}</span>
                      </td>

                      {/* Date */}
                      <td className="py-3.5 px-4 font-mono text-[11px] text-gray-500">
                        {new Date(w.requestedAt).toLocaleString('fr-FR')}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        <span className={`py-1 px-2.5 rounded-lg text-[9px] font-bold uppercase tracking-wider ${
                          w.status === 'approved' ? 'bg-green-950/40 border border-green-500/20 text-green-400' :
                          w.status === 'rejected' ? 'bg-red-950/40 border border-red-500/20 text-red-400' :
                          'bg-yellow-950/40 border border-yellow-500/20 text-yellow-400 animate-pulse'
                        }`}>
                          {w.status === 'approved' ? 'Payé' :
                           w.status === 'rejected' ? 'Refusé' : 'En attente'}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center justify-center gap-2">
                          {w.status === 'pending' ? (
                            <>
                              {/* Approve Button */}
                              <button
                                onClick={() => handleProcessWithdrawal(w.id, 'approve')}
                                disabled={processingId !== null}
                                id={`approve-withdrawal-btn-${w.id}`}
                                className="py-1 px-3 rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold text-[11px] transition flex items-center gap-1 cursor-pointer disabled:opacity-40"
                              >
                                <Check size={12} />
                                <span>Payer</span>
                              </button>

                              {/* Reject Button */}
                              <button
                                onClick={() => handleProcessWithdrawal(w.id, 'reject')}
                                disabled={processingId !== null}
                                id={`reject-withdrawal-btn-${w.id}`}
                                className="py-1 px-3 rounded-lg bg-red-950/30 hover:bg-red-950/50 border border-red-900/40 text-red-400 font-bold text-[11px] transition flex items-center gap-1 cursor-pointer disabled:opacity-40"
                              >
                                <X size={12} />
                                <span>Rejeter</span>
                              </button>
                            </>
                          ) : (
                            <span className="text-gray-600 font-mono text-[10px]">
                              Traité le {new Date(w.processedAt || '').toLocaleDateString('fr-FR')}
                            </span>
                          )}
                        </div>
                      </td>

                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
}
