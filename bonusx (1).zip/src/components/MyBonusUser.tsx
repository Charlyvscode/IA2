import React, { useState, useEffect } from 'react';
import { 
  Coins, 
  ArrowUpRight, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Wallet,
  ArrowRight
} from 'lucide-react';
import { User, Transaction, Withdrawal } from '../types';
import { api } from '../lib/api';
import { useLanguage } from '../lib/LanguageContext';
import { BtcIcon, UsdtIcon } from './CryptoIcons';

interface MyBonusUserProps {
  user: User;
  onUserUpdate: (updatedUser: User) => void;
  onTriggerNotificationRefresh: () => void;
}

export default function MyBonusUser({
  user,
  onUserUpdate,
  onTriggerNotificationRefresh
}: MyBonusUserProps) {
  const { t, language } = useLanguage();
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawWallet, setWithdrawWallet] = useState(user.walletAddress || '');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [withdrawCurrency, setWithdrawCurrency] = useState<'USDT' | 'BTC'>('USDT');

  const fetchData = async () => {
    try {
      const txData = await api.getMyBonus();
      const withData = await api.getMyWithdrawals();
      setTransactions(txData.bonuses);
      setWithdrawals(withData.withdrawals);
    } catch (err) {
      console.error('Erreur my-bonus fetch', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user]);

  const handleRequestWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setSubmitting(true);

    const amount = Number(withdrawAmount);
    if (!amount || amount <= 0) {
      setErrorMsg(language === 'fr' ? 'Veuillez saisir un montant de retrait supérieur à 0.' : 'Please enter a withdrawal amount greater than 0.');
      setSubmitting(false);
      return;
    }

    if (amount > user.usdcBalance) {
      setErrorMsg(language === 'fr' ? 'Solde insuffisant pour réaliser ce retrait.' : 'Insufficient balance for this withdrawal.');
      setSubmitting(false);
      return;
    }

    if (withdrawCurrency === 'USDT') {
      const isValidUsdt = withdrawWallet.startsWith('0x') || withdrawWallet.startsWith('T') || withdrawWallet.length >= 34;
      if (!isValidUsdt) {
        setErrorMsg(language === 'fr' 
          ? 'Adresse de portefeuille USDT (TRC20, ERC20 ou Polygon) invalide.' 
          : 'Invalid USDT wallet address (TRC20, ERC20 or Polygon).');
        setSubmitting(false);
        return;
      }
    } else {
      const isValidBtc = withdrawWallet.startsWith('1') || withdrawWallet.startsWith('3') || withdrawWallet.startsWith('bc1') || withdrawWallet.length >= 26;
      if (!isValidBtc) {
        setErrorMsg(language === 'fr' 
          ? 'Adresse de portefeuille Bitcoin (Native, SegWit ou Legacy) invalide.' 
          : 'Invalid Bitcoin wallet address (Native, SegWit or Legacy).');
        setSubmitting(false);
        return;
      }
    }

    try {
      const res = await api.requestWithdrawal(amount, withdrawWallet);
      if (res.success) {
        setSuccessMsg(language === 'fr' 
          ? `Demande de retrait de ${amount.toFixed(2)} ${withdrawCurrency} initiée avec succès ! Les fonds sont gelés pour validation administrative.`
          : `Withdrawal request of ${amount.toFixed(2)} ${withdrawCurrency} initiated successfully! Funds are frozen for administrative validation.`
        );
        setWithdrawAmount('');
        onUserUpdate(res.user);
        onTriggerNotificationRefresh();
        fetchData();
      }
    } catch (err: any) {
      setErrorMsg(err.message || t('common.error'));
    } finally {
      setSubmitting(false);
    }
  };

  // Quick stats
  const totalEarnedUsdc = transactions
    .filter(tx => tx.amountUsdc > 0)
    .reduce((sum, tx) => sum + tx.amountUsdc, 0);

  const pendingWithdrawalsAmount = withdrawals
    .filter(w => w.status === 'pending')
    .reduce((sum, w) => sum + w.amountUsdc, 0);

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* Upper overview header */}
      <div>
        <h2 className="font-display font-bold text-2xl text-white">{t('bonus.title')}</h2>
        <p className="text-xs text-gray-400">{t('bonus.desc')}</p>
      </div>

      {/* Grid: Financial Stats Card & Withdrawal Portal */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        
        {/* Left Stats Cards & Logs (Covers 2 cols) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Cumulative earnings card */}
          <div className="bg-gray-950/40 backdrop-blur-md rounded-2xl p-6 border border-gray-900 bg-gradient-to-br from-gray-900/40 to-cyan-950/20 shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/5 rounded-full blur-2xl" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-gray-400 uppercase">{language === 'fr' ? 'Cumul des gains reçus' : 'Cumulative earnings'}</span>
              <Coins className="text-brand-cyan" size={18} />
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <UsdtIcon size={24} />
                <h3 className="font-display font-black text-2xl text-white">
                  {totalEarnedUsdc.toFixed(2)} <span className="text-green-400 text-xs font-mono font-bold">USDT</span>
                </h3>
              </div>
              <div className="flex items-center gap-2 pt-2 border-t border-gray-900/50">
                <BtcIcon size={20} />
                <span className="font-mono text-sm font-bold text-amber-500">
                  {(totalEarnedUsdc / 65000).toFixed(6)} <span className="text-xs text-gray-400 font-normal">BTC</span>
                </span>
              </div>
            </div>
            <p className="text-[10px] text-gray-500 mt-3">{language === 'fr' ? 'Cumul total de toutes vos actions rémunérées' : 'Total accumulated rewards across all paid activities'}</p>
          </div>

          {/* Pending locked withdrawals card */}
          <div className="bg-gray-950/40 backdrop-blur-md rounded-2xl p-6 border border-gray-900 bg-gradient-to-br from-gray-900/40 to-yellow-950/10 shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-yellow-500/5 rounded-full blur-2xl" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-yellow-500 uppercase">{language === 'fr' ? 'Montant gelé en retrait' : 'Pending withdrawal amount'}</span>
              <Clock className="text-yellow-500" size={18} />
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <UsdtIcon size={24} />
                <h3 className="font-display font-black text-2xl text-white">
                  {pendingWithdrawalsAmount.toFixed(2)} <span className="text-green-400 text-xs font-mono font-bold">USDT</span>
                </h3>
              </div>
              <div className="flex items-center gap-2 pt-2 border-t border-gray-900/50">
                <BtcIcon size={20} />
                <span className="font-mono text-sm font-bold text-amber-500">
                  {(pendingWithdrawalsAmount / 65000).toFixed(6)} <span className="text-xs text-gray-400 font-normal">BTC</span>
                </span>
              </div>
            </div>
            <p className="text-[10px] text-gray-500 mt-3">{language === 'fr' ? 'Fonds en cours de validation par l\'administration' : 'Funds undergoing verification by administrative panel'}</p>
          </div>

        </div>

        {/* Right: Withdrawal Portal (Covers 3 cols) */}
        <div className="lg:col-span-3 bg-gray-950/40 backdrop-blur-md rounded-3xl p-8 border border-gray-900 shadow-xl relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand-cyan/5 rounded-full blur-2xl pointer-events-none" />
          
          <div className="pb-4 mb-6 border-b border-gray-900 flex justify-between items-start gap-4">
            <div>
              <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
                <ArrowUpRight className="text-brand-cyan" size={18} />
                <span>{language === 'fr' ? 'Demander un retrait sécurisé' : 'Request secure withdrawal'}</span>
              </h3>
              <p className="text-xs text-gray-400 mt-1">
                {language === 'fr' ? 'Transférez vos gains de manière non-custodial vers votre adresse préférée.' : 'Transfer your earnings in a non-custodial way to your preferred address.'}
              </p>
            </div>
          </div>

          {/* Asset choice selector tabs */}
          <div className="mb-6">
            <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-2.5 font-mono">
              {language === 'fr' ? 'Actif de Retrait Sélectionné' : 'Selected Withdrawal Asset'}
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  setWithdrawCurrency('USDT');
                  setErrorMsg('');
                }}
                className={`flex items-center justify-center gap-2.5 p-3 rounded-xl border text-xs font-bold transition-all duration-300 ${
                  withdrawCurrency === 'USDT'
                    ? 'bg-green-500/10 border-green-500/40 text-white shadow-[0_0_12px_rgba(38,161,123,0.15)]'
                    : 'bg-gray-900/20 border-gray-800/80 text-gray-400 hover:text-white'
                }`}
              >
                <UsdtIcon size={18} />
                <span>USDT Tether</span>
              </button>
              
              <button
                type="button"
                onClick={() => {
                  setWithdrawCurrency('BTC');
                  setErrorMsg('');
                }}
                className={`flex items-center justify-center gap-2.5 p-3 rounded-xl border text-xs font-bold transition-all duration-300 ${
                  withdrawCurrency === 'BTC'
                    ? 'bg-amber-500/10 border-amber-500/40 text-white shadow-[0_0_12px_rgba(247,147,26,0.15)]'
                    : 'bg-gray-900/20 border-gray-800/80 text-gray-400 hover:text-white'
                }`}
              >
                <BtcIcon size={18} />
                <span>BTC Bitcoin</span>
              </button>
            </div>
          </div>

          {/* Error / Success feedback */}
          {errorMsg && (
            <div className="mb-6 p-4 rounded-xl bg-red-950/20 border border-red-500/30 text-xs text-red-400 flex items-center gap-2 animate-pulse">
              <AlertCircle size={16} className="shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-6 p-4 rounded-xl bg-green-950/20 border border-green-500/30 text-xs text-green-400 flex items-center gap-2">
              <CheckCircle2 size={16} className="shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleRequestWithdrawal} className="space-y-4">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Withdraw Amount Input */}
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                  {language === 'fr' ? 'Montant à retirer' : 'Amount to cashout'}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-xl pl-4 pr-24 py-3 text-sm text-white font-mono placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition"
                    required
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-1 font-bold text-brand-cyan text-xs font-mono">
                    {withdrawCurrency === 'USDT' ? <UsdtIcon size={14} /> : <BtcIcon size={14} />}
                    <span>{withdrawCurrency}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center mt-1.5 px-1 text-[10px] text-gray-500 font-mono">
                  <span>
                    {language === 'fr' ? 'Disponible' : 'Available'} : {user.usdcBalance.toFixed(2)} USDT 
                    {withdrawCurrency === 'BTC' && ` (~${(user.usdcBalance / 65000).toFixed(6)} BTC)`}
                  </span>
                  <button 
                    type="button" 
                    onClick={() => setWithdrawAmount(user.usdcBalance.toString())}
                    className="text-brand-cyan hover:underline cursor-pointer font-bold"
                  >
                    Max
                  </button>
                </div>
              </div>

              {/* Withdraw Wallet Address Input */}
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                  {withdrawCurrency === 'USDT' 
                    ? (language === 'fr' ? 'Adresse de réception USDT' : 'USDT Receiving Address')
                    : (language === 'fr' ? 'Adresse de réception Bitcoin' : 'Bitcoin Receiving Address')
                  }
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder={withdrawCurrency === 'USDT' ? "0x... ou T..." : "1... ou bc1..."}
                    value={withdrawWallet}
                    onChange={(e) => setWithdrawWallet(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-3 text-xs text-white font-mono placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition"
                    required
                  />
                </div>
                <span className="text-[9px] text-gray-500 font-mono mt-1 px-1 block">
                  {withdrawCurrency === 'USDT' 
                    ? (language === 'fr' ? 'Réseaux supportés : TRC20, ERC20, Polygon' : 'Supported networks: TRC20, ERC20, Polygon')
                    : (language === 'fr' ? 'Réseaux supportés : Bitcoin Mainnet Native / SegWit' : 'Supported networks: Bitcoin Mainnet Native / SegWit')
                  }
                </span>
              </div>

            </div>

            <div className="pt-4">
              <button
                type="submit"
                disabled={submitting}
                id="request-withdrawal-btn"
                className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-brand-blue to-brand-cyan hover:brightness-110 text-gray-950 font-extrabold text-xs transition duration-200 cursor-pointer flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,229,255,0.15)] disabled:opacity-50"
              >
                {submitting ? (
                  <span className="w-4 h-4 border-2 border-gray-950/30 border-t-gray-950 rounded-full animate-spin" />
                ) : (
                  <>
                    <span>{language === 'fr' ? `Confirmer le Retrait en ${withdrawCurrency}` : `Confirm Cashout in ${withdrawCurrency}`}</span>
                    <ArrowRight size={14} />
                  </>
                )}
              </button>
            </div>

          </form>

          <div className="mt-6 p-4 rounded-xl bg-gray-950/40 border border-gray-900 text-[10px] text-gray-400 font-mono space-y-1">
            <p className="text-white font-semibold mb-1">⚠️ {language === 'fr' ? 'Informations Importantes sur les Payouts :' : 'Important Payout Information :'}</p>
            <p>{language === 'fr' ? '• Les retraits en USDT et BTC sont validés sans frais supplémentaires.' : '• Withdrawals in USDT and BTC are cleared without extra network fees.'}</p>
            <p>{language === 'fr' ? "• Temps d'exécution : validation manuelle administrative sous 1 à 12 heures." : '• Processing time: manual administrative validation in 1 to 12 hours.'}</p>
            <p>{language === 'fr' ? "• Les requêtes frauduleuses ou d'utilisateurs suspectés de multi-comptes seront déclinées." : '• Fraudulent requests or users suspected of multi-accounts will be declined.'}</p>
          </div>

        </div>

      </div>

      {/* History Table Grid: Left Transactions Ledger, Right Withdrawals List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Left Side: Ledger of Income */}
        <div className="bg-gray-950/40 border border-gray-900 rounded-2xl p-6 shadow-lg">
          <div className="pb-3 border-b border-gray-900 mb-4">
            <h4 className="font-display font-bold text-base text-white">{language === 'fr' ? 'Historique de Gains' : 'Earnings History'}</h4>
            <p className="text-xs text-gray-500">{language === 'fr' ? 'Missions validées, claims et parrainage' : 'Approved missions, claims, and referrals'}</p>
          </div>

          <div className="overflow-y-auto max-h-[300px]">
            {loading ? (
              <div className="text-center py-8 text-gray-600 font-mono text-xs">{t('common.loading')}</div>
            ) : transactions.length === 0 ? (
              <div className="text-center py-12 text-gray-600 font-mono text-xs">{language === 'fr' ? 'Aucun gain enregistré.' : 'No recorded earnings.'}</div>
            ) : (
              <div className="space-y-3 pr-1">
                {transactions.map(tx => (
                  <div key={tx.id} className="p-3 bg-gray-900/30 rounded-xl border border-gray-900 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-semibold text-white">{tx.description}</p>
                      <span className="text-[10px] text-gray-500 font-mono block">
                        {new Date(tx.createdAt).toLocaleDateString(t('header.time_format'), {
                          hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short'
                        })}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-green-400">+{tx.amountUsdc.toFixed(2)} USDT</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Ledger of Withdrawals */}
        <div className="bg-gray-950/40 border border-gray-900 rounded-2xl p-6 shadow-lg">
          <div className="pb-3 border-b border-gray-900 mb-4">
            <h4 className="font-display font-bold text-base text-white">{language === 'fr' ? 'Demandes de Retraits' : 'Withdrawal Requests'}</h4>
            <p className="text-xs text-gray-500 font-normal">{language === 'fr' ? 'Suivi de tes requêtes de payouts' : 'Tracking of your payouts requests'}</p>
          </div>

          <div className="overflow-y-auto max-h-[300px]">
            {loading ? (
              <div className="text-center py-8 text-gray-600 font-mono text-xs">{t('common.loading')}</div>
            ) : withdrawals.length === 0 ? (
              <div className="text-center py-12 text-gray-600 font-mono text-xs">{language === 'fr' ? 'Aucun retrait pour le moment.' : 'No withdrawals yet.'}</div>
            ) : (
              <div className="space-y-3 pr-1">
                {withdrawals.map(w => (
                  <div key={w.id} className="p-3 bg-gray-900/30 rounded-xl border border-gray-900 flex items-center justify-between text-xs">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] text-gray-400">ID: {w.id}</span>
                        <span className={`text-[9px] py-0.5 px-2 rounded-md font-bold uppercase ${
                          w.status === 'approved' ? 'bg-green-950/40 border border-green-500/20 text-green-400' :
                          w.status === 'rejected' ? 'bg-red-950/40 border border-red-500/20 text-red-400' :
                          'bg-yellow-950/40 border border-yellow-500/20 text-yellow-400'
                        }`}>
                          {w.status === 'approved' ? t('common.status_approved') : w.status === 'rejected' ? t('common.status_rejected') : t('common.status_pending')}
                        </span>
                      </div>
                      <p className="font-mono text-[10px] text-gray-500 truncate max-w-[200px]">Vers: {w.walletAddress}</p>
                      <span className="text-[9px] text-gray-500 font-mono block">
                        {new Date(w.requestedAt).toLocaleDateString(t('header.time_format'), {
                          hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short'
                        })}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-red-400">-{w.amountUsdc.toFixed(2)} USDT</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
