import React from 'react';
import { 
  Home, 
  Award, 
  Coins, 
  Trophy, 
  Users, 
  Settings, 
  LogOut, 
  ShieldAlert, 
  Activity, 
  ArrowDownCircle, 
  PlusSquare, 
  Star,
  UserCheck,
  X
} from 'lucide-react';
import { User } from '../types';
import { useLanguage } from '../lib/LanguageContext';

interface SidebarProps {
  user: User;
  activeMenu: string;
  setActiveMenu: (menu: string) => void;
  isAdminView: boolean;
  setIsAdminView: (isAdmin: boolean) => void;
  onLogout: () => void;
  isOpen?: boolean;
  setIsOpen?: (open: boolean) => void;
}

export default function Sidebar({
  user,
  activeMenu,
  setActiveMenu,
  isAdminView,
  setIsAdminView,
  onLogout,
  isOpen = false,
  setIsOpen
}: SidebarProps) {
  const { t } = useLanguage();
  
  const userMenus = [
    { id: 'home', label: t('menu.home'), icon: Home },
    { id: 'missions', label: t('menu.missions'), icon: Award },
    { id: 'bonus', label: t('menu.my_bonus'), icon: Coins },
    { id: 'leaderboard', label: t('menu.leaderboard'), icon: Trophy },
    { id: 'referrals', label: t('menu.referrals'), icon: Users },
    { id: 'settings', label: t('menu.settings'), icon: Settings },
  ];

  const adminMenus = [
    { id: 'admin-dashboard', label: t('menu.admin_dashboard'), icon: Home },
    { id: 'admin-users', label: t('menu.admin_users'), icon: UserCheck },
    { id: 'admin-submissions', label: t('menu.admin_submissions'), icon: Award },
    { id: 'admin-missions', label: t('menu.admin_missions'), icon: PlusSquare },
    { id: 'admin-rewards', label: t('menu.admin_rewards'), icon: Star },
    { id: 'admin-withdrawals', label: t('menu.admin_withdrawals'), icon: ArrowDownCircle },
    { id: 'admin-transactions', label: t('menu.admin_transactions'), icon: Activity },
    { id: 'admin-settings', label: t('menu.admin_settings'), icon: Settings },
  ];

  const currentMenus = isAdminView ? adminMenus : userMenus;

  return (
    <>
      {/* Mobile backdrop overlay */}
      <div 
        className={`fixed inset-0 bg-black/70 backdrop-blur-xs z-30 transition-opacity duration-300 md:hidden ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsOpen?.(false)}
      />

      <aside className={`w-64 bg-gray-950/95 border-r border-gray-900/80 flex flex-col h-screen fixed top-0 left-0 z-40 shadow-2xl transition-transform duration-300 ${
        isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
      }`}>
        {/* Brand logo header */}
        <div className="p-6 border-b border-gray-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-brand-blue to-brand-cyan flex items-center justify-center font-display font-bold text-white shadow-[0_0_15px_rgba(0,229,255,0.4)]">
              BX
            </div>
            <div>
              <h1 className="font-display font-bold text-xl tracking-tight text-white flex items-center gap-1">
                Bonus<span className="text-brand-cyan">X</span>
              </h1>
              <p className="text-[10px] text-gray-400 font-mono tracking-widest uppercase">Rewards Hub</p>
            </div>
          </div>

          {/* Mobile close button */}
          <button
            onClick={() => setIsOpen?.(false)}
            className="md:hidden p-1.5 rounded-xl text-gray-400 hover:text-white hover:bg-gray-900 transition cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

      {/* Mode switcher if Admin */}
      {user.isAdmin && (
        <div className="p-4 mx-4 mt-4 rounded-xl bg-gradient-to-r from-blue-950/40 to-cyan-950/40 border border-brand-cyan/20 flex flex-col gap-2">
          <div className="flex items-center gap-2 text-xs text-brand-cyan font-mono uppercase tracking-wider">
            <ShieldAlert size={14} className="animate-pulse" />
            <span>{t('menu.admin_mode')}</span>
          </div>
          <button
            onClick={() => {
              setIsAdminView(!isAdminView);
              setActiveMenu(isAdminView ? 'home' : 'admin-dashboard');
            }}
            id="toggle-admin-view-btn"
            className="w-full py-1.5 px-3 rounded-lg bg-brand-blue/20 hover:bg-brand-blue/40 border border-brand-blue/40 text-xs text-white font-medium transition duration-200 cursor-pointer text-center"
          >
            {isAdminView ? t('menu.access_user') : t('menu.access_admin')}
          </button>
        </div>
      )}

      {/* Navigation menu items */}
      <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        <div className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider px-3 mb-2 font-mono">
          {isAdminView ? t('menu.admin_title') : t('menu.user_title')}
        </div>
        {currentMenus.map((menu) => {
          const IconComponent = menu.icon;
          const isActive = activeMenu === menu.id;
          return (
            <button
              key={menu.id}
              id={`menu-item-${menu.id}`}
              onClick={() => setActiveMenu(menu.id)}
              className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-medium transition duration-200 cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-brand-blue/20 to-brand-cyan/10 border border-brand-cyan/30 text-brand-cyan text-glow-neon'
                  : 'text-gray-400 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
            >
              <IconComponent size={18} className={isActive ? 'text-brand-cyan' : 'text-gray-400'} />
              <span>{menu.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Logged in identity and disconnect footer */}
      <div className="p-4 border-t border-gray-900/80">
        <div className="flex items-center gap-3 px-2 py-1 mb-4">
          <div className="w-10 h-10 rounded-full bg-slate-800 border border-brand-cyan/40 flex items-center justify-center font-display font-bold text-brand-cyan shadow-[0_0_10px_rgba(0,229,255,0.15)]">
            {user.username.substring(0, 2).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-semibold text-white truncate">{user.username}</h4>
            <p className="text-xs text-gray-400 truncate font-mono">{user.email}</p>
          </div>
        </div>

        <button
          onClick={onLogout}
          id="logout-btn"
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 text-sm font-medium transition duration-200 cursor-pointer"
        >
          <LogOut size={16} />
          <span>{t('common.logout')}</span>
        </button>
      </div>
    </aside>
    </>
  );
}
