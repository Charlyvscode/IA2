import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  Settings, 
  TrendingUp, 
  Save, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  Coins,
  Clock,
  Sparkles
} from 'lucide-react';
import { api } from '../lib/api';

export default function MissionsAdmin() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Form Inputs
  const [durationMinutes, setDurationMinutes] = useState(10);
  const [rewardAmount, setRewardAmount] = useState(1.50);
  const [xpReward, setXpReward] = useState(50);

  // Fetch current administrative parameters
  const fetchSettings = async () => {
    try {
      const res = await api.getAdminGauge();
      if (res.settings) {
        setDurationMinutes(res.settings.durationMinutes);
        setRewardAmount(res.settings.rewardAmount);
        setXpReward(res.settings.xpReward);
      }
    } catch (err) {
      console.error('Erreur fetchAdminGauge', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  // Update administrative parameters
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setErrorMsg('');
    setSuccessMsg('');

    if (durationMinutes <= 0 || rewardAmount < 0 || xpReward < 0) {
      setErrorMsg('Veuillez entrer des valeurs strictement positives.');
      setSaving(false);
      return;
    }

    try {
      const res = await api.updateAdminGauge({
        durationMinutes: Number(durationMinutes),
        rewardAmount: Number(rewardAmount),
        xpReward: Number(xpReward)
      });
      if (res.success) {
        setSuccessMsg('Paramètres de la jauge mis à jour avec succès !');
        setTimeout(() => setSuccessMsg(''), 4000);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Une erreur est survenue lors de la sauvegarde.');
    } finally {
      setSaving(false);
    }
  };

  // Quick preset loader helpers
  const applyPreset = (mins: number, reward: number, xp: number) => {
    setDurationMinutes(mins);
    setRewardAmount(reward);
    setXpReward(xp);
    setErrorMsg('');
    setSuccessMsg('');
  };

  // Economic mathematical indicators for admin simulation
  const hourlyClaimsCount = 60 / durationMinutes;
  const hourlyUSDCYield = hourlyClaimsCount * rewardAmount;
  const dailyMaxClaims = (24 * 60) / durationMinutes;
  const dailyMaxUSDCYield = dailyMaxClaims * rewardAmount;

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* Upper header */}
      <div>
        <h2 className="font-display font-black text-2xl text-white flex items-center gap-2">
          <Settings className="text-brand-cyan" size={24} />
          <span>Contrôle de la Jauge de Bonus</span>
        </h2>
        <p className="text-xs text-gray-400 mt-1 max-w-2xl">
          Configurez ici la vitesse de remplissage de la jauge utilisateur, les gains en USDT/BTC correspondants crédités et la récompense en points d'XP.
        </p>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-3">
          <div className="w-8 h-8 border-2 border-brand-cyan/20 border-t-brand-cyan rounded-full animate-spin" />
          <span className="text-xs text-gray-500 font-mono uppercase tracking-widest">Chargement des paramètres de jauge...</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Settings Form panel (7 cols) */}
          <div className="lg:col-span-7 bg-gray-950/40 border border-gray-900 rounded-3xl p-8 shadow-2xl relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-cyan/5 rounded-full blur-2xl pointer-events-none" />
            
            <div className="pb-4 mb-6 border-b border-gray-900 flex items-center justify-between">
              <h3 className="font-display font-bold text-base text-white">Configuration des Variables</h3>
              <Sparkles size={16} className="text-brand-cyan animate-pulse" />
            </div>

            {/* Error / Success feedback toasts */}
            {errorMsg && (
              <div className="mb-6 p-4 rounded-xl bg-red-950/20 border border-red-500/30 text-xs text-red-400 flex items-center gap-2 animate-pulse">
                <AlertCircle size={16} className="shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="mb-6 p-4 rounded-xl bg-green-950/20 border border-green-500/30 text-xs text-green-400 flex items-center gap-2">
                <CheckCircle2 size={16} className="shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleSaveSettings} className="space-y-6">
              
              {/* Cooldown duration minutes input */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
                    Temps de remplissage (Minutes)
                  </label>
                  <span className="text-xs font-mono font-bold text-brand-cyan">{durationMinutes} minutes</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <input
                    type="number"
                    step="1"
                    min="1"
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(Math.max(1, parseInt(e.target.value) || 1))}
                    className="sm:col-span-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-3 text-center text-sm font-mono font-bold text-white focus:outline-none focus:border-brand-cyan transition"
                    required
                  />
                  <div className="sm:col-span-3 flex items-center">
                    <input
                      type="range"
                      min="1"
                      max="120"
                      value={durationMinutes}
                      onChange={(e) => setDurationMinutes(parseInt(e.target.value))}
                      className="w-full accent-brand-cyan cursor-pointer h-1.5 bg-gray-900 rounded-lg appearance-none"
                    />
                  </div>
                </div>
                <p className="text-[10px] text-gray-500">
                  Définit le temps nécessaire pour que la jauge atteigne 100% (ex : 10 minutes par défaut).
                </p>
              </div>

              {/* Reward and XP inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                
                {/* Reward Amount in USD equivalent */}
                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
                    Montant Récompense (USDT Équivalent)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={rewardAmount}
                      onChange={(e) => setRewardAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full bg-gray-950 border border-gray-800 rounded-xl pl-4 pr-16 py-3 text-sm font-mono font-bold text-white focus:outline-none focus:border-brand-cyan transition"
                      required
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-mono text-brand-cyan font-bold">
                      USDT
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-500">
                    Valeur en dollar stable USDT / BTC équivalent crédité au solde à chaque réclamation.
                  </p>
                </div>

                {/* XP Reward */}
                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
                    Points d'XP attribués
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      step="1"
                      min="0"
                      value={xpReward}
                      onChange={(e) => setXpReward(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full bg-gray-950 border border-gray-800 rounded-xl pl-4 pr-16 py-3 text-sm font-mono font-bold text-white focus:outline-none focus:border-brand-cyan transition"
                      required
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-mono text-brand-blue font-bold">
                      XP
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-500">
                    Aide l'utilisateur à progresser et débloquer des primes de niveaux.
                  </p>
                </div>

              </div>

              {/* Presets quick links */}
              <div className="pt-4 border-t border-gray-900">
                <span className="block text-[10px] font-mono font-bold uppercase text-gray-500 tracking-wider mb-2">
                  Modèles de Remplissage Rapides (Presets)
                </span>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => applyPreset(1, 0.25, 10)}
                    className="py-1.5 px-3 rounded-lg bg-gray-900 hover:bg-gray-800 text-[10px] font-bold text-gray-300 border border-gray-800 transition cursor-pointer"
                  >
                    🚀 Hyper Fast (1 Min - 0.25 USDT)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset(10, 1.50, 50)}
                    className="py-1.5 px-3 rounded-lg bg-gray-900 hover:bg-gray-800 text-[10px] font-bold text-gray-300 border border-gray-800 transition cursor-pointer"
                  >
                    ⏱️ Standard (10 Min - 1.50 USDT)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset(30, 5.00, 150)}
                    className="py-1.5 px-3 rounded-lg bg-gray-900 hover:bg-gray-800 text-[10px] font-bold text-gray-300 border border-gray-800 transition cursor-pointer"
                  >
                    🔒 Medium Lock (30 Min - 5.00 USDT)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset(60, 12.00, 300)}
                    className="py-1.5 px-3 rounded-lg bg-gray-900 hover:bg-gray-800 text-[10px] font-bold text-gray-300 border border-gray-800 transition cursor-pointer"
                  >
                    💎 High Stakes (60 Min - 12.00 USDT)
                  </button>
                </div>
              </div>

              {/* Save changes button */}
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={saving}
                  id="admin-save-gauge-btn"
                  className="w-full py-3 px-6 rounded-xl bg-gradient-to-r from-brand-blue to-brand-cyan hover:brightness-110 text-gray-950 font-extrabold text-xs transition duration-200 cursor-pointer flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,229,255,0.15)] disabled:opacity-50"
                >
                  {saving ? (
                    <span className="w-4 h-4 border-2 border-gray-950/30 border-t-gray-950 rounded-full animate-spin" />
                  ) : (
                    <>
                      <Save size={14} />
                      <span>Appliquer les Paramètres Administratifs</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          </div>

          {/* Economics & Simulator Preview panel (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* Economic Math Simulator Card */}
            <div className="bg-gray-950/45 border border-gray-900 rounded-3xl p-6 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-brand-blue/5 rounded-full blur-xl" />
              <h4 className="font-display font-bold text-sm text-white flex items-center gap-1.5 mb-4">
                <TrendingUp size={14} className="text-brand-cyan" />
                <span>Simulateur Économique</span>
              </h4>

              <div className="space-y-4 font-mono">
                
                {/* Stats grid */}
                <div className="p-3 bg-gray-900/30 rounded-xl border border-gray-900 text-xs flex justify-between items-center">
                  <span className="text-gray-500">Réclamations / heure :</span>
                  <span className="font-bold text-white">{hourlyClaimsCount.toFixed(1)} fois</span>
                </div>

                <div className="p-3 bg-gray-900/30 rounded-xl border border-gray-900 text-xs flex justify-between items-center">
                  <span className="text-gray-500">Rendement max / heure :</span>
                  <span className="font-bold text-green-400">{hourlyUSDCYield.toFixed(2)} USDT</span>
                </div>

                <div className="p-3 bg-gray-900/30 rounded-xl border border-gray-900 text-xs flex justify-between items-center">
                  <span className="text-gray-500">Claims max / jour (24h) :</span>
                  <span className="font-bold text-white">{dailyMaxClaims.toFixed(0)} fois</span>
                </div>

                <div className="p-3 bg-gradient-to-br from-gray-900/40 to-cyan-950/20 rounded-xl border border-gray-800 text-xs flex justify-between items-center">
                  <span className="text-gray-400 font-semibold">Distribution max / jour / user :</span>
                  <span className="font-black text-brand-cyan text-sm">{dailyMaxUSDCYield.toFixed(2)} USDT</span>
                </div>

              </div>

              <div className="mt-6 p-4 rounded-xl bg-gray-950 border border-gray-900 text-[10px] text-gray-500 leading-relaxed">
                💡 <strong>Analyse d'impact :</strong> Un temps de remplissage de {durationMinutes} minutes assure un engagement régulier des utilisateurs. Veillez à ce que vos réserves financières d'administration couvrent le taux d'engagement théorique de {dailyMaxUSDCYield.toFixed(2)} USDT par jour et par utilisateur actif.
              </div>
            </div>

            {/* Simulated Live User Preview */}
            <div className="bg-gray-950/45 border border-gray-900 rounded-3xl p-6 shadow-xl space-y-4">
              <h4 className="font-display font-bold text-sm text-white flex items-center gap-1.5">
                <Sparkles size={14} className="text-brand-cyan" />
                <span>Aperçu de l'interface utilisateur</span>
              </h4>

              {/* Mini User Component Emulator */}
              <div className="p-4 rounded-2xl bg-gray-950 border border-gray-900 text-center space-y-3">
                <div className="text-[10px] uppercase font-mono text-gray-500">Compteur de Jauge utilisateur</div>
                
                {/* Simulated circle or bar */}
                <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border border-dashed border-brand-cyan/20 animate-spin-slow" />
                  <svg className="w-24 h-24 transform -rotate-90">
                    <circle cx="48" cy="48" r="40" className="stroke-gray-900 fill-none" strokeWidth="4" />
                    <circle cx="48" cy="48" r="40" className="stroke-brand-cyan fill-none" strokeWidth="6" strokeDasharray={2 * Math.PI * 40} strokeDashoffset={2 * Math.PI * 40 * 0.4} />
                  </svg>
                  <div className="absolute flex flex-col items-center justify-center">
                    <span className="font-display font-black text-white text-base">60%</span>
                    <span className="text-[8px] font-mono text-brand-blue font-bold">04:00</span>
                  </div>
                </div>

                <div className="py-2.5 rounded-xl bg-gray-900 text-[10px] font-black text-gray-500 uppercase border border-gray-800">
                  Remplissage en cours (60%)
                </div>

                <p className="text-[9px] text-gray-500 leading-tight">
                  L'utilisateur verra ce bouton inactif avec décompte. Il s'activera et s'illuminera pour réclamer <strong>{rewardAmount.toFixed(2)} USDT</strong> en Bitcoin ou USDT dès que le minuteur atteindra zéro.
                </p>
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
