import React, { useState, useEffect } from 'react';
import { Trophy, Medal, Crown, Sparkles } from 'lucide-react';
import { LeaderboardUser as LUser } from '../types';
import { api } from '../lib/api';
import { useLanguage } from '../lib/LanguageContext';

export default function LeaderboardUser() {
  const { t, language } = useLanguage();
  const [leaderboard, setLeaderboard] = useState<LUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        const res = await api.getLeaderboard();
        setLeaderboard(res.leaderboard);
      } catch (err) {
        console.error('Erreur classement fetch', err);
      } finally {
        setLoading(false);
      }
    };
    fetchLeaderboard();
  }, []);

  const topThree = leaderboard.slice(0, 3);
  const regularUsers = leaderboard.slice(3);

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* Title */}
      <div>
        <h2 className="font-display font-bold text-2xl text-white flex items-center gap-2">
          <Trophy className="text-yellow-500 animate-pulse" />
          <span>{t('leaderboard.title')}</span>
        </h2>
        <p className="text-xs text-gray-400">{t('leaderboard.desc')}</p>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-3">
          <div className="w-8 h-8 border-2 border-brand-cyan/20 border-t-brand-cyan rounded-full animate-spin" />
          <span className="text-xs text-gray-500 font-mono uppercase tracking-widest">{language === 'fr' ? 'Calcul des positions...' : 'Calculating positions...'}</span>
        </div>
      ) : leaderboard.length === 0 ? (
        <div className="text-center py-16 bg-gray-950/40 rounded-2xl border border-gray-900 text-xs text-gray-500">
          {language === 'fr' ? 'Le classement est vide pour le moment. Réclame tes premiers XP !' : 'The leaderboard is currently empty. Claim your first XP!'}
        </div>
      ) : (
        <div className="space-y-8">
          
          {/* Top 3 Podium Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end pt-4">
            
            {/* 2nd Place */}
            {topThree[1] && (
              <div className="bg-gray-950/40 backdrop-blur-md rounded-2xl p-6 border border-gray-900 shadow-lg relative order-2 md:order-1 text-center md:min-h-[220px] flex flex-col justify-center hover:border-brand-cyan/20 transition-all">
                <div className="absolute top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-slate-700/60 border border-slate-500 flex items-center justify-center text-slate-300 font-bold text-xs font-mono">
                  2
                </div>
                <div className="w-12 h-12 rounded-full bg-slate-800 border-2 border-slate-400 mx-auto mb-3 flex items-center justify-center font-bold text-slate-300 text-sm">
                  {topThree[1].username.substring(0, 2).toUpperCase()}
                </div>
                <h4 className="font-bold text-white text-sm truncate">{topThree[1].username}</h4>
                <p className="text-[11px] text-gray-400 font-mono mt-1">{t('common.level')} {topThree[1].level} • {topThree[1].xp} XP</p>
                <div className="mt-3.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-400/10 border border-slate-400/20 text-[10px] text-slate-300 mx-auto">
                  <Medal size={12} />
                  <span>{language === 'fr' ? "Médaille d'Argent" : 'Silver Medal'}</span>
                </div>
              </div>
            )}

            {/* 1st Place (Crown theme) */}
            {topThree[0] && (
              <div className="bg-gray-950/40 backdrop-blur-md rounded-3xl p-8 border border-yellow-500/30 bg-gradient-to-tr from-yellow-950/20 to-gray-900/40 shadow-[0_0_30px_rgba(234,179,8,0.06)] relative order-1 md:order-2 text-center md:min-h-[260px] flex flex-col justify-center hover:border-yellow-400/40 transition-all">
                <div className="absolute top-4 left-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-yellow-500/20 border border-yellow-500 flex items-center justify-center text-yellow-400 font-bold text-sm font-mono shadow-[0_0_10px_rgba(234,179,8,0.3)]">
                  1
                </div>
                <div className="w-16 h-16 rounded-full bg-yellow-950/40 border-2 border-yellow-400 mx-auto mb-4 flex items-center justify-center font-bold text-yellow-400 text-lg relative">
                  <Crown size={20} className="absolute -top-4 left-1/2 -translate-x-1/2 text-yellow-400 drop-shadow-[0_0_5px_rgba(234,179,8,0.5)] animate-bounce" />
                  {topThree[0].username.substring(0, 2).toUpperCase()}
                </div>
                <h4 className="font-bold text-white text-base truncate flex items-center justify-center gap-1">
                  <span>{topThree[0].username}</span>
                  <Sparkles size={14} className="text-yellow-400 animate-pulse" />
                </h4>
                <p className="text-xs text-yellow-400/90 font-mono mt-1 font-semibold">{t('common.level')} {topThree[0].level} • {topThree[0].xp} XP</p>
                <div className="mt-4 inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-yellow-500/20 border border-yellow-400/30 text-[10px] text-yellow-400 mx-auto">
                  <span>🏆 {language === 'fr' ? 'Champion BonusX' : 'BonusX Champion'}</span>
                </div>
              </div>
            )}

            {/* 3rd Place */}
            {topThree[2] && (
              <div className="bg-gray-950/40 backdrop-blur-md rounded-2xl p-6 border border-gray-900 shadow-lg relative order-3 md:order-3 text-center md:min-h-[200px] flex flex-col justify-center hover:border-brand-cyan/20 transition-all">
                <div className="absolute top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-amber-900/40 border border-amber-600 flex items-center justify-center text-amber-500 font-bold text-xs font-mono">
                  3
                </div>
                <div className="w-12 h-12 rounded-full bg-amber-950/40 border-2 border-amber-600 mx-auto mb-3 flex items-center justify-center font-bold text-amber-500 text-sm">
                  {topThree[2].username.substring(0, 2).toUpperCase()}
                </div>
                <h4 className="font-bold text-white text-sm truncate">{topThree[2].username}</h4>
                <p className="text-[11px] text-gray-400 font-mono mt-1">{t('common.level')} {topThree[2].level} • {topThree[2].xp} XP</p>
                <div className="mt-3.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-600/10 border border-amber-600/20 text-[10px] text-amber-500 mx-auto">
                  <Medal size={12} />
                  <span>{language === 'fr' ? 'Médaille de Bronze' : 'Bronze Medal'}</span>
                </div>
              </div>
            )}

          </div>

          {/* Regular Users List Table */}
          {regularUsers.length > 0 && (
            <div className="bg-gray-950/40 border border-gray-900 rounded-2xl p-6 shadow-lg">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-gray-400">
                  <thead>
                    <tr className="border-b border-gray-900 text-[10px] uppercase font-mono tracking-wider text-gray-500">
                      <th className="py-3.5 px-4 w-16 text-center">{language === 'fr' ? 'Rang' : 'Rank'}</th>
                      <th className="py-3.5 px-4">{language === 'fr' ? 'Utilisateur' : 'User'}</th>
                      <th className="py-3.5 px-4">{t('common.level')}</th>
                      <th className="py-3.5 px-4 text-right">{language === 'fr' ? "Points d'XP" : 'XP Points'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-900/60">
                    {regularUsers.map((item, index) => (
                      <tr key={item.id} className="hover:bg-white/2 transition">
                        <td className="py-3 px-4 font-mono font-bold text-gray-400 text-center">
                          {index + 4}
                        </td>
                        <td className="py-3 px-4 font-semibold text-white flex items-center gap-3">
                          <div className="w-7 h-7 rounded-full bg-gray-950 border border-gray-900 flex items-center justify-center text-[10px] font-bold text-gray-400">
                            {item.username.substring(0, 2).toUpperCase()}
                          </div>
                          <span>{item.username}</span>
                        </td>
                        <td className="py-3 px-4 text-gray-300">
                          <span className="py-0.5 px-2 rounded bg-brand-cyan/10 border border-brand-cyan/20 text-[10px] font-bold text-brand-cyan font-mono">
                            LVL {item.level}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-gray-300">
                          {item.xp.toLocaleString()} XP
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
