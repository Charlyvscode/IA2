import React, { useState, useEffect } from 'react';
import { Mail, Lock, User as UserIcon, Users, AlertCircle, Coins, ArrowRight, ShieldCheck, Languages } from 'lucide-react';
import { api, setSessionToken } from '../lib/api';
import { User } from '../types';
import { useLanguage } from '../lib/LanguageContext';

interface AuthPageProps {
  onLoginSuccess: (user: User) => void;
}

export default function AuthPage({ onLoginSuccess }: AuthPageProps) {
  const { t, language, setLanguage } = useLanguage();
  const [isLogin, setIsLogin] = useState(true);
  
  // Inputs
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [referralCode, setReferralCode] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Check URL parameters on mount to auto-detect referral code (?ref=ALEX50)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) {
      setReferralCode(ref.toUpperCase());
      setIsLogin(false); // Switch to registration page so they can use the referral !
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    if (!email || !password || (!isLogin && !username)) {
      setErrorMsg(t('auth.error_all_fields'));
      setLoading(false);
      return;
    }

    try {
      if (isLogin) {
        // Login Flow
        const res = await api.login({ email, password });
        setSessionToken(res.token);
        onLoginSuccess(res.user);
      } else {
        // Register Flow
        const res = await api.register({
          email,
          username,
          password,
          referralCode: referralCode.trim() || undefined
        });
        setSessionToken(res.token);
        onLoginSuccess(res.user);
      }
    } catch (err: any) {
      setErrorMsg(err.message || t('auth.error_invalid_credentials'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center p-4 relative overflow-hidden bg-radial-cyan font-sans">
      
      {/* Floating Language Selector in Top Right */}
      <div className="absolute top-6 right-6 z-20 flex bg-gray-900/80 backdrop-blur rounded-xl p-1 border border-gray-800 shadow-xl">
        <button
          onClick={() => setLanguage('fr')}
          className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all duration-150 ${
            language === 'fr'
              ? 'bg-gradient-to-r from-brand-blue to-brand-cyan text-gray-950 font-bold shadow-[0_0_8px_rgba(0,229,255,0.4)]'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          FR
        </button>
        <button
          onClick={() => setLanguage('en')}
          className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all duration-150 ${
            language === 'en'
              ? 'bg-gradient-to-r from-brand-blue to-brand-cyan text-gray-950 font-bold shadow-[0_0_8px_rgba(0,229,255,0.4)]'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          EN
        </button>
      </div>

      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-blue/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-brand-cyan/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-md relative z-10 animate-fade-in">
        
        {/* Brand Header */}
        <div className="text-center mb-8 space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-brand-blue to-brand-cyan mx-auto flex items-center justify-center font-display font-black text-white text-2xl shadow-[0_0_25px_rgba(0,229,255,0.4)] animate-float">
            BX
          </div>
          <h1 className="font-display font-extrabold text-3xl tracking-tight text-white mt-4">
            Bonus<span className="text-brand-cyan">X</span>
          </h1>
          <p className="text-xs text-gray-400">
            {language === 'fr' ? 'Gagnez des USDC en accomplissant des missions Web3' : 'Earn USDC by completing simple Web3 tasks'}
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-gray-950/60 backdrop-blur-md rounded-3xl p-8 border border-gray-900 shadow-2xl">
          
          <div className="flex gap-4 pb-6 mb-6 border-b border-gray-900/60">
            <button
              onClick={() => {
                setIsLogin(true);
                setErrorMsg('');
              }}
              className={`flex-1 py-2 text-center font-display font-bold text-sm transition ${
                isLogin ? 'text-brand-cyan border-b-2 border-brand-cyan pb-2' : 'text-gray-500 hover:text-white'
              }`}
            >
              {language === 'fr' ? 'Se connecter' : 'Log In'}
            </button>
            <button
              onClick={() => {
                setIsLogin(false);
                setErrorMsg('');
              }}
              className={`flex-1 py-2 text-center font-display font-bold text-sm transition ${
                !isLogin ? 'text-brand-cyan border-b-2 border-brand-cyan pb-2' : 'text-gray-500 hover:text-white'
              }`}
            >
              {language === 'fr' ? "S'inscrire" : 'Sign Up'}
            </button>
          </div>

          {errorMsg && (
            <div className="mb-6 p-4 rounded-xl bg-red-950/20 border border-red-500/30 text-xs text-red-400 flex items-center gap-2 animate-pulse">
              <AlertCircle size={16} className="shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {referralCode && !isLogin && (
            <div className="mb-6 p-3 rounded-xl bg-brand-cyan/10 border border-brand-cyan/30 text-xs text-brand-cyan flex items-center gap-2 font-mono shadow-[0_0_12px_rgba(0,229,255,0.1)]">
              <Coins size={14} className="animate-pulse" />
              <span>{language === 'fr' ? 'Code parrainage appliqué ! (+5.00 USDC offerts)' : 'Referral code applied! (+5.00 USDC free)'}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Email Input */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
                {t('auth.email')}
              </label>
              <div className="relative">
                <input
                  type="email"
                  placeholder="nom@exemple.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-900 rounded-xl pl-11 pr-4 py-3 text-xs text-white placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition font-mono"
                  required
                />
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600" size={16} />
              </div>
            </div>

            {/* Username input (Only for Sign-up) */}
            {!isLogin && (
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
                  {t('auth.username')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Pseudo (Ex: AlexCrypto)"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-900 rounded-xl pl-11 pr-4 py-3 text-xs text-white placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition font-semibold"
                    required={!isLogin}
                  />
                  <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600" size={16} />
                </div>
              </div>
            )}

            {/* Password Input */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
                {t('auth.password')}
              </label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-900 rounded-xl pl-11 pr-4 py-3 text-xs text-white placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition"
                  required
                />
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600" size={16} />
              </div>
            </div>

            {/* Referral code input (Only for Sign-up) */}
            {!isLogin && (
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
                  {t('auth.referral_optional')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Ex: ALEX50"
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                    className="w-full bg-gray-950 border border-gray-900 rounded-xl pl-11 pr-4 py-3 text-xs text-brand-cyan font-mono font-bold placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition uppercase"
                  />
                  <Users className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600" size={16} />
                </div>
              </div>
            )}

            {/* Submit button */}
            <div className="pt-4">
              <button
                type="submit"
                disabled={loading}
                id="auth-submit-btn"
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-brand-blue to-brand-cyan text-gray-950 font-extrabold text-xs transition duration-200 cursor-pointer flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,229,255,0.25)] disabled:opacity-50"
              >
                {loading ? (
                  <span className="w-4 h-4 border-2 border-gray-950/30 border-t-gray-950 rounded-full animate-spin" />
                ) : (
                  <>
                    <span>{isLogin ? t('auth.btn_login') : t('auth.btn_register')}</span>
                    <ArrowRight size={14} />
                  </>
                )}
              </button>
            </div>

          </form>

        </div>

        {/* Demo Credentials Helper banner */}
        <div className="mt-6 p-4 rounded-2xl bg-gray-950/60 border border-gray-900 text-[11px] text-gray-400 font-mono space-y-1.5 shadow-md">
          <p className="text-white font-semibold flex items-center gap-1">
            <ShieldCheck size={14} className="text-brand-cyan" />
            <span>🔑 {language === 'fr' ? 'Comptes Démo de Test Préconfigurés :' : 'Demo Accounts for Preconfigured Testing :'}</span>
          </p>
          <div className="grid grid-cols-2 gap-2 text-[10px]">
            <div className="p-2 bg-gray-950 border border-gray-900 rounded-lg">
              <p className="text-brand-cyan font-bold">👤 {language === 'fr' ? 'ESPACE UTILISATEUR' : 'USER SPACE'}</p>
              <p className="mt-1">Email: <span className="text-white font-bold select-all">user@bonusx.com</span></p>
              <p>{language === 'fr' ? 'Mot de passe:' : 'Password:'} <span className="text-white font-bold select-all">user123</span></p>
            </div>
            <div className="p-2 bg-gray-950 border border-gray-900 rounded-lg">
              <p className="text-indigo-400 font-bold">🛡️ {language === 'fr' ? 'ESPACE ADMIN' : 'ADMIN SPACE'}</p>
              <p className="mt-1">Email: <span className="text-white font-bold select-all">admin@bonusx.com</span></p>
              <p>{language === 'fr' ? 'Mot de passe:' : 'Password:'} <span className="text-white font-bold select-all">admin123</span></p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
