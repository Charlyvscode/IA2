import React, { useState } from 'react';
import { Settings, Shield, User, Wallet, Key, AlertCircle, CheckCircle2 } from 'lucide-react';
import { User as UserType } from '../types';
import { api } from '../lib/api';
import { useLanguage } from '../lib/LanguageContext';

interface SettingsUserProps {
  user: UserType;
  onUserUpdate: (updatedUser: UserType) => void;
}

export default function SettingsUser({ user, onUserUpdate }: SettingsUserProps) {
  const { t, language } = useLanguage();
  const [username, setUsername] = useState(user.username);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [wallet, setWallet] = useState(user.walletAddress || '');
  
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [saving, setSaving] = useState(false);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setSaving(true);

    if (username.trim().length < 3) {
      setErrorMsg(language === 'fr' ? "Le nom d'utilisateur doit comporter au moins 3 caractères." : "Username must be at least 3 characters long.");
      setSaving(false);
      return;
    }

    if (password) {
      if (password.length < 6) {
        setErrorMsg(language === 'fr' ? "Le mot de passe doit comporter au moins 6 caractères." : "Password must be at least 6 characters long.");
        setSaving(false);
        return;
      }
      if (password !== confirmPassword) {
        setErrorMsg(language === 'fr' ? "Les mots de passe ne correspondent pas." : "Passwords do not match.");
        setSaving(false);
        return;
      }
    }

    try {
      // 1. Update Profile (username, password)
      const profileRes = await api.updateSettings({
        username: username.trim(),
        password: password ? password : undefined
      });

      // 2. Update Wallet
      const walletRes = await api.updateWallet(wallet.trim() || '');

      if (profileRes.success && walletRes.success) {
        onUserUpdate(walletRes.user);
        setSuccessMsg(language === 'fr' ? "Compte mis à jour avec succès !" : "Account updated successfully!");
        setPassword('');
        setConfirmPassword('');
      }
    } catch (err: any) {
      setErrorMsg(err.message || t('common.error'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* Title */}
      <div>
        <h2 className="font-display font-bold text-2xl text-white">{t('settings.title')}</h2>
        <p className="text-xs text-gray-400">{t('settings.desc')}</p>
      </div>

      <div className="max-w-3xl bg-gray-950/40 backdrop-blur-md rounded-3xl p-8 border border-gray-900 shadow-xl relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-cyan/5 rounded-full blur-2xl pointer-events-none" />

        {errorMsg && (
          <div className="mb-6 p-4 rounded-xl bg-red-950/20 border border-red-500/30 text-xs text-red-400 flex items-center gap-2 animate-pulse">
            <AlertCircle size={16} />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-6 p-4 rounded-xl bg-green-950/20 border border-green-500/30 text-xs text-green-400 flex items-center gap-2">
            <CheckCircle2 size={16} />
            <span>{successMsg}</span>
          </div>
        )}

        <form onSubmit={handleUpdateProfile} className="space-y-6">
          
          {/* Section 1: Informations Générales */}
          <div className="space-y-4">
            <h3 className="font-display font-bold text-sm text-white flex items-center gap-2 pb-2 border-b border-gray-900">
              <User className="text-brand-cyan" size={16} />
              <span>{language === 'fr' ? 'Informations Générales' : 'General Information'}</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                  {language === 'fr' ? 'Adresse Email (Non modifiable)' : 'Email Address (Non-editable)'}
                </label>
                <input
                  type="email"
                  value={user.email}
                  disabled
                  className="w-full bg-gray-950/60 border border-gray-900 rounded-xl px-4 py-2.5 text-xs text-gray-600 font-mono cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                  {language === 'fr' ? "Pseudo d'Utilisateur" : 'Username'}
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition font-semibold"
                  required
                />
              </div>
            </div>
          </div>

          {/* Section 2: Sécurité / Mot de passe */}
          <div className="space-y-4 pt-4">
            <h3 className="font-display font-bold text-sm text-white flex items-center gap-2 pb-2 border-b border-gray-900">
              <Key className="text-brand-cyan" size={16} />
              <span>{language === 'fr' ? 'Modifier le Mot de Passe' : 'Change Password'}</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                  {language === 'fr' ? 'Nouveau Mot de Passe (Optionnel)' : 'New Password (Optional)'}
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-850 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                  {language === 'fr' ? 'Confirmer le Mot de Passe' : 'Confirm Password'}
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-850 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition"
                />
              </div>
            </div>
            <span className="text-[10px] text-gray-500 font-mono block">
              {language === 'fr' 
                ? 'Laissez ces champs vides si vous ne souhaitez pas modifier votre mot de passe actuel.'
                : 'Leave these fields empty if you do not want to change your current password.'}
            </span>
          </div>

          {/* Section 3: Portefeuille */}
          <div className="space-y-4 pt-4">
            <h3 className="font-display font-bold text-sm text-white flex items-center gap-2 pb-2 border-b border-gray-900">
              <Wallet className="text-brand-cyan" size={16} />
              <span>{language === 'fr' ? 'Configuration Portefeuille Web3' : 'Web3 Wallet Configuration'}</span>
            </h3>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                {language === 'fr' ? 'Portefeuille EVM de Réception (Polygon / Mainnet)' : 'Receiving EVM Wallet (Polygon / Mainnet)'}
              </label>
              <input
                type="text"
                placeholder="0x..."
                value={wallet}
                onChange={(e) => setWallet(e.target.value)}
                className="w-full bg-gray-950 border border-gray-850 rounded-xl px-4 py-2.5 text-xs text-white font-mono placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition"
              />
            </div>
          </div>

          {/* Core Save button */}
          <div className="pt-6 border-t border-gray-950 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              id="save-user-settings-btn"
              className="py-3 px-8 rounded-xl bg-gradient-to-r from-brand-blue to-brand-cyan hover:brightness-110 text-gray-950 font-extrabold text-xs transition cursor-pointer flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,229,255,0.15)] disabled:opacity-50"
            >
              {saving ? (
                <span className="w-4 h-4 border-2 border-gray-950/30 border-t-gray-950 rounded-full animate-spin" />
              ) : (
                <>
                  <Shield size={14} />
                  <span>{language === 'fr' ? 'Sauvegarder les Paramètres' : 'Save Settings'}</span>
                </>
              )}
            </button>
          </div>

        </form>

      </div>

    </div>
  );
}
