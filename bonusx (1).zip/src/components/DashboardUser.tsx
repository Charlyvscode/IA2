import React, { useState, useEffect } from 'react';
import { 
  Gift, 
  Coins, 
  TrendingUp, 
  AlertCircle, 
  Sparkles, 
  CheckCircle2, 
  ArrowUpRight, 
  Activity, 
  Zap,
  Award,
  Wallet
} from 'lucide-react';
import * as d3 from 'd3';
import { User, Transaction } from '../types';
import { api } from '../lib/api';
import { useLanguage } from '../lib/LanguageContext';

interface DashboardUserProps {
  user: User;
  onUserUpdate: (updatedUser: User) => void;
  onTriggerNotificationRefresh: () => void;
  onNavigate?: (menuId: string) => void;
}

interface D3SparklineProps {
  data: number[];
  color: string;
  gradientId: string;
}

// Custom D3-powered Sparkline component
function D3Sparkline({ data, color, gradientId }: D3SparklineProps) {
  const width = 120;
  const height = 40;

  // D3 Scales with safe min/max fallbacks to avoid layout collapse
  const minVal = d3.min(data) ?? 0;
  const maxVal = d3.max(data) ?? 100;
  const yDomain = minVal === maxVal ? [minVal - 10, maxVal + 10] : [minVal, maxVal];

  const xScale = d3.scaleLinear()
    .domain([0, data.length - 1])
    .range([2, width - 2]);

  const yScale = d3.scaleLinear()
    .domain(yDomain)
    .range([height - 4, 4]);

  // Smoothed line generator using monotone curve interpolation
  const lineGenerator = d3.line<number>()
    .x((_, i) => xScale(i))
    .y(d => yScale(d))
    .curve(d3.curveMonotoneX);

  const pathD = lineGenerator(data) || '';

  // Area generator for custom underlying glow effects
  const areaGenerator = d3.area<number>()
    .x((_, i) => xScale(i))
    .y0(height)
    .y1(d => yScale(d))
    .curve(d3.curveMonotoneX);

  const areaD = areaGenerator(data) || '';

  return (
    <div className="relative shrink-0 select-none">
      <svg width={width} height={height} className="overflow-visible">
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.25" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        
        {/* Glowing Filled Underlay */}
        <path d={areaD} fill={`url(#${gradientId})`} />

        {/* Dynamic Curved Path */}
        <path
          d={pathD}
          fill="none"
          stroke={color}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="transition-all duration-500"
        />

        {/* Pulse Indicators on the final coordinate */}
        <circle
          cx={xScale(data.length - 1)}
          cy={yScale(data[data.length - 1])}
          r="3"
          fill={color}
        />
        <circle
          cx={xScale(data.length - 1)}
          cy={yScale(data[data.length - 1])}
          r="6"
          fill={color}
          className="animate-ping opacity-65"
        />
      </svg>
    </div>
  );
}

export default function DashboardUser({
  user,
  onUserUpdate,
  onTriggerNotificationRefresh,
  onNavigate
}: DashboardUserProps) {
  const { t, language } = useLanguage();
  const [claiming, setClaiming] = useState(false);
  const [claimStatus, setClaimStatus] = useState<{
    success: boolean;
    usdc?: number;
    xp?: number;
    leveledUp?: boolean;
    lvlUpReward?: number;
    error?: string;
  } | null>(null);
  
  const [recentTx, setRecentTx] = useState<Transaction[]>([]);
  const [stats, setStats] = useState({
    completedMissions: 0,
    referralsCount: 0,
  });

  const fetchDashboardData = async () => {
    try {
      const txData = await api.getMyBonus();
      setRecentTx(txData.bonuses.slice(0, 5)); // Get 5 latest

      const refData = await api.getReferrals();
      const subData = await api.getMySubmissions();
      
      setStats({
        completedMissions: subData.submissions.filter((s: any) => s.status === 'approved').length,
        referralsCount: refData.referralsCount
      });
    } catch (err) {
      console.error('Erreur dashboard data', err);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [user]);

  const handleClaimBonus = async () => {
    setClaiming(true);
    setClaimStatus(null);
    try {
      const res = await api.claimDaily();
      if (res.success) {
        onUserUpdate(res.user);
        setClaimStatus({
          success: true,
          usdc: res.bonusUsdc,
          xp: res.xpReward,
          leveledUp: res.leveledUp,
          lvlUpReward: res.levelUpReward
        });
        onTriggerNotificationRefresh();
        fetchDashboardData();
      }
    } catch (err: any) {
      setClaimStatus({
        success: false,
        error: err.message || t('dashboard.claim_error')
      });
    } finally {
      setClaiming(false);
    }
  };

  // Helper for rendering high-fidelity interactive SVG trendline
  const renderTrendChart = () => {
    return (
      <div className="mt-6 p-4 rounded-2xl bg-gray-900/40 border border-gray-800/80">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Activity size={14} className="text-brand-cyan animate-pulse" />
            <span className="text-[11px] font-mono text-gray-400 uppercase tracking-wider">
              {language === 'fr' ? 'Évolution de l\'Activité (XP & Gains)' : 'Activity Evolution (XP & Gains)'}
            </span>
          </div>
          <span className="text-[10px] font-mono text-brand-cyan bg-brand-cyan/10 px-2 py-0.5 rounded">
            Live EVM Sync
          </span>
        </div>
        <div className="h-20 w-full relative">
          <svg className="w-full h-full" viewBox="0 0 300 80" preserveAspectRatio="none">
            <defs>
              <linearGradient id="chart-glow" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#00e5ff" stopOpacity="0.25"/>
                <stop offset="100%" stopColor="#00e5ff" stopOpacity="0"/>
              </linearGradient>
            </defs>
            {/* Grid Lines */}
            <line x1="0" y1="20" x2="300" y2="20" stroke="#1f2937" strokeWidth="0.5" strokeDasharray="3,3" />
            <line x1="0" y1="40" x2="300" y2="40" stroke="#1f2937" strokeWidth="0.5" strokeDasharray="3,3" />
            <line x1="0" y1="60" x2="300" y2="60" stroke="#1f2937" strokeWidth="0.5" strokeDasharray="3,3" />
            
            {/* Area path */}
            <path
              d="M 0 70 Q 50 45 100 50 T 200 25 T 300 15 L 300 80 L 0 80 Z"
              fill="url(#chart-glow)"
            />
            {/* Trend line */}
            <path
              d="M 0 70 Q 50 45 100 50 T 200 25 T 300 15"
              fill="none"
              stroke="url(#line-grad)"
              strokeWidth="2"
              className="stroke-brand-cyan"
            />
            {/* Interactive Points */}
            <circle cx="100" cy="50" r="3" fill="#00e5ff" className="animate-ping" />
            <circle cx="100" cy="50" r="3" fill="#0052ff" />
            <circle cx="200" cy="25" r="3" fill="#00e5ff" />
            <circle cx="300" cy="15" r="3" fill="#00e5ff" className="shadow-[0_0_8px_#00e5ff]" />
            <linearGradient id="line-grad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#0052ff" />
              <stop offset="100%" stopColor="#00e5ff" />
            </linearGradient>
          </svg>
        </div>
        <div className="flex justify-between items-center text-[9px] text-gray-500 font-mono mt-2">
          <span>LVL 1</span>
          <span>LVL {Math.max(2, Math.floor(user.level / 2))}</span>
          <span>LVL {user.level} (ACTUEL)</span>
        </div>
      </div>
    );
  };

  // Generate dynamic progression curves for sparklines
  const getBalanceTrend = () => {
    if (recentTx.length === 0) {
      return [0, user.usdcBalance * 0.35, user.usdcBalance * 0.7, user.usdcBalance];
    }
    const sortedTx = [...recentTx].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    let current = user.usdcBalance;
    const history: number[] = [current];
    for (let i = sortedTx.length - 1; i >= 0; i--) {
      current -= sortedTx[i].amountUsdc;
      history.unshift(Math.max(0, current));
    }
    while (history.length < 4) {
      history.unshift(0);
    }
    return history;
  };

  const getXpTrend = () => {
    const currentXp = user.xp;
    return [
      Math.floor(currentXp * 0.2),
      Math.floor(currentXp * 0.45),
      Math.floor(currentXp * 0.75),
      currentXp
    ];
  };

  const getActivityTrend = () => {
    const totalActivity = stats.completedMissions + stats.referralsCount;
    return [
      Math.floor(totalActivity * 0.2),
      Math.floor(totalActivity * 0.5),
      Math.floor(totalActivity * 0.8),
      totalActivity
    ];
  };

  const balanceData = getBalanceTrend();
  const xpData = getXpTrend();
  const activityData = getActivityTrend();

  // Fine-tuned display typography elements for user balances
  const balanceStr = user.usdcBalance.toFixed(2);
  const [balanceInteger, balanceDecimal] = balanceStr.split('.');

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Upper Grid: Quick Stats with D3-powered trend lines and polished typography */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Card 1: Balance with bespoke sub-pixel rendering */}
        <div className="group bg-gray-950/40 backdrop-blur-md rounded-2xl p-6 relative overflow-hidden border border-gray-900 hover:border-brand-cyan/30 shadow-lg transition-all duration-300 flex flex-col justify-between min-h-[175px]">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand-blue/5 rounded-full blur-3xl group-hover:bg-brand-blue/10 transition-all duration-300 pointer-events-none" />
          
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono text-gray-400 uppercase tracking-wider">{t('dashboard.available_balance')}</span>
              <div className="p-2 rounded-xl bg-brand-blue/10 border border-brand-blue/20 text-brand-blue group-hover:scale-110 transition duration-300">
                <Coins size={16} />
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="flex items-baseline gap-0.5">
                <span className="font-display font-black text-4xl text-white tracking-tight bg-gradient-to-r from-white via-gray-100 to-brand-cyan bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(0,229,255,0.15)]">
                  {balanceInteger}
                </span>
                <span className="font-display font-bold text-xl text-brand-cyan">
                  .{balanceDecimal}
                </span>
                <span className="text-[10px] font-mono text-gray-500 ml-2 font-bold uppercase tracking-wider">
                  USDC
                </span>
              </div>
              <p className="text-[11px] text-gray-500 leading-relaxed">{t('dashboard.balance_desc')}</p>
              
              {/* Crypto equivalents with BTC / USDT logos as requested */}
              <div className="flex flex-wrap gap-2 mt-3 pt-2.5 border-t border-gray-900/40 text-[10px] font-mono font-bold">
                <span className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-md text-amber-500 shadow-sm">
                  <span>₿</span> {(user.usdcBalance / 65000).toFixed(6)} BTC
                </span>
                <span className="flex items-center gap-1 bg-green-500/10 border border-green-500/20 px-2 py-0.5 rounded-md text-green-400 shadow-sm">
                  <span>₮</span> {user.usdcBalance.toFixed(2)} USDT
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-900/60 flex items-center justify-between gap-4">
            <div className="flex flex-col">
              <span className="text-[9px] font-mono text-gray-500 uppercase">{language === 'fr' ? 'Évolution Solde' : 'Balance History'}</span>
              <span className="text-[10px] font-mono text-green-400 font-bold">Polygon Sync</span>
            </div>
            <D3Sparkline data={balanceData} color="#00e5ff" gradientId="balance-sparkline" />
          </div>
        </div>

        {/* Card 2: Niveau & XP with progression curve */}
        <div className="group bg-gray-950/40 backdrop-blur-md rounded-2xl p-6 relative overflow-hidden border border-gray-900 hover:border-brand-cyan/30 shadow-lg transition-all duration-300 flex flex-col justify-between min-h-[175px]">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand-cyan/5 rounded-full blur-3xl group-hover:bg-brand-cyan/10 transition-all duration-300 pointer-events-none" />
          
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono text-gray-400 uppercase tracking-wider">{t('dashboard.current_level')}</span>
              <div className="p-2 rounded-xl bg-brand-cyan/10 border border-brand-cyan/20 text-brand-cyan group-hover:scale-110 transition duration-300">
                <TrendingUp size={16} />
              </div>
            </div>
            
            <div className="space-y-1">
              <h3 className="font-display font-black text-3xl text-white tracking-tight">
                {t('common.level')} {user.level}
              </h3>
              <p className="text-xs text-gray-400 font-mono font-medium">
                {t('dashboard.xp_accumulated', { xp: user.xp })}
              </p>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-900/60 flex items-center justify-between gap-4">
            <div className="flex flex-col">
              <span className="text-[9px] font-mono text-gray-500 uppercase">{language === 'fr' ? 'Progression XP' : 'XP Progress'}</span>
              <span className="text-[10px] font-mono text-brand-cyan font-bold">LVL UP SOON</span>
            </div>
            <D3Sparkline data={xpData} color="#0052ff" gradientId="xp-sparkline" />
          </div>
        </div>

        {/* Card 3: Activité & Stat progression curve */}
        <div className="group bg-gray-950/40 backdrop-blur-md rounded-2xl p-6 relative overflow-hidden border border-gray-900 hover:border-brand-cyan/30 shadow-lg transition-all duration-300 flex flex-col justify-between min-h-[175px]">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-3xl group-hover:bg-indigo-500/10 transition-all duration-300 pointer-events-none" />
          
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono text-gray-400 uppercase tracking-wider">{t('dashboard.activity_title')}</span>
              <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 group-hover:scale-110 transition duration-300">
                <Sparkles size={16} />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-400 font-medium">{t('dashboard.missions_validated')}</span>
                <span className="text-xs font-bold text-white font-mono">{stats.completedMissions}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-400 font-medium">{t('dashboard.referrals_count')}</span>
                <span className="text-xs font-bold text-white font-mono">{stats.referralsCount}</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-900/60 flex items-center justify-between gap-4">
            <div className="flex flex-col">
              <span className="text-[9px] font-mono text-gray-500 uppercase">{language === 'fr' ? 'Taux d\'Activité' : 'Activity Rate'}</span>
              <span className="text-[10px] font-mono text-indigo-400 font-bold">100% Verified</span>
            </div>
            <D3Sparkline data={activityData} color="#8b5cf6" gradientId="activity-sparkline" />
          </div>
        </div>

      </div>

      {/* Bento Quick Actions Grid */}
      <div className="bg-gray-950/40 backdrop-blur-md border border-gray-900 rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-brand-cyan/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex items-center justify-between mb-6 pb-3 border-b border-gray-900">
          <div>
            <h4 className="font-display font-bold text-base text-white flex items-center gap-2">
              <Zap className="text-brand-cyan animate-pulse" size={16} />
              <span>{language === 'fr' ? 'Actions Rapides' : 'Quick Actions'}</span>
            </h4>
            <p className="text-xs text-gray-500 mt-0.5">
              {language === 'fr' ? 'Raccourcis pour maximiser vos gains et gérer votre compte' : 'Shortcuts to maximize your earnings and manage your account'}
            </p>
          </div>
          <span className="text-[10px] font-mono text-brand-cyan bg-brand-cyan/10 px-2.5 py-0.5 rounded-full uppercase tracking-wider font-bold">
            Live EVM Portal
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Action 1: Web3 Missions */}
          <button
            onClick={() => onNavigate && onNavigate('missions')}
            className="group text-left bg-gray-900/20 hover:bg-brand-blue/5 border border-gray-900 hover:border-brand-blue/30 rounded-2xl p-5 transition-all duration-300 flex flex-col justify-between h-36 cursor-pointer"
          >
            <div className="p-2.5 rounded-xl bg-brand-blue/10 border border-brand-blue/20 text-brand-blue group-hover:scale-110 transition duration-300 w-fit">
              <Award size={18} />
            </div>
            <div>
              <h5 className="font-display font-bold text-sm text-white group-hover:text-brand-blue transition">
                {language === 'fr' ? 'Missions Web3' : 'Web3 Missions'}
              </h5>
              <p className="text-[11px] text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                {language === 'fr' ? 'Valider des tâches sociales, quiz et vidéo pour gagner instantanément.' : 'Complete social tasks, quizzes, and videos for instant rewards.'}
              </p>
            </div>
          </button>

          {/* Action 2: Daily loyalty claim (smooth scrolls down to container) */}
          <button
            onClick={() => {
              const element = document.getElementById('claim-section-container');
              if (element) {
                element.scrollIntoView({ behavior: 'smooth' });
                element.classList.add('ring-2', 'ring-brand-cyan', 'ring-offset-2', 'ring-offset-gray-950');
                setTimeout(() => {
                  element.classList.remove('ring-2', 'ring-brand-cyan', 'ring-offset-2', 'ring-offset-gray-950');
                }, 2000);
              }
            }}
            className="group text-left bg-gray-900/20 hover:bg-brand-cyan/5 border border-gray-900 hover:border-brand-cyan/30 rounded-2xl p-5 transition-all duration-300 flex flex-col justify-between h-36 cursor-pointer"
          >
            <div className="p-2.5 rounded-xl bg-brand-cyan/10 border border-brand-cyan/20 text-brand-cyan group-hover:scale-110 transition duration-300 w-fit">
              <Gift size={18} />
            </div>
            <div>
              <h5 className="font-display font-bold text-sm text-white group-hover:text-brand-cyan transition">
                {language === 'fr' ? 'Bonus Quotidien' : 'Daily Bonus'}
              </h5>
              <p className="text-[11px] text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                {language === 'fr' ? 'Récupérer votre récompense USDC de fidélité toutes les 24h.' : 'Retrieve your loyalty USDC rewards every 24 hours.'}
              </p>
            </div>
          </button>

          {/* Action 3: Request Payout */}
          <button
            onClick={() => onNavigate && onNavigate('bonus')}
            className="group text-left bg-gray-900/20 hover:bg-green-500/5 border border-gray-900 hover:border-green-500/30 rounded-2xl p-5 transition-all duration-300 flex flex-col justify-between h-36 cursor-pointer"
          >
            <div className="p-2.5 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 group-hover:scale-110 transition duration-300 w-fit">
              <Wallet size={18} />
            </div>
            <div>
              <h5 className="font-display font-bold text-sm text-white group-hover:text-green-400 transition">
                {language === 'fr' ? 'Retirer mes USDC' : 'Withdraw USDC'}
              </h5>
              <p className="text-[11px] text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                {language === 'fr' ? 'Transférer vos gains USDC disponibles vers votre portefeuille Polygon.' : 'Transfer your available USDC earnings to your Polygon wallet.'}
              </p>
            </div>
          </button>

          {/* Action 4: Invite & Earn */}
          <button
            onClick={() => onNavigate && onNavigate('referrals')}
            className="group text-left bg-gray-900/20 hover:bg-indigo-500/5 border border-gray-900 hover:border-indigo-500/30 rounded-2xl p-5 transition-all duration-300 flex flex-col justify-between h-36 cursor-pointer"
          >
            <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 group-hover:scale-110 transition duration-300 w-fit">
              <ArrowUpRight size={18} />
            </div>
            <div>
              <h5 className="font-display font-bold text-sm text-white group-hover:text-indigo-400 transition">
                {language === 'fr' ? 'Parrainer des Amis' : 'Refer Friends'}
              </h5>
              <p className="text-[11px] text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                {language === 'fr' ? 'Obtenir +10.00 USDC de commission par filleul actif inscrit.' : 'Get +10.00 USDC commission for every active referral registered.'}
              </p>
            </div>
          </button>

        </div>
      </div>

      {/* Main Core Layout: Left central gift/wheel + Right recent transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        
        {/* Left Side: Central Spinning Animation & Daily Claim Button (Covers 3 cols) */}
        <div id="claim-section-container" className="lg:col-span-3 bg-gray-950/45 border border-gray-900 rounded-3xl p-8 shadow-xl flex flex-col items-center justify-center relative overflow-hidden transition-all duration-500">
          
          {/* Subtle grid pattern background to enhance layout premium feel */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-35 pointer-events-none" />
          
          {/* Neon radial glow background */}
          <div className="absolute inset-0 bg-radial-gradient pointer-events-none" />

          {/* Central Animated Coin / Gift Visualizer */}
          <div className="relative w-48 h-48 mb-6 flex items-center justify-center group z-10">
            {/* Spinning background rays */}
            <div className="absolute inset-0 rounded-full border border-dashed border-brand-cyan/20 animate-spin-slow group-hover:border-brand-cyan/40" />
            
            {/* Ambient neon pulse shadow */}
            <div className="absolute w-36 h-36 rounded-full bg-brand-cyan/5 blur-2xl animate-neon-pulse" />

            {/* Main spinning coin */}
            <div className="w-36 h-36 rounded-full bg-gradient-to-tr from-brand-blue to-brand-cyan p-1.5 shadow-[0_0_30px_rgba(0,229,255,0.15)] hover:shadow-[0_0_40px_rgba(0,229,255,0.35)] transition-all duration-500 animate-float cursor-pointer flex items-center justify-center">
              <div className="w-full h-full rounded-full bg-gray-950 flex flex-col items-center justify-center border border-brand-cyan/20 group-hover:border-brand-cyan/40 transition duration-300">
                <div className="w-12 h-12 rounded-xl bg-brand-cyan/10 flex items-center justify-center mb-1.5 border border-brand-cyan/20">
                  <Coins size={28} className="text-brand-cyan animate-pulse" />
                </div>
                <span className="font-display font-extrabold text-base text-white tracking-tight">BonusX</span>
                <span className="text-[9px] font-mono text-gray-500 tracking-wider">SECURE LOOT</span>
              </div>
            </div>

            {/* Sparkle micro-elements */}
            <div className="absolute top-2 right-4 text-brand-cyan animate-pulse">✨</div>
            <div className="absolute bottom-4 left-6 text-brand-cyan animate-pulse delay-75">✨</div>
          </div>

          <div className="text-center max-w-sm mb-6 space-y-2 z-10">
            <h4 className="font-display font-extrabold text-xl text-white tracking-tight">{t('dashboard.daily_bonus_title')}</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              {t('dashboard.daily_bonus_desc')}
            </p>
          </div>

          {/* Claim Results Display */}
          {claimStatus && (
            <div className="w-full max-w-sm mb-6 animate-fade-in z-10">
              {claimStatus.success ? (
                <div className="p-4 rounded-2xl bg-green-950/20 border border-green-500/30 space-y-2.5 text-center shadow-[0_0_15px_rgba(34,197,94,0.15)]">
                  <div className="flex items-center justify-center gap-2 text-green-400">
                    <CheckCircle2 size={18} />
                    <span className="font-semibold text-sm">{t('dashboard.bonus_claimed')}</span>
                  </div>
                  <p className="text-xs text-gray-300 leading-relaxed">
                    {t('dashboard.bonus_claimed_desc', { usdc: claimStatus.usdc, xp: claimStatus.xp })}
                  </p>
                  {claimStatus.leveledUp && (
                    <div className="p-3 rounded-xl bg-gradient-to-r from-yellow-950/30 to-amber-950/30 border border-yellow-500/30 text-xs text-yellow-400 mt-2 flex flex-col items-center gap-1 shadow-lg animate-bounce">
                      <span className="font-bold tracking-wider flex items-center gap-1.5">
                        <Zap size={14} className="animate-pulse text-amber-400" />
                        {t('dashboard.level_up_congrats')}
                      </span>
                      <span>{t('dashboard.level_up_desc', { reward: claimStatus.lvlUpReward })}</span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-red-950/20 border border-red-500/30 flex items-center gap-3 text-red-400 text-xs shadow-lg">
                  <AlertCircle size={20} className="shrink-0" />
                  <span>{claimStatus.error}</span>
                </div>
              )}
            </div>
          )}

          {/* Core action button */}
          <div className="w-full max-w-sm relative z-10 group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-brand-blue to-brand-cyan rounded-2xl blur opacity-30 group-hover:opacity-70 transition duration-300" />
            <button
              onClick={handleClaimBonus}
              disabled={claiming}
              id="claim-daily-bonus-btn"
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-brand-blue to-brand-cyan text-gray-950 font-extrabold hover:brightness-110 transition duration-200 cursor-pointer text-center relative overflow-hidden shadow-[0_4px_20px_rgba(0,229,255,0.3)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2.5 text-sm"
            >
              {claiming ? (
                <>
                  <span className="w-5 h-5 border-2 border-gray-950/30 border-t-gray-950 rounded-full animate-spin" />
                  <span>{t('dashboard.syncing')}</span>
                </>
              ) : (
                <>
                  <Gift size={18} />
                  <span>{t('dashboard.claim_daily_btn')}</span>
                </>
              )}
            </button>
          </div>

          <span className="text-[10px] text-gray-500 font-mono mt-3.5 uppercase tracking-wider z-10">
            {t('dashboard.cooldown_info')}
          </span>

        </div>

        {/* Right Side: Recent Transactions List & Trend Chart (Covers 2 cols) */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          
          {/* Trend Tracker Card */}
          <div className="bg-gray-950/45 border border-gray-900 rounded-3xl p-6 shadow-xl">
            {renderTrendChart()}
          </div>

          {/* Recent History Card */}
          <div className="bg-gray-950/45 border border-gray-900 rounded-3xl p-6 shadow-xl flex-1 flex flex-col h-full">
            <div className="pb-4 mb-4 border-b border-gray-900 flex items-center justify-between">
              <div>
                <h4 className="font-display font-bold text-base text-white">{t('dashboard.history_title')}</h4>
                <p className="text-xs text-gray-500">{t('dashboard.history_desc')}</p>
              </div>
              <ArrowUpRight size={18} className="text-gray-500" />
            </div>

            <div className="flex-1 space-y-3 overflow-y-auto max-h-[220px]">
              {recentTx.length === 0 ? (
                <div className="text-center py-10 text-xs text-gray-500 font-mono">
                  {t('dashboard.no_transactions')}
                </div>
              ) : (
                recentTx.map((tx) => (
                  <div 
                    key={tx.id} 
                    className="p-3 rounded-xl bg-gray-900/30 border border-gray-900 flex items-center justify-between text-xs transition hover:border-gray-800"
                  >
                    <div className="space-y-1 min-w-0 pr-2">
                      <p className="font-semibold text-white leading-tight truncate">{tx.description}</p>
                      <span className="text-[10px] text-gray-500 font-mono block">
                        {new Date(tx.createdAt).toLocaleDateString(t('header.time_format'), {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="font-mono font-bold text-green-400">
                        +{tx.amountUsdc.toFixed(2)} USDC
                      </span>
                      <span className="text-[9px] text-gray-500 block font-mono">{t('dashboard.polygon_tx')}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
