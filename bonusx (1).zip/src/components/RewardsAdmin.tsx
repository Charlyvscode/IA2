import React, { useState, useEffect } from 'react';
import { Star, Award, CheckCircle2, AlertCircle, Coins, Plus, Settings } from 'lucide-react';
import { LevelConfig } from '../types';
import { api } from '../lib/api';

export default function RewardsAdmin() {
  const [levelConfigs, setLevelConfigs] = useState<LevelConfig[]>([]);
  const [loading, setLoading] = useState(true);

  // Form states
  const [level, setLevel] = useState('');
  const [xpRequired, setXpRequired] = useState('');
  const [rewardUsdc, setRewardUsdc] = useState('');

  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const fetchLevels = async () => {
    try {
      const res = await api.getAdminLevels();
      setLevelConfigs(res.levels);
    } catch (err) {
      console.error('Erreur admin levels fetch', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLevels();
  }, []);

  const handleSaveLevelConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setSaving(true);

    const lvlNum = Number(level);
    const xpNum = Number(xpRequired);
    const rewardNum = Number(rewardUsdc);

    if (!level || xpRequired === '' || rewardUsdc === '') {
      setErrorMsg('Veuillez remplir tous les champs du palier de niveau.');
      setSaving(false);
      return;
    }

    if (lvlNum <= 0 || xpNum < 0 || rewardNum < 0) {
      setErrorMsg('Veuillez saisir des valeurs positives cohérentes.');
      setSaving(false);
      return;
    }

    try {
      const res = await api.updateAdminLevel({
        level: lvlNum,
        xpRequired: xpNum,
        rewardUsdc: rewardNum
      });

      if (res.success) {
        setSuccessMsg(`Palier du niveau ${lvlNum} mis à jour avec succès !`);
        setLevel('');
        setXpRequired('');
        setRewardUsdc('');
        fetchLevels();
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Erreur lors de la sauvegarde du niveau.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Title */}
      <div>
        <h2 className="font-display font-bold text-2xl text-white">Configuration des Niveaux & Paliers</h2>
        <p className="text-xs text-gray-400">Définissez les prérequis en points d'XP et les récompenses en USDC créditées automatiquement lors de la montée de niveau des utilisateurs.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        
        {/* Left Side: Level Configs list table (Covers 3 cols) */}
        <div className="lg:col-span-3 glass-card rounded-2xl p-6 border border-gray-800/80 shadow-lg">
          <div className="pb-3 border-b border-gray-900 mb-4 flex items-center justify-between">
            <h3 className="font-display font-bold text-base text-white">Table des Paliers</h3>
            <span className="text-[10px] text-brand-cyan font-mono font-semibold">SÉQUENCE AUTOMATISÉE</span>
          </div>

          {loading ? (
            <div className="text-center py-12 text-xs text-gray-600 font-mono">Chargement des paliers...</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-gray-400">
                <thead>
                  <tr className="border-b border-gray-900 text-[10px] uppercase font-mono tracking-wider text-gray-500">
                    <th className="py-3 px-4">Palier</th>
                    <th className="py-3 px-4">XP Minimale requise</th>
                    <th className="py-3 px-4 text-right font-mono">Bonus de passage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-900/60 font-mono text-gray-300">
                  {levelConfigs.map((cfg) => (
                    <tr key={cfg.level} className="hover:bg-white/2 transition">
                      <td className="py-3 px-4 font-semibold text-white">
                        <span className="py-1 px-2.5 rounded-lg bg-brand-cyan/10 border border-brand-cyan/20 text-brand-cyan text-[10px] font-bold">
                          Niveau {cfg.level}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {cfg.xpRequired.toLocaleString()} XP
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-green-400">
                        {cfg.rewardUsdc > 0 ? `+${cfg.rewardUsdc.toFixed(2)} USDC` : 'Sans bonus'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Right Side: Form to add/update palier (Covers 2 cols) */}
        <div className="lg:col-span-2 glass-card rounded-2xl p-6 border border-gray-800/80 shadow-md">
          <div className="pb-3 border-b border-gray-900 mb-4 flex items-center gap-2">
            <Settings className="text-brand-cyan" size={16} />
            <h4 className="font-display font-bold text-base text-white">Éditeur de Palier</h4>
          </div>

          {errorMsg && (
            <div className="mb-4 p-3 rounded-lg bg-red-950/20 border border-red-500/30 text-xs text-red-400 flex items-center gap-2">
              <AlertCircle size={14} />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 rounded-lg bg-green-950/20 border border-green-500/30 text-xs text-green-400 flex items-center gap-2">
              <CheckCircle2 size={14} />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleSaveLevelConfig} className="space-y-4">
            
            {/* Level input */}
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase mb-2 font-mono">
                Niveau concerné
              </label>
              <input
                type="number"
                placeholder="Ex: 5"
                value={level}
                onChange={(e) => setLevel(e.target.value)}
                className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-700 font-mono focus:outline-none focus:border-brand-cyan transition"
                required
              />
            </div>

            {/* XP Required input */}
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase mb-2 font-mono">
                Seuil d'XP minimal
              </label>
              <input
                type="number"
                placeholder="Ex: 2500"
                value={xpRequired}
                onChange={(e) => setXpRequired(e.target.value)}
                className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-700 font-mono focus:outline-none focus:border-brand-cyan transition"
                required
              />
            </div>

            {/* Reward USDC input */}
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase mb-2 font-mono">
                Bonus de Passage (USDC)
              </label>
              <input
                type="number"
                step="0.01"
                placeholder="Ex: 15.00"
                value={rewardUsdc}
                onChange={(e) => setRewardUsdc(e.target.value)}
                className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-700 font-mono focus:outline-none focus:border-brand-cyan transition"
                required
              />
            </div>

            <div className="pt-4">
              <button
                type="submit"
                disabled={saving}
                id="save-level-config-btn"
                className="w-full py-3 rounded-xl bg-brand-blue hover:brightness-110 text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,82,255,0.2)] disabled:opacity-50"
              >
                {saving ? (
                  <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Plus size={14} />
                    <span>Sauvegarder le niveau</span>
                  </>
                )}
              </button>
            </div>

          </form>

        </div>

      </div>

    </div>
  );
}
