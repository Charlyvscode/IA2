import React, { useState, useEffect } from 'react';
import { Users, Copy, Check, Gift, Coins, Share2, HelpCircle } from 'lucide-react';
import { User, ReferralStats } from '../types';
import { api } from '../lib/api';
import { useLanguage } from '../lib/LanguageContext';

interface ReferralUserProps {
  user: User;
}

export default function ReferralUser({ user }: ReferralUserProps) {
  const { t, language } = useLanguage();
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const fetchReferrals = async () => {
    try {
      const res = await api.getReferrals();
      setStats(res);
    } catch (err) {
      console.error('Erreur parrainage fetch', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReferrals();
  }, [user]);

  // Generate Referral link
  const referralLink = `${window.location.origin}/?ref=${stats?.referralCode || user.referralCode}`;

  const copyToClipboard = (text: string, type: 'code' | 'link') => {
    navigator.clipboard.writeText(text);
    if (type === 'code') {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } else {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* Title */}
      <div>
        <h2 className="font-display font-bold text-2xl text-white">{t('referrals.title')}</h2>
        <p className="text-xs text-gray-400">{t('referrals.desc')}</p>
      </div>

      {/* Grid: Instructions vs Invite Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        
        {/* Left Side: Referral Program Rules & Copy (Covers 3 cols) */}
        <div className="lg:col-span-3 bg-gray-950/40 backdrop-blur-md rounded-3xl p-8 border border-gray-900 shadow-xl relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand-cyan/5 rounded-full blur-2xl pointer-events-none" />
          
          <div className="pb-4 mb-6 border-b border-gray-900 flex items-center justify-between">
            <h3 className="font-display font-bold text-base text-white">{language === 'fr' ? "Ton Lien d'Invitation" : 'Your Invitation Link'}</h3>
            <span className="text-xs text-brand-cyan font-mono font-bold">{language === 'fr' ? 'COMMISSION 100% GARANTIE' : '100% SECURE COMMISSION'}</span>
          </div>

          <div className="space-y-6">
            
            {/* Steps Guide */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-gray-900/40 border border-gray-900 flex gap-3 items-start text-xs">
                <span className="w-6 h-6 rounded-lg bg-brand-blue/20 border border-brand-blue/30 flex items-center justify-center font-bold text-brand-cyan font-mono">1</span>
                <div>
                  <h4 className="font-bold text-white mb-0.5">{language === 'fr' ? 'Partage ton code' : 'Share your code'}</h4>
                  <p className="text-gray-400 leading-relaxed text-[11px]">{language === 'fr' ? 'Envoie ton lien à tes contacts, sur tes réseaux sociaux, ou sur tes forums crypto.' : 'Send your link to friends, post on socials, or share in crypto groups.'}</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-gray-900/40 border border-gray-900 flex gap-3 items-start text-xs">
                <span className="w-6 h-6 rounded-lg bg-brand-cyan/20 border border-brand-cyan/30 flex items-center justify-center font-bold text-brand-cyan font-mono">2</span>
                <div>
                  <h4 className="font-bold text-white mb-0.5">{language === 'fr' ? 'Gagnez tous les deux' : 'Both of you earn'}</h4>
                  <p className="text-gray-400 leading-relaxed text-[11px]">
                    {language === 'fr' 
                      ? <>Ton filleul gagne <span className="text-green-400 font-bold">5 USDC</span> à l'inscription. Tu touches <span className="text-green-400 font-bold">10 USDC</span> immédiatement.</>
                      : <>Your invitee gets <span className="text-green-400 font-bold">5 USDC</span> on signup. You get <span className="text-green-400 font-bold">10 USDC</span> instantly.</>
                    }
                  </p>
                </div>
              </div>
            </div>

            {/* Sharing Fields */}
            <div className="space-y-4 pt-4 border-t border-gray-900">
              
              {/* Field 1: Referral Code */}
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                  {t('referrals.code_label')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={stats?.referralCode || user.referralCode}
                    readOnly
                    className="w-full bg-gray-950 border border-gray-850 rounded-xl px-4 py-3 text-sm text-brand-cyan font-mono font-bold uppercase select-all"
                  />
                  <button
                    onClick={() => copyToClipboard(stats?.referralCode || user.referralCode, 'code')}
                    id="copy-referral-code-btn"
                    className="absolute right-3 top-1/2 -translate-y-1/2 py-1.5 px-3 rounded-lg bg-gray-900 hover:bg-gray-800 text-xs font-bold text-white flex items-center gap-1 cursor-pointer transition border border-gray-800"
                  >
                    {copiedCode ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                    <span>{copiedCode ? t('referrals.copied') : t('referrals.copy')}</span>
                  </button>
                </div>
              </div>

              {/* Field 2: Custom Link */}
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 font-mono">
                  {t('referrals.link_label')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={referralLink}
                    readOnly
                    className="w-full bg-gray-950 border border-gray-850 rounded-xl px-4 py-3 text-xs text-gray-400 font-mono select-all"
                  />
                  <button
                    onClick={() => copyToClipboard(referralLink, 'link')}
                    id="copy-referral-link-btn"
                    className="absolute right-3 top-1/2 -translate-y-1/2 py-1.5 px-3 rounded-lg bg-gray-900 hover:bg-gray-800 text-xs font-bold text-white flex items-center gap-1 cursor-pointer transition border border-gray-800"
                  >
                    {copiedLink ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                    <span>{copiedLink ? t('referrals.copied') : t('referrals.copy')}</span>
                  </button>
                </div>
              </div>

            </div>

          </div>

        </div>

        {/* Right Side: Quick Stats counters (Covers 2 cols) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Card: Registered referrals */}
          <div className="bg-gray-950/40 backdrop-blur-md rounded-2xl p-6 border border-gray-900 bg-gradient-to-br from-gray-900/40 to-cyan-950/20 shadow-lg flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-gray-400 uppercase">{t('referrals.count_label')}</span>
              <Users className="text-brand-cyan" size={18} />
            </div>
            <div>
              <h3 className="font-display font-bold text-4xl text-white font-mono">
                {loading ? '...' : stats?.referralsCount || 0}
              </h3>
              <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-mono">{language === 'fr' ? 'Amis parrainés enregistrés' : 'Registered referred friends'}</p>
            </div>
          </div>

          {/* Card: Total USDC Earned from referrals */}
          <div className="bg-gray-950/40 backdrop-blur-md rounded-2xl p-6 border border-gray-900 bg-gradient-to-br from-gray-900/40 to-green-950/10 shadow-lg flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-gray-400 uppercase">{t('referrals.earning_label')}</span>
              <Coins className="text-green-400" size={18} />
            </div>
            <div>
              <h3 className="font-display font-bold text-4xl text-white font-mono text-glow-neon">
                {loading ? '...' : (stats?.totalEarnedUsdc || 0).toFixed(2)} <span className="text-brand-cyan text-sm">USDC</span>
              </h3>
              <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-mono">{language === 'fr' ? 'Gains accumulés retirables' : 'Accumulated withdrawable earnings'}</p>
            </div>
          </div>

        </div>

      </div>

      {/* Referred Users List Table */}
      <div className="bg-gray-950/40 border border-gray-900 rounded-2xl p-6 shadow-lg">
        <div className="pb-3 border-b border-gray-900 mb-4">
          <h3 className="font-display font-bold text-base text-white">{language === 'fr' ? 'Mes Filleuls Actifs' : 'My Active Invites'}</h3>
          <p className="text-xs text-gray-500 font-normal">{language === 'fr' ? 'Liste et statut des comptes que tu as invités' : 'List and status of accounts you have invited'}</p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-xs text-gray-600 font-mono">{t('common.loading')}</div>
        ) : !stats || stats.referredUsers.length === 0 ? (
          <div className="text-center py-12 text-xs text-gray-500 font-mono">
            {language === 'fr' ? "Aucun filleul actif pour le moment. Partage ton code d'invitation pour commencer à gagner !" : 'No active referrals yet. Share your invitation code to start earning!'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-gray-400">
              <thead>
                <tr className="border-b border-gray-900 text-[10px] uppercase font-mono tracking-wider text-gray-500">
                  <th className="py-3 px-4">{language === 'fr' ? "Nom de l'utilisateur" : 'Username'}</th>
                  <th className="py-3 px-4">{language === 'fr' ? 'Niveau actuel' : 'Current Level'}</th>
                  <th className="py-3 px-4">{language === 'fr' ? 'Date de ralliement' : 'Date Joined'}</th>
                  <th className="py-3 px-4 text-right">{language === 'fr' ? 'Commission versée' : 'Paid Commission'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-900/60">
                {stats.referredUsers.map((ref, idx) => (
                  <tr key={idx} className="hover:bg-white/2 transition">
                    <td className="py-3 px-4 font-semibold text-white flex items-center gap-2.5">
                      <div className="w-6.5 h-6.5 rounded-full bg-gray-900 border border-gray-800 flex items-center justify-center font-bold text-brand-cyan text-[10px]">
                        {ref.username.substring(0, 2).toUpperCase()}
                      </div>
                      <span>{ref.username}</span>
                    </td>
                    <td className="py-3 px-4 text-gray-300">
                      <span className="py-0.5 px-2 rounded bg-brand-cyan/10 text-brand-cyan font-mono text-[10px] font-bold">
                        LVL {ref.level}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-gray-500">
                      {new Date(ref.joinedAt).toLocaleDateString(t('header.time_format'), {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric'
                      })}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-green-400">
                      +{ref.earnedForReferrer.toFixed(2)} USDC
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
