import React, { useState, useEffect } from 'react';
import { Check, X, AlertCircle, Clock, Send, MessageSquare, CheckCircle2 } from 'lucide-react';
import { api } from '../lib/api';

export default function SubmissionsAdmin() {
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  
  // Feedback comment states
  const [comments, setComments] = useState<Record<string, string>>({});

  const fetchSubmissions = async () => {
    try {
      const res = await api.getAdminSubmissions();
      // Sort pending first, then newest
      const sorted = res.submissions.sort((a: any, b: any) => {
        if (a.status === 'pending' && b.status !== 'pending') return -1;
        if (a.status !== 'pending' && b.status === 'pending') return 1;
        return new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime();
      });
      setSubmissions(sorted);
    } catch (err) {
      console.error('Erreur admin submissions fetch', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubmissions();
  }, []);

  const handleProcessSubmission = async (id: string, action: 'approve' | 'reject') => {
    const comment = comments[id] || '';
    
    if (action === 'reject' && !comment.trim()) {
      alert('Veuillez saisir un commentaire expliquant le motif du rejet de la mission.');
      return;
    }

    const confirmation = window.confirm(`Voulez-vous vraiment ${action === 'approve' ? 'VALIDER' : 'REFUSER'} cette preuve de mission ?`);
    if (!confirmation) return;

    setProcessingId(id);
    try {
      await api.processSubmission(id, action, comment.trim());
      // Refresh submissions
      fetchSubmissions();
      // Clear comment
      setComments(prev => ({ ...prev, [id]: '' }));
    } catch (err: any) {
      alert(err.message || 'Erreur lors du traitement.');
    } finally {
      setProcessingId(null);
    }
  };

  const handleCommentChange = (id: string, value: string) => {
    setComments(prev => ({
      ...prev,
      [id]: value
    }));
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Title */}
      <div>
        <h2 className="font-display font-bold text-2xl text-white">Validation des Missions</h2>
        <p className="text-xs text-gray-400 font-normal">Contrôlez les justificatifs d'activité soumis par les membres de la plateforme. Approuvez pour verser les commissions ou refusez en fournissant un motif explicatif.</p>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-3">
          <div className="w-8 h-8 border-2 border-brand-cyan/20 border-t-brand-cyan rounded-full animate-spin" />
          <span className="text-xs text-gray-500 font-mono uppercase tracking-widest">Récupération des soumissions de preuves...</span>
        </div>
      ) : (
        <div className="glass-card rounded-2xl p-6 border border-gray-800/80 shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-gray-400">
              <thead>
                <tr className="border-b border-gray-900 text-[10px] uppercase font-mono tracking-wider text-gray-500">
                  <th className="py-3.5 px-4">Utilisateur</th>
                  <th className="py-3.5 px-4">Mission concernée</th>
                  <th className="py-3.5 px-4">Justificatif fourni</th>
                  <th className="py-3.5 px-4">Date d'envoi</th>
                  <th className="py-3.5 px-4">Statut</th>
                  <th className="py-3.5 px-4 text-center">Évaluation administrative</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-900/60">
                {submissions.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-12 text-gray-600 font-mono">
                      Aucune preuve soumise enregistrée.
                    </td>
                  </tr>
                ) : (
                  submissions.map((sub) => (
                    <tr key={sub.id} className={`hover:bg-white/2 transition ${sub.status === 'pending' ? 'bg-yellow-500/2' : ''}`}>
                      
                      {/* User details */}
                      <td className="py-3.5 px-4">
                        <p className="font-semibold text-white truncate">{sub.user ? sub.user.username : 'Utilisateur Supprimé'}</p>
                        <p className="text-[10px] text-gray-500 font-mono">{sub.user ? sub.user.email : ''}</p>
                      </td>

                      {/* Mission details */}
                      <td className="py-3.5 px-4 max-w-xs">
                        <p className="font-semibold text-white leading-tight">{sub.mission ? sub.mission.title : 'Mission Supprimée'}</p>
                        <div className="flex items-center gap-1.5 mt-0.5 text-[10px] font-mono font-bold text-gray-500">
                          <span className="text-green-400">+{sub.mission?.rewardUsdc.toFixed(2)} USDC</span>
                          <span>/</span>
                          <span className="text-brand-cyan">+{sub.mission?.rewardXp} XP</span>
                        </div>
                      </td>

                      {/* Proof string */}
                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="bg-gray-950 border border-gray-900 rounded-lg p-2.5 font-mono text-[11px] text-gray-300 break-all select-all">
                          {sub.proofText}
                        </div>
                      </td>

                      {/* Submit Date */}
                      <td className="py-3.5 px-4 font-mono text-[11px] text-gray-500">
                        {new Date(sub.submittedAt).toLocaleString('fr-FR')}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        <span className={`py-1 px-2.5 rounded-lg text-[9px] font-bold uppercase tracking-wider ${
                          sub.status === 'approved' ? 'bg-green-950/40 border border-green-500/20 text-green-400' :
                          sub.status === 'rejected' ? 'bg-red-950/40 border border-red-500/20 text-red-400' :
                          'bg-yellow-950/40 border border-yellow-500/20 text-yellow-400 animate-pulse'
                        }`}>
                          {sub.status === 'approved' ? 'Validée' :
                           sub.status === 'rejected' ? 'Refusée' : 'En attente'}
                        </span>
                      </td>

                      {/* Action verification */}
                      <td className="py-3.5 px-4">
                        {sub.status === 'pending' ? (
                          <div className="flex flex-col gap-2 min-w-[200px]">
                            
                            {/* Feedback comment input */}
                            <div className="relative">
                              <input
                                type="text"
                                placeholder="Commentaire / Motif de refus..."
                                value={comments[sub.id] || ''}
                                onChange={(e) => handleCommentChange(sub.id, e.target.value)}
                                className="w-full bg-gray-950 border border-gray-900 rounded-lg px-2.5 py-1.5 text-[11px] text-white placeholder-gray-600 focus:outline-none focus:border-brand-cyan"
                              />
                            </div>

                            <div className="flex gap-2">
                              {/* Approve action */}
                              <button
                                onClick={() => handleProcessSubmission(sub.id, 'approve')}
                                disabled={processingId !== null}
                                id={`approve-submission-btn-${sub.id}`}
                                className="flex-1 py-1.5 px-3.5 rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold text-[11px] transition flex items-center justify-center gap-1 cursor-pointer disabled:opacity-40"
                              >
                                <Check size={12} />
                                <span>Valider</span>
                              </button>

                              {/* Reject action */}
                              <button
                                onClick={() => handleProcessSubmission(sub.id, 'reject')}
                                disabled={processingId !== null}
                                id={`reject-submission-btn-${sub.id}`}
                                className="flex-1 py-1.5 px-3.5 rounded-lg bg-red-950/30 hover:bg-red-950/50 border border-red-900/40 text-red-400 font-bold text-[11px] transition flex items-center justify-center gap-1 cursor-pointer disabled:opacity-40"
                              >
                                <X size={12} />
                                <span>Refuser</span>
                              </button>
                            </div>

                          </div>
                        ) : (
                          <div className="text-center font-mono text-[10px] text-gray-500">
                            {sub.adminComment ? (
                              <p className="italic max-w-xs mx-auto break-words">"{sub.adminComment}"</p>
                            ) : (
                              <span>Validé le {new Date(sub.processedAt || '').toLocaleDateString('fr-FR')}</span>
                            )}
                          </div>
                        )}
                      </td>

                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
}
