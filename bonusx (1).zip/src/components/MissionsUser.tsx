import React, { useState, useEffect, useRef } from 'react';
import { 
  Zap, 
  Coins, 
  Clock, 
  ArrowRight, 
  AlertCircle, 
  CheckCircle2, 
  HelpCircle,
  TrendingUp,
  Award,
  ArrowUpRight,
  Sparkles,
  Gamepad2,
  Brain,
  HelpCircle as QuizIcon,
  ChevronRight,
  TrendingDown,
  RotateCcw,
  Trophy
} from 'lucide-react';
import { User } from '../types';
import { api } from '../lib/api';
import { useLanguage } from '../lib/LanguageContext';
import { BtcIcon, UsdtIcon, EthIcon, SolIcon } from './CryptoIcons';

interface MissionsUserProps {
  user: User;
  onTriggerNotificationRefresh: () => void;
  onNavigate?: (menuId: string) => void;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  delay: number;
  type: 'BTC' | 'USDT' | 'ETH' | 'SOL';
}

const QUIZ_QUESTIONS = [
  {
    question_fr: "Quelle est la blockchain principale recommandée par BonusX pour des retraits instantanés à frais réduits ?",
    question_en: "Which main blockchain is recommended by BonusX for instant, low-fee withdrawals?",
    options: [
      "Bitcoin (Réseau natif)", 
      "Ethereum (ERC20)", 
      "Polygon (USDT/USDC Matic)"
    ],
    correct: 2,
    explanation_fr: "Polygon est une solution de mise à l'échelle (Layer 2) d'Ethereum qui permet d'envoyer des USDT et USDC en quelques secondes pour moins de $0.05 de frais !",
    explanation_en: "Polygon is an Ethereum Layer 2 scaling solution that lets you cash out USDT and USDC in seconds with gas fees below $0.05!"
  },
  {
    question_fr: "Qu'est-ce qu'une phrase de récupération secrète (Seed Phrase) dans un portefeuille crypto ?",
    question_en: "What is a recovery seed phrase in a crypto wallet?",
    options: [
      "Un mot de passe pour réinitialiser son adresse e-mail", 
      "Une suite de 12 à 24 mots confidentiels donnant le contrôle total sur vos fonds (à ne JAMAIS partager)", 
      "Une phrase d'accueil configurée par le service client"
    ],
    correct: 1,
    explanation_fr: "La phrase de récupération est la clé maîtresse de vos cryptomonnaies. Toute personne qui la possède peut accéder à vos fonds. Ne la partagez JAMAIS !",
    explanation_en: "The seed phrase is the master key to your crypto assets. Anyone who knows it can take all your funds. NEVER share it with anyone!"
  },
  {
    question_fr: "Que signifie le terme d'argot Web3 'HODL' ?",
    question_en: "What does the Web3 slang term 'HODL' stand for?",
    options: [
      "Conserver ses cryptomonnaies à long terme malgré les fluctuations du marché", 
      "Vendre toutes ses positions en urgence en cas de baisse", 
      "Acheter une crypto-monnaie par peur de rater l'opportunité (FOMO)"
    ],
    correct: 0,
    explanation_fr: "HODL provient d'une faute d'orthographe légendaire de 'HOLD' sur un forum de Bitcoin en 2013. C'est aujourd'hui le symbole de la patience à long terme.",
    explanation_en: "HODL originated from a legendary misspelling of 'HOLD' on a Bitcoin forum back in 2013. It now symbolizes long-term investing patience."
  }
];

export default function MissionsUser({
  user: initialUser,
  onTriggerNotificationRefresh,
  onNavigate
}: MissionsUserProps) {
  const { t, language } = useLanguage();
  const [currentUser, setCurrentUser] = useState<User>(initialUser);
  
  // Navigation Section (Tabs)
  const [activeSection, setActiveSection] = useState<'mining' | 'retention'>('mining');
  
  // Multi-Gauges State
  const [loading, setLoading] = useState(true);
  const [gaugesState, setGaugesState] = useState<Record<string, { progress: number; timeLeftSeconds: number }>>({
    USDT: { progress: 0, timeLeftSeconds: 0 },
    BTC: { progress: 0, timeLeftSeconds: 0 },
    ETH: { progress: 0, timeLeftSeconds: 0 },
    SOL: { progress: 0, timeLeftSeconds: 0 }
  });
  const [lastGaugeClaims, setLastGaugeClaims] = useState<Record<string, string>>({});
  const [settings, setSettings] = useState({ durationMinutes: 10, rewardAmount: 1.50, xpReward: 50 });
  
  // Claim states
  const [claimingCur, setClaimingCur] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [claimSuccess, setClaimSuccess] = useState<any | null>(null);
  
  // Particles animation state
  const [particles, setParticles] = useState<Particle[]>([]);
  const particleIdCounter = useRef(0);

  // RETENTION TASK 1: Lucky Spin Wheel
  const [spinning, setSpinning] = useState(false);
  const [spinError, setSpinError] = useState('');
  const [spinResult, setSpinResult] = useState<any | null>(null);
  const [rotationDegrees, setRotationDegrees] = useState(0);
  const [lastSpinTime, setLastSpinTime] = useState<string>(currentUser.lastSpinAt || '');
  const [spinCooldownTimeLeft, setSpinCooldownTimeLeft] = useState(0);

  // RETENTION TASK 2: Daily Quiz Web3
  const [quizDone, setQuizDone] = useState(false);
  const [lastQuizTime, setLastQuizTime] = useState<string>(currentUser.lastQuizAt || '');
  const [currentQuizStep, setCurrentQuizStep] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [quizAnswered, setQuizAnswered] = useState(false);
  const [quizFinished, setQuizFinished] = useState(false);
  const [quizReward, setQuizReward] = useState<any | null>(null);
  const [quizAnswersSubmitted, setQuizAnswersSubmitted] = useState<boolean[]>([]);
  const [quizLoading, setQuizLoading] = useState(false);
  const [quizError, setQuizError] = useState('');
  const [quizCooldownTimeLeft, setQuizCooldownTimeLeft] = useState(0);

  // RETENTION TASK 3: Predict BTC Price UP/DOWN
  const [btcLivePrice, setBtcLivePrice] = useState(64320.50);
  const [predictDirection, setPredictDirection] = useState<'UP' | 'DOWN' | null>(null);
  const [predicting, setPredicting] = useState(false);
  const [predictError, setPredictError] = useState('');
  const [predictSuccess, setPredictSuccess] = useState(false);
  
  // Pending prediction states
  const [userPredictionChoice, setUserPredictionChoice] = useState<'UP' | 'DOWN' | null>(currentUser.predictionChoice || null);
  const [userPredictionBtcPrice, setUserPredictionBtcPrice] = useState<number>(currentUser.predictionBtcPrice || 0);
  const [userPredictionResult, setUserPredictionResult] = useState<'pending' | 'won' | 'lost' | null>(currentUser.predictionResult || null);
  const [lastPredictAt, setLastPredictAt] = useState<string>(currentUser.lastPredictionAt || '');
  const [predictRemainingSeconds, setPredictRemainingSeconds] = useState(0);
  const [verifyingPredict, setVerifyingPredict] = useState(false);
  const [verifyResult, setVerifyResult] = useState<any | null>(null);

  // Fetch initial profile/gauge states
  const fetchGaugeState = async () => {
    try {
      const res = await api.getGaugeState();
      setSettings(res.settings);
      if (res.gauges) {
        setGaugesState(res.gauges);
        const claims: Record<string, string> = {};
        Object.keys(res.gauges).forEach(k => {
          claims[k] = res.gauges[k].lastClaimAt;
        });
        setLastGaugeClaims(claims);
      } else {
        // Fallback to legacy
        setGaugesState({
          USDT: { progress: res.progress, timeLeftSeconds: res.timeLeftSeconds },
          BTC: { progress: res.progress, timeLeftSeconds: res.timeLeftSeconds },
          ETH: { progress: 0, timeLeftSeconds: 0 },
          SOL: { progress: 0, timeLeftSeconds: 0 }
        });
      }
      
      // Update local user state
      const me = await api.me();
      if (me.user) {
        setCurrentUser(me.user);
        setLastSpinTime(me.user.lastSpinAt || '');
        setLastQuizTime(me.user.lastQuizAt || '');
        setUserPredictionChoice(me.user.predictionChoice || null);
        setUserPredictionBtcPrice(me.user.predictionBtcPrice || 0);
        setUserPredictionResult(me.user.predictionResult || null);
        setLastPredictAt(me.user.lastPredictionAt || '');
      }
    } catch (err) {
      console.error('Erreur fetchGaugeState', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGaugeState();
  }, [initialUser]);

  // Simulated live ticking BTC Price Feed for the Predictor game
  useEffect(() => {
    const timer = setInterval(() => {
      setBtcLivePrice(prev => {
        const volatility = (Math.random() - 0.5) * 16; // fluctuations
        return Number((prev + volatility).toFixed(2));
      });
    }, 2500);
    return () => clearInterval(timer);
  }, []);

  // Live countdown for gauges refilling
  useEffect(() => {
    if (loading || !lastGaugeClaims) return;

    const interval = setInterval(() => {
      const updated: typeof gaugesState = {};
      const currencies = ['USDT', 'BTC', 'ETH', 'SOL'];
      currencies.forEach(cur => {
        const lastClaimAt = lastGaugeClaims[cur] || new Date(Date.now() - settings.durationMinutes * 60 * 1000).toISOString();
        const lastClaimTime = new Date(lastClaimAt).getTime();
        const elapsedSeconds = (Date.now() - lastClaimTime) / 1000;
        const totalSeconds = settings.durationMinutes * 60;
        
        const progress = Math.min(100, Math.floor((elapsedSeconds / totalSeconds) * 100));
        const timeLeftSeconds = Math.max(0, Math.floor(totalSeconds - elapsedSeconds));
        updated[cur] = { progress, timeLeftSeconds };
      });
      setGaugesState(updated);
    }, 1000);

    return () => clearInterval(interval);
  }, [loading, lastGaugeClaims, settings.durationMinutes]);

  // Spin Wheel Cooldown Tracker
  useEffect(() => {
    if (!lastSpinTime) {
      setSpinCooldownTimeLeft(0);
      return;
    }
    const interval = setInterval(() => {
      const COOLDOWN = 12 * 3600 * 1000; // 12 hours
      const elapsed = Date.now() - new Date(lastSpinTime).getTime();
      const left = Math.max(0, Math.floor((COOLDOWN - elapsed) / 1000));
      setSpinCooldownTimeLeft(left);
      if (left === 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [lastSpinTime]);

  // Quiz Cooldown Tracker
  useEffect(() => {
    if (!lastQuizTime) {
      setQuizCooldownTimeLeft(0);
      setQuizDone(false);
      return;
    }
    const interval = setInterval(() => {
      const COOLDOWN = 24 * 3600 * 1000; // 24 hours
      const elapsed = Date.now() - new Date(lastQuizTime).getTime();
      const left = Math.max(0, Math.floor((COOLDOWN - elapsed) / 1000));
      setQuizCooldownTimeLeft(left);
      setQuizDone(left > 0);
      if (left === 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [lastQuizTime]);

  // Predictor Countdown Timer
  useEffect(() => {
    if (userPredictionResult !== 'pending' || !lastPredictAt) {
      setPredictRemainingSeconds(0);
      return;
    }
    const interval = setInterval(() => {
      const waitTime = 15 * 1000; // 15 seconds wait time for immediate feedback
      const elapsed = Date.now() - new Date(lastPredictAt).getTime();
      const remaining = Math.max(0, Math.floor((waitTime - elapsed) / 1000));
      setPredictRemainingSeconds(remaining);
      if (remaining === 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [userPredictionResult, lastPredictAt]);

  // Spawn coin animation particles
  const spawnParticles = (type: 'BTC' | 'USDT' | 'ETH' | 'SOL') => {
    const newParticles: Particle[] = [];
    for (let i = 0; i < 20; i++) {
      newParticles.push({
        id: particleIdCounter.current++,
        x: (Math.random() - 0.5) * 280, // Spread width wise
        y: -40 - Math.random() * 80, // Start above button
        size: Math.floor(16 + Math.random() * 16),
        delay: Math.random() * 0.5,
        type
      });
    }
    setParticles(newParticles);
    
    // Clear particles after 3 seconds
    setTimeout(() => {
      setParticles([]);
    }, 3000);
  };

  // Claim specific Gauge reward
  const handleClaimGauge = async (currency: 'USDT' | 'BTC' | 'ETH' | 'SOL') => {
    if (gaugesState[currency].progress < 100) {
      setErrorMsg(language === 'fr' 
        ? "Cette jauge n'est pas encore remplie. Veuillez attendre la fin du compte à rebours." 
        : "This gauge is not 100% full yet. Please wait for the countdown to complete."
      );
      return;
    }

    setClaimingCur(currency);
    setErrorMsg('');
    setClaimSuccess(null);

    try {
      const res = await api.claimGauge(currency);
      if (res.success) {
        spawnParticles(currency);
        setClaimSuccess({
          amount: res.claimedAmount,
          xp: res.xpGranted,
          leveledUp: res.leveledUp,
          levelUpReward: res.levelUpReward,
          currency: res.currency
        });
        
        onTriggerNotificationRefresh();
        
        setTimeout(() => {
          fetchGaugeState();
        }, 1200);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Une erreur est survenue.');
    } finally {
      setClaimingCur(null);
    }
  };

  // SPIN WHEEL Action
  const handleLuckySpin = async () => {
    if (spinCooldownTimeLeft > 0 || spinning) return;
    setSpinning(true);
    setSpinError('');
    setSpinResult(null);

    try {
      const res = await api.dailySpin();
      if (res.success) {
        // Each sector of the 8 slices is 45 degrees. 
        // Index: 0 -> +0.10 USDT, 1 -> +15 XP, 2 -> +0.25 USDT, 3 -> +30 XP, etc.
        // Target rotation = multiple spins (e.g. 10 spins = 3600 deg) + offset to align arrow pointing to winning slice.
        // Slice angles: Index 0 is [0 to 45], Index 1 is [45 to 90], etc.
        const baseSpins = 2880; // 8 full spins
        const prizeAngle = (res.rewardIndex * 45) + 22.5; // center of slice
        const totalDeg = baseSpins + (360 - prizeAngle); // Spin clockwise to land correctly

        setRotationDegrees(totalDeg);

        // Wait for CSS animation to complete (4 seconds)
        setTimeout(() => {
          setSpinning(false);
          setSpinResult({
            label: res.label,
            type: res.rewardType,
            val: res.rewardVal,
            leveledUp: res.leveledUp,
            levelUpReward: res.levelUpReward
          });
          setLastSpinTime(res.user.lastSpinAt);
          
          // Refresh user balance and notifications
          onTriggerNotificationRefresh();
          fetchGaugeState();
        }, 4100);
      }
    } catch (err: any) {
      setSpinError(err.message || 'Erreur lors du lancer de la roue.');
      setSpinning(false);
    }
  };

  // QUIZ Answer selection & validate
  const handleQuizAnswerSelect = (index: number) => {
    if (quizAnswered) return;
    setSelectedAnswer(index);
  };

  const handleValidateQuizStep = () => {
    if (selectedAnswer === null) return;
    
    const isCorrect = selectedAnswer === QUIZ_QUESTIONS[currentQuizStep].correct;
    if (isCorrect) {
      setQuizScore(prev => prev + 1);
    }
    setQuizAnswersSubmitted(prev => [...prev, isCorrect]);
    setQuizAnswered(true);
  };

  const handleNextQuizQuestion = () => {
    if (currentQuizStep < QUIZ_QUESTIONS.length - 1) {
      setCurrentQuizStep(prev => prev + 1);
      setSelectedAnswer(null);
      setQuizAnswered(false);
    } else {
      setQuizFinished(true);
      submitQuizResults();
    }
  };

  const submitQuizResults = async () => {
    setQuizLoading(true);
    setQuizError('');
    try {
      const finalScore = quizScore + (selectedAnswer === QUIZ_QUESTIONS[currentQuizStep].correct ? 1 : 0);
      const res = await api.dailyQuiz(finalScore);
      if (res.success) {
        setQuizReward({
          score: res.score,
          rewardUsdt: res.rewardUsdt,
          rewardXp: res.rewardXp,
          leveledUp: res.leveledUp,
          levelUpReward: res.levelUpReward
        });
        setLastQuizTime(res.user.lastQuizAt);
        onTriggerNotificationRefresh();
        fetchGaugeState();
      }
    } catch (err: any) {
      setQuizError(err.message || 'Erreur lors de la validation du quiz.');
    } finally {
      setQuizLoading(false);
    }
  };

  const resetQuizUI = () => {
    setCurrentQuizStep(0);
    setSelectedAnswer(null);
    setQuizScore(0);
    setQuizAnswered(false);
    setQuizFinished(false);
    setQuizReward(null);
  };

  // BTC PREDICTOR Actions
  const handleBtcPredict = async (direction: 'UP' | 'DOWN') => {
    if (userPredictionResult === 'pending' || predicting) return;
    setPredicting(true);
    setPredictError('');
    setPredictSuccess(false);

    try {
      const res = await api.dailyPredict(direction, btcLivePrice);
      if (res.success) {
        setUserPredictionChoice(direction);
        setUserPredictionBtcPrice(btcLivePrice);
        setUserPredictionResult('pending');
        setLastPredictAt(res.user.lastPredictionAt);
        setPredictSuccess(true);
        onTriggerNotificationRefresh();
      }
    } catch (err: any) {
      setPredictError(err.message || 'Erreur lors de la prédiction.');
    } finally {
      setPredicting(false);
    }
  };

  const handleVerifyPredict = async () => {
    if (predictRemainingSeconds > 0 || verifyingPredict) return;
    setVerifyingPredict(true);
    setPredictError('');
    setVerifyResult(null);

    try {
      const res = await api.verifyPredict();
      if (res.success) {
        setVerifyResult({
          result: res.result,
          initialPrice: res.initialPrice,
          finalPrice: res.finalPrice,
          rewardUsdt: res.rewardUsdt,
          rewardXp: res.rewardXp,
          leveledUp: res.leveledUp,
          levelUpReward: res.levelUpReward
        });
        setUserPredictionResult(res.result);
        onTriggerNotificationRefresh();
        fetchGaugeState();
      }
    } catch (err: any) {
      setPredictError(err.message || 'Erreur lors de la vérification.');
    } finally {
      setVerifyingPredict(false);
    }
  };

  // Formatter helpers
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatCooldown = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hrs.toString().padStart(2, '0')}h ${mins.toString().padStart(2, '0')}m ${secs.toString().padStart(2, '0')}s`;
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* 3D coin float animations injected */}
      <style>{`
        @keyframes float-coin {
          0% {
            transform: translate3d(0, 0, 0) scale(0.4) rotate(0deg);
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 0.9;
          }
          100% {
            transform: translate3d(var(--x-dir), var(--y-dir), 0) scale(1.4) rotate(var(--rotate-dir));
            opacity: 0;
          }
        }
        .animate-coin-particle {
          animation: float-coin 1.8s cubic-bezier(0.1, 0.75, 0.25, 1) forwards;
        }
      `}</style>

      {/* Hero Header with Navigation Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-gray-900 pb-6">
        <div>
          <h2 className="font-display font-black text-2xl text-white flex items-center gap-2">
            <Zap className="text-brand-cyan animate-pulse" size={24} />
            <span>
              {language === 'fr' ? 'Générateurs & Tâches Web3' : 'Generators & Web3 Tasks'}
            </span>
          </h2>
          <p className="text-xs text-gray-400 mt-1 max-w-xl">
            {language === 'fr' 
              ? 'Miner vos crypto-actifs favoris et complétez les activités quotidiennes sur-place pour maximiser vos gains sans jamais quitter la plateforme.'
              : 'Mine your favorite crypto assets and complete daily on-site challenges to maximize rewards without ever leaving the platform.'}
          </p>
        </div>

        {/* Dynamic Nav Switches */}
        <div className="flex bg-gray-950 p-1 rounded-2xl border border-gray-900 self-start md:self-auto shrink-0 shadow-lg">
          <button
            onClick={() => setActiveSection('mining')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
              activeSection === 'mining'
                ? 'bg-gradient-to-r from-brand-blue/30 to-brand-cyan/20 border border-brand-cyan/30 text-white shadow-inner'
                : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            <Coins size={14} className={activeSection === 'mining' ? 'text-brand-cyan' : ''} />
            <span>{language === 'fr' ? '🔋 Mines de Crypto' : '🔋 Crypto Mining'}</span>
          </button>
          
          <button
            onClick={() => setActiveSection('retention')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
              activeSection === 'retention'
                ? 'bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 text-white shadow-inner'
                : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            <Gamepad2 size={14} className={activeSection === 'retention' ? 'text-purple-400 animate-bounce' : ''} />
            <span>{language === 'fr' ? '🎡 Tâches Quotidiennes' : '🎡 Daily Quests'}</span>
          </button>
        </div>
      </div>

      {/* Particle container for claiming explosions */}
      <div className="absolute inset-0 pointer-events-none z-50 flex items-center justify-center">
        {particles.map((p) => {
          return (
            <div
              key={p.id}
              className="absolute font-display font-black flex items-center justify-center select-none rounded-full animate-coin-particle border overflow-hidden"
              style={{
                '--x-dir': `${p.x}px`,
                '--y-dir': `${p.y - 120}px`,
                '--rotate-dir': `${Math.random() > 0.5 ? 360 : -360}deg`,
                left: `calc(50% + ${p.x * 0.1}px)`,
                top: '40%',
                width: `${p.size}px`,
                height: `${p.size}px`,
                animationDelay: `${p.delay}s`,
                backgroundColor: p.type === 'BTC' ? 'rgba(247, 147, 26, 0.15)' : p.type === 'USDT' ? 'rgba(38, 161, 123, 0.15)' : p.type === 'ETH' ? 'rgba(98, 126, 234, 0.15)' : 'rgba(20, 241, 149, 0.15)',
                borderColor: p.type === 'BTC' ? '#f7931a' : p.type === 'USDT' ? '#26a17b' : p.type === 'ETH' ? '#627eea' : '#14f195',
                boxShadow: p.type === 'BTC' ? '0 0 12px rgba(247, 147, 26, 0.4)' : p.type === 'USDT' ? '0 0 12px rgba(38, 161, 123, 0.4)' : p.type === 'ETH' ? '0 0 12px rgba(98, 126, 234, 0.4)' : '0 0 12px rgba(20, 241, 149, 0.4)',
              } as React.CSSProperties}
            >
              {p.type === 'BTC' && <BtcIcon size={p.size} />}
              {p.type === 'USDT' && <UsdtIcon size={p.size} />}
              {p.type === 'ETH' && <EthIcon size={p.size} />}
              {p.type === 'SOL' && <SolIcon size={p.size} />}
            </div>
          );
        })}
      </div>

      {/* Global Notifications for errors/claims */}
      {errorMsg && (
        <div className="p-4 rounded-xl bg-red-950/20 border border-red-500/30 flex items-center gap-2.5 text-xs text-red-400 shadow-md">
          <AlertCircle size={16} className="shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {claimSuccess && (
        <div className="p-5 rounded-2xl bg-green-950/25 border border-green-500/30 text-center space-y-2 shadow-lg max-w-2xl mx-auto animate-fade-in relative overflow-hidden">
          <div className="absolute inset-0 bg-green-500/5 blur-xl pointer-events-none" />
          <div className="flex items-center justify-center gap-2 text-green-400 font-bold text-sm">
            <CheckCircle2 size={18} className="animate-bounce" />
            <span>{language === 'fr' ? 'Générateur Réclamé avec Succès !' : 'Generator Claimed Successfully!'}</span>
          </div>
          <p className="text-xs text-gray-300">
            {language === 'fr' ? (
              <>
                Excellent ! Vous avez récolté <span className="text-green-400 font-bold">+{claimSuccess.amount.toFixed(2)} USDT</span> crédité sous forme de{" "}
                <span className="inline-flex items-center gap-1 font-bold text-white bg-gray-900 px-2 py-0.5 rounded-md border border-gray-800">
                  {claimSuccess.currency === 'BTC' ? <BtcIcon size={14} /> : claimSuccess.currency === 'ETH' ? <EthIcon size={14} /> : claimSuccess.currency === 'SOL' ? <SolIcon size={14} /> : <UsdtIcon size={14} />} {claimSuccess.currency}
                </span>{" "}
                et <span className="text-brand-cyan font-bold">+{claimSuccess.xp} XP</span> !
              </>
            ) : (
              <>
                Fabulous! You collected <span className="text-green-400 font-bold">+{claimSuccess.amount.toFixed(2)} USDT</span> credited as{" "}
                <span className="inline-flex items-center gap-1 font-bold text-white bg-gray-900 px-2 py-0.5 rounded-md border border-gray-800">
                  {claimSuccess.currency === 'BTC' ? <BtcIcon size={14} /> : claimSuccess.currency === 'ETH' ? <EthIcon size={14} /> : claimSuccess.currency === 'SOL' ? <SolIcon size={14} /> : <UsdtIcon size={14} />} {claimSuccess.currency}
                </span>{" "}
                and <span className="text-brand-cyan font-bold">+{claimSuccess.xp} XP</span>!
              </>
            )}
          </p>
          {claimSuccess.leveledUp && (
            <div className="p-3 rounded-xl bg-gradient-to-r from-yellow-950/30 to-amber-950/30 border border-yellow-500/30 text-[11px] text-yellow-400 mt-2 flex flex-col items-center gap-0.5 mx-auto max-w-md animate-pulse">
              <span className="font-black tracking-wider uppercase flex items-center gap-1">
                🏆 NIVEAU SUPÉRIEUR ATTEINT !
              </span>
              <span>
                {language === 'fr' 
                  ? `Tu passes au niveau supérieur et gagnes +${claimSuccess.levelUpReward} USDC de bonus !`
                  : `You reached a new level and unlocked a +${claimSuccess.levelUpReward} USDC bonus reward!`}
              </span>
            </div>
          )}
        </div>
      )}

      {/* SECTION 1: MINING GAUGE CARDS */}
      {activeSection === 'mining' && (
        <div className="space-y-6">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-24 gap-3">
              <div className="w-8 h-8 border-2 border-brand-cyan/20 border-t-brand-cyan rounded-full animate-spin" />
              <span className="text-xs text-gray-500 font-mono uppercase tracking-widest">
                {language === 'fr' ? 'Initialisation des générateurs...' : 'Initializing generators...'}
              </span>
            </div>
          ) : (
            <>
              {/* Informative alert */}
              <div className="bg-gray-950/30 border border-gray-900 rounded-2xl p-4 flex items-start gap-3 max-w-4xl">
                <Sparkles className="text-brand-cyan shrink-0 mt-0.5 animate-pulse" size={16} />
                <div className="text-xs text-gray-400 leading-relaxed">
                  {language === 'fr'
                    ? "Les jauges se rechargent simultanément en arrière-plan. Dès qu'une jauge affiche 100%, récoltez vos gains immédiatement pour relancer la production du mineur. Les gains sont directement versés sur votre solde de gains USDT."
                    : "Gauges refill simultaneously in the background. As soon as a gauge reaches 100%, collect your earnings instantly to resume mining. Earnings are added directly to your USDT withdrawable balance."}
                </div>
              </div>

              {/* 4-Card Responsive Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                
                {/* CARD 1: USDT (Tether) */}
                <div className={`relative bg-gray-950/45 border rounded-3xl p-6 flex flex-col justify-between overflow-hidden transition-all duration-500 group min-h-[340px] shadow-xl ${
                  gaugesState['USDT'].progress === 100
                    ? 'border-green-500/50 shadow-[0_0_20px_rgba(34,197,94,0.15)] bg-green-950/5'
                    : 'border-gray-900 hover:border-gray-800'
                }`}>
                  {/* Decorative background logo */}
                  <div className="absolute -bottom-10 -right-10 opacity-5 pointer-events-none group-hover:scale-110 transition duration-500">
                    <UsdtIcon size={160} />
                  </div>

                  {/* Top card header */}
                  <div className="flex justify-between items-start z-10">
                    <div className="flex items-center gap-3">
                      <UsdtIcon size={36} className="rounded-xl shadow-lg shadow-green-500/10" />
                      <div>
                        <h4 className="font-display font-bold text-sm text-white">USDT</h4>
                        <p className="text-[10px] text-gray-500 font-mono font-bold">Stablecoin Dollar</p>
                      </div>
                    </div>
                    {gaugesState['USDT'].progress === 100 ? (
                      <span className="py-0.5 px-2 rounded-full bg-green-500/15 border border-green-500/30 text-[9px] font-mono font-bold text-green-400 uppercase tracking-wider animate-pulse">
                        READY
                      </span>
                    ) : (
                      <span className="py-0.5 px-2 rounded-full bg-gray-900 border border-gray-800 text-[9px] font-mono font-bold text-gray-500 uppercase tracking-wider">
                        MINING
                      </span>
                    )}
                  </div>

                  {/* Middle circular loader */}
                  <div className="my-6 flex flex-col items-center justify-center z-10 relative">
                    <div className="relative w-28 h-28 flex items-center justify-center">
                      <svg className="w-24 h-24 transform -rotate-90">
                        <circle cx="48" cy="48" r="40" className="stroke-gray-900 fill-none" strokeWidth="5" />
                        <circle 
                          cx="48" 
                          cy="48" 
                          r="40" 
                          className={`fill-none transition-all duration-1000 stroke-current ${
                            gaugesState['USDT'].progress === 100 ? 'text-green-500' : 'text-brand-blue'
                          }`} 
                          strokeWidth="6" 
                          strokeDasharray={2 * Math.PI * 40}
                          strokeDashoffset={2 * Math.PI * 40 * (1 - gaugesState['USDT'].progress / 100)}
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute text-center">
                        <span className="block font-display font-black text-xl text-white tracking-tight">
                          {gaugesState['USDT'].progress}%
                        </span>
                        <span className="block text-[8px] font-mono text-gray-500 uppercase tracking-wider">
                          {gaugesState['USDT'].progress === 100 ? (
                            <span className="text-green-400 font-bold">COMPLET</span>
                          ) : (
                            formatTime(gaugesState['USDT'].timeLeftSeconds)
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Bottom info & action */}
                  <div className="space-y-4 z-10">
                    <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                      <span>Rendement :</span>
                      <span className="text-white font-bold">+{settings.rewardAmount.toFixed(2)} USDT</span>
                    </div>

                    <button
                      onClick={() => handleClaimGauge('USDT')}
                      disabled={gaugesState['USDT'].progress < 100 || claimingCur !== null}
                      className={`w-full py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer ${
                        gaugesState['USDT'].progress === 100
                          ? 'bg-green-500 text-gray-950 hover:brightness-110 shadow-[0_0_12px_rgba(34,197,94,0.4)]'
                          : 'bg-gray-900 text-gray-600 border border-gray-800 cursor-not-allowed'
                      }`}
                    >
                      {claimingCur === 'USDT' ? (
                        <div className="w-4 h-4 border-2 border-gray-950/30 border-t-gray-950 rounded-full animate-spin" />
                      ) : (
                        <>
                          <Coins size={14} />
                          <span>{language === 'fr' ? 'Récolter USDT' : 'Harvest USDT'}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* CARD 2: BTC (Bitcoin) */}
                <div className={`relative bg-gray-950/45 border rounded-3xl p-6 flex flex-col justify-between overflow-hidden transition-all duration-500 group min-h-[340px] shadow-xl ${
                  gaugesState['BTC'].progress === 100
                    ? 'border-amber-500/50 shadow-[0_0_20px_rgba(245,158,11,0.15)] bg-amber-950/5'
                    : 'border-gray-900 hover:border-gray-800'
                }`}>
                  <div className="absolute -bottom-10 -right-10 opacity-5 pointer-events-none group-hover:scale-110 transition duration-500">
                    <BtcIcon size={160} />
                  </div>

                  <div className="flex justify-between items-start z-10">
                    <div className="flex items-center gap-3">
                      <BtcIcon size={36} className="rounded-xl shadow-lg shadow-amber-500/10" />
                      <div>
                        <h4 className="font-display font-bold text-sm text-white">BTC</h4>
                        <p className="text-[10px] text-gray-500 font-mono font-bold">Or Numérique</p>
                      </div>
                    </div>
                    {gaugesState['BTC'].progress === 100 ? (
                      <span className="py-0.5 px-2 rounded-full bg-amber-500/15 border border-amber-500/30 text-[9px] font-mono font-bold text-amber-400 uppercase tracking-wider animate-pulse">
                        READY
                      </span>
                    ) : (
                      <span className="py-0.5 px-2 rounded-full bg-gray-900 border border-gray-800 text-[9px] font-mono font-bold text-gray-500 uppercase tracking-wider">
                        MINING
                      </span>
                    )}
                  </div>

                  <div className="my-6 flex flex-col items-center justify-center z-10 relative">
                    <div className="relative w-28 h-28 flex items-center justify-center">
                      <svg className="w-24 h-24 transform -rotate-90">
                        <circle cx="48" cy="48" r="40" className="stroke-gray-900 fill-none" strokeWidth="5" />
                        <circle 
                          cx="48" 
                          cy="48" 
                          r="40" 
                          className={`fill-none transition-all duration-1000 stroke-current ${
                            gaugesState['BTC'].progress === 100 ? 'text-amber-500' : 'text-brand-blue'
                          }`} 
                          strokeWidth="6" 
                          strokeDasharray={2 * Math.PI * 40}
                          strokeDashoffset={2 * Math.PI * 40 * (1 - gaugesState['BTC'].progress / 100)}
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute text-center">
                        <span className="block font-display font-black text-xl text-white tracking-tight">
                          {gaugesState['BTC'].progress}%
                        </span>
                        <span className="block text-[8px] font-mono text-gray-500 uppercase tracking-wider">
                          {gaugesState['BTC'].progress === 100 ? (
                            <span className="text-amber-400 font-bold">COMPLET</span>
                          ) : (
                            formatTime(gaugesState['BTC'].timeLeftSeconds)
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 z-10">
                    <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                      <span>Rendement :</span>
                      <span className="text-white font-bold">+{settings.rewardAmount.toFixed(2)} USDT</span>
                    </div>

                    <button
                      onClick={() => handleClaimGauge('BTC')}
                      disabled={gaugesState['BTC'].progress < 100 || claimingCur !== null}
                      className={`w-full py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer ${
                        gaugesState['BTC'].progress === 100
                          ? 'bg-amber-500 text-gray-950 hover:brightness-110 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                          : 'bg-gray-900 text-gray-600 border border-gray-800 cursor-not-allowed'
                      }`}
                    >
                      {claimingCur === 'BTC' ? (
                        <div className="w-4 h-4 border-2 border-gray-950/30 border-t-gray-950 rounded-full animate-spin" />
                      ) : (
                        <>
                          <Coins size={14} />
                          <span>{language === 'fr' ? 'Récolter BTC' : 'Harvest BTC'}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* CARD 3: ETH (Ethereum) */}
                <div className={`relative bg-gray-950/45 border rounded-3xl p-6 flex flex-col justify-between overflow-hidden transition-all duration-500 group min-h-[340px] shadow-xl ${
                  gaugesState['ETH'].progress === 100
                    ? 'border-indigo-500/50 shadow-[0_0_20px_rgba(98,126,234,0.15)] bg-indigo-950/5'
                    : 'border-gray-900 hover:border-gray-800'
                }`}>
                  <div className="absolute -bottom-10 -right-10 opacity-5 pointer-events-none group-hover:scale-110 transition duration-500">
                    <EthIcon size={160} />
                  </div>

                  <div className="flex justify-between items-start z-10">
                    <div className="flex items-center gap-3">
                      <EthIcon size={36} className="rounded-xl shadow-lg shadow-indigo-500/10" />
                      <div>
                        <h4 className="font-display font-bold text-sm text-white">ETH</h4>
                        <p className="text-[10px] text-gray-500 font-mono font-bold">Web3 Computes</p>
                      </div>
                    </div>
                    {gaugesState['ETH'].progress === 100 ? (
                      <span className="py-0.5 px-2 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-[9px] font-mono font-bold text-indigo-400 uppercase tracking-wider animate-pulse">
                        READY
                      </span>
                    ) : (
                      <span className="py-0.5 px-2 rounded-full bg-gray-900 border border-gray-800 text-[9px] font-mono font-bold text-gray-500 uppercase tracking-wider">
                        MINING
                      </span>
                    )}
                  </div>

                  <div className="my-6 flex flex-col items-center justify-center z-10 relative">
                    <div className="relative w-28 h-28 flex items-center justify-center">
                      <svg className="w-24 h-24 transform -rotate-90">
                        <circle cx="48" cy="48" r="40" className="stroke-gray-900 fill-none" strokeWidth="5" />
                        <circle 
                          cx="48" 
                          cy="48" 
                          r="40" 
                          className={`fill-none transition-all duration-1000 stroke-current ${
                            gaugesState['ETH'].progress === 100 ? 'text-indigo-400' : 'text-brand-blue'
                          }`} 
                          strokeWidth="6" 
                          strokeDasharray={2 * Math.PI * 40}
                          strokeDashoffset={2 * Math.PI * 40 * (1 - gaugesState['ETH'].progress / 100)}
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute text-center">
                        <span className="block font-display font-black text-xl text-white tracking-tight">
                          {gaugesState['ETH'].progress}%
                        </span>
                        <span className="block text-[8px] font-mono text-gray-500 uppercase tracking-wider">
                          {gaugesState['ETH'].progress === 100 ? (
                            <span className="text-indigo-400 font-bold">COMPLET</span>
                          ) : (
                            formatTime(gaugesState['ETH'].timeLeftSeconds)
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 z-10">
                    <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                      <span>Rendement :</span>
                      <span className="text-white font-bold">+{settings.rewardAmount.toFixed(2)} USDT</span>
                    </div>

                    <button
                      onClick={() => handleClaimGauge('ETH')}
                      disabled={gaugesState['ETH'].progress < 100 || claimingCur !== null}
                      className={`w-full py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer ${
                        gaugesState['ETH'].progress === 100
                          ? 'bg-indigo-600 text-white hover:brightness-110 shadow-[0_0_12px_rgba(98,126,234,0.4)]'
                          : 'bg-gray-900 text-gray-600 border border-gray-800 cursor-not-allowed'
                      }`}
                    >
                      {claimingCur === 'ETH' ? (
                        <div className="w-4 h-4 border-2 border-gray-950/30 border-t-gray-950 rounded-full animate-spin" />
                      ) : (
                        <>
                          <Coins size={14} />
                          <span>{language === 'fr' ? 'Récolter ETH' : 'Harvest ETH'}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* CARD 4: SOL (Solana) */}
                <div className={`relative bg-gray-950/45 border rounded-3xl p-6 flex flex-col justify-between overflow-hidden transition-all duration-500 group min-h-[340px] shadow-xl ${
                  gaugesState['SOL'].progress === 100
                    ? 'border-emerald-400/50 shadow-[0_0_20px_rgba(20,241,149,0.15)] bg-emerald-950/5'
                    : 'border-gray-900 hover:border-gray-800'
                }`}>
                  <div className="absolute -bottom-10 -right-10 opacity-5 pointer-events-none group-hover:scale-110 transition duration-500">
                    <SolIcon size={160} />
                  </div>

                  <div className="flex justify-between items-start z-10">
                    <div className="flex items-center gap-3">
                      <SolIcon size={36} className="rounded-xl shadow-lg shadow-emerald-400/10" />
                      <div>
                        <h4 className="font-display font-bold text-sm text-white">SOL</h4>
                        <p className="text-[10px] text-gray-500 font-mono font-bold">Ultra-Fast</p>
                      </div>
                    </div>
                    {gaugesState['SOL'].progress === 100 ? (
                      <span className="py-0.5 px-2 rounded-full bg-emerald-400/15 border border-emerald-400/30 text-[9px] font-mono font-bold text-emerald-400 uppercase tracking-wider animate-pulse">
                        READY
                      </span>
                    ) : (
                      <span className="py-0.5 px-2 rounded-full bg-gray-900 border border-gray-800 text-[9px] font-mono font-bold text-gray-500 uppercase tracking-wider">
                        MINING
                      </span>
                    )}
                  </div>

                  <div className="my-6 flex flex-col items-center justify-center z-10 relative">
                    <div className="relative w-28 h-28 flex items-center justify-center">
                      <svg className="w-24 h-24 transform -rotate-90">
                        <circle cx="48" cy="48" r="40" className="stroke-gray-900 fill-none" strokeWidth="5" />
                        <circle 
                          cx="48" 
                          cy="48" 
                          r="40" 
                          className={`fill-none transition-all duration-1000 stroke-current ${
                            gaugesState['SOL'].progress === 100 ? 'text-emerald-400' : 'text-brand-blue'
                          }`} 
                          strokeWidth="6" 
                          strokeDasharray={2 * Math.PI * 40}
                          strokeDashoffset={2 * Math.PI * 40 * (1 - gaugesState['SOL'].progress / 100)}
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute text-center">
                        <span className="block font-display font-black text-xl text-white tracking-tight">
                          {gaugesState['SOL'].progress}%
                        </span>
                        <span className="block text-[8px] font-mono text-gray-500 uppercase tracking-wider">
                          {gaugesState['SOL'].progress === 100 ? (
                            <span className="text-emerald-400 font-bold">COMPLET</span>
                          ) : (
                            formatTime(gaugesState['SOL'].timeLeftSeconds)
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 z-10">
                    <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                      <span>Rendement :</span>
                      <span className="text-white font-bold">+{settings.rewardAmount.toFixed(2)} USDT</span>
                    </div>

                    <button
                      onClick={() => handleClaimGauge('SOL')}
                      disabled={gaugesState['SOL'].progress < 100 || claimingCur !== null}
                      className={`w-full py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer ${
                        gaugesState['SOL'].progress === 100
                          ? 'bg-emerald-400 text-gray-950 hover:brightness-110 shadow-[0_0_12px_rgba(20,241,149,0.4)]'
                          : 'bg-gray-900 text-gray-600 border border-gray-800 cursor-not-allowed'
                      }`}
                    >
                      {claimingCur === 'SOL' ? (
                        <div className="w-4 h-4 border-2 border-gray-950/30 border-t-gray-950 rounded-full animate-spin" />
                      ) : (
                        <>
                          <Coins size={14} />
                          <span>{language === 'fr' ? 'Récolter SOL' : 'Harvest SOL'}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

              </div>
            </>
          )}
        </div>
      )}

      {/* SECTION 2: RETENTION DAILY TASKS PLAYGROUND */}
      {activeSection === 'retention' && (
        <div className="space-y-8">
          
          {/* Bento Subtabs for retention tasks */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* TASK 1: Lucky Spin Wheel (7 cols) */}
            <div className="lg:col-span-7 bg-gray-950/45 border border-gray-900 rounded-3xl p-6 shadow-xl relative overflow-hidden flex flex-col justify-between min-h-[500px]">
              <div className="absolute inset-0 bg-radial-at-t from-purple-500/5 to-transparent pointer-events-none" />
              
              <div>
                <div className="flex items-center gap-2.5 mb-2">
                  <span className="p-1.5 rounded-lg bg-purple-500/10 text-purple-400">
                    <Sparkles size={16} />
                  </span>
                  <h3 className="font-display font-black text-base text-white">
                    {language === 'fr' ? 'Roue de la Fortune Cyber' : 'Cyber Lucky Spin Wheel'}
                  </h3>
                </div>
                <p className="text-[11px] text-gray-400 leading-relaxed mb-6">
                  {language === 'fr' 
                    ? 'Tournez la roue numérique toutes les 12 heures pour tenter de décrocher des USDT instantanés ou des bonus d\'XP massifs !'
                    : 'Spin the digital wheel every 12 hours for a chance to secure instant USDT credits or massive XP boosts!'}
                </p>

                {/* Spin error */}
                {spinError && (
                  <div className="mb-4 p-3 rounded-xl bg-red-950/25 border border-red-500/25 text-[11px] text-red-400 flex items-center gap-2">
                    <AlertCircle size={14} />
                    <span>{spinError}</span>
                  </div>
                )}

                {/* CSS/SVG Spin wheel component container */}
                <div className="flex flex-col items-center justify-center py-6 relative">
                  
                  {/* Outer glowing frame */}
                  <div className="relative w-64 h-64 rounded-full border-4 border-gray-900 flex items-center justify-center shadow-[0_0_30px_rgba(168,85,247,0.15)] bg-gray-950">
                    
                    {/* Top pointing marker */}
                    <div className="absolute -top-1.5 z-30 transform -translate-x-1/2 left-1/2 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[18px] border-t-purple-500 drop-shadow-[0_2px_5px_rgba(168,85,247,0.5)]" />
                    
                    {/* The physical spinning circle */}
                    <div 
                      className="absolute w-[94%] h-[94%] rounded-full overflow-hidden transition-transform duration-[4000ms] ease-out border border-gray-800"
                      style={{ 
                        transform: `rotate(${rotationDegrees}deg)`,
                        backgroundImage: `conic-gradient(
                          #111827 0deg 45deg,
                          #1f2937 45deg 90deg,
                          #111827 90deg 135deg,
                          #1f2937 135deg 180deg,
                          #111827 180deg 225deg,
                          #1f2937 225deg 270deg,
                          #111827 270deg 315deg,
                          #1f2937 315deg 360deg
                        )`
                      }}
                    >
                      {/* Labels drawn on the wheel */}
                      {[
                        { label: '+0.10₮', angle: 22.5, color: 'text-green-400' },
                        { label: '+15 XP', angle: 67.5, color: 'text-purple-400' },
                        { label: '+0.25₮', angle: 112.5, color: 'text-green-400' },
                        { label: '+30 XP', angle: 157.5, color: 'text-purple-400' },
                        { label: '+0.50₮', angle: 202.5, color: 'text-green-400' },
                        { label: '+50 XP', angle: 247.5, color: 'text-purple-400' },
                        { label: '+1.00₮', angle: 292.5, color: 'text-green-300 font-black' },
                        { label: '+100 XP', angle: 337.5, color: 'text-purple-300 font-black' }
                      ].map((item, idx) => (
                        <div 
                          key={idx}
                          className={`absolute text-[10px] font-mono font-bold tracking-tight origin-center text-center ${item.color}`}
                          style={{
                            left: '50%',
                            top: '50%',
                            transform: `translate(-50%, -50%) rotate(${item.angle}deg) translateY(-84px)`
                          }}
                        >
                          {item.label}
                        </div>
                      ))}

                      {/* Division lines */}
                      {[0, 45, 90, 135, 180, 225, 270, 315].map((angle) => (
                        <div 
                          key={angle}
                          className="absolute w-[1px] h-1/2 bg-gray-800/80 origin-bottom left-[50%] top-0"
                          style={{ transform: `rotate(${angle}deg)` }}
                        />
                      ))}
                    </div>

                    {/* Central Core button */}
                    <button
                      onClick={handleLuckySpin}
                      disabled={spinCooldownTimeLeft > 0 || spinning}
                      className={`absolute w-16 h-16 rounded-full font-black text-xs uppercase flex flex-col items-center justify-center select-none z-20 cursor-pointer shadow-lg transition-all duration-300 ${
                        spinCooldownTimeLeft > 0
                          ? 'bg-gray-900 border border-gray-800 text-gray-500 cursor-not-allowed'
                          : 'bg-purple-600 hover:bg-purple-500 text-white border border-purple-400 shadow-purple-600/30 animate-pulse'
                      }`}
                    >
                      {spinning ? (
                        <span className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <span className="font-extrabold text-[10px]">SPIN</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Cooldown Timer display */}
                  {spinCooldownTimeLeft > 0 && (
                    <div className="mt-4 flex items-center gap-1.5 py-1 px-3 rounded-full bg-gray-950 border border-gray-900 text-[10px] font-mono text-gray-400">
                      <Clock size={12} className="text-purple-400 animate-pulse" />
                      <span>Recharge : {formatCooldown(spinCooldownTimeLeft)}</span>
                    </div>
                  )}

                  {/* Spin Result Modal Style */}
                  {spinResult && (
                    <div className="mt-5 p-4 rounded-2xl bg-purple-950/15 border border-purple-500/20 text-center space-y-2 animate-bounce max-w-sm mx-auto">
                      <div className="flex items-center justify-center gap-1.5 text-purple-400 font-extrabold text-xs">
                        <Sparkles size={16} className="animate-spin-slow" />
                        <span>FÉLICITATIONS !</span>
                      </div>
                      <p className="text-xs text-white">
                        Vous avez gagné <span className="text-purple-400 font-black">{spinResult.label}</span> sur la roue !
                      </p>
                      {spinResult.leveledUp && (
                        <span className="block text-[9px] text-yellow-400 font-bold uppercase tracking-wider">
                          🏆 NIVEAU SUIVANT DÉVERROUILLÉ !
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* TASK 2: Daily Quiz Web3 (5 cols) */}
            <div className="lg:col-span-5 bg-gray-950/45 border border-gray-900 rounded-3xl p-6 shadow-xl relative min-h-[500px] flex flex-col justify-between">
              <div className="absolute inset-0 bg-radial-at-t from-pink-500/5 to-transparent pointer-events-none" />
              
              <div>
                <div className="flex items-center justify-between mb-4 border-b border-gray-900/50 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-lg bg-pink-500/10 text-pink-400">
                      <Brain size={16} />
                    </span>
                    <h3 className="font-display font-black text-sm text-white">
                      {language === 'fr' ? 'Quiz Quotidien Web3' : 'Daily Web3 Quiz'}
                    </h3>
                  </div>
                  {quizDone && (
                    <span className="py-0.5 px-2 rounded-full bg-pink-500/10 border border-pink-500/20 text-[9px] font-mono font-bold text-pink-400 uppercase tracking-wider animate-pulse">
                      DONE
                    </span>
                  )}
                </div>

                {/* Quiz Done screen */}
                {quizDone && !quizFinished ? (
                  <div className="py-12 text-center space-y-4">
                    <div className="w-16 h-16 bg-pink-950/20 border border-pink-500/20 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-pink-500/5">
                      <Trophy className="text-pink-400 animate-bounce" size={28} />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-extrabold text-white">
                        {language === 'fr' ? 'Quiz déjà validé aujourd\'hui !' : 'Quiz already completed today!'}
                      </h4>
                      <p className="text-xs text-gray-400 max-w-xs mx-auto leading-relaxed">
                        {language === 'fr' 
                          ? 'Excellent travail d\'apprentissage ! Revenez demain pour un nouveau quiz et d\'autres récompenses.'
                          : 'Excellent learning work! Come back tomorrow for a new set of questions and more rewards.'}
                      </p>
                    </div>
                    {quizCooldownTimeLeft > 0 && (
                      <div className="inline-flex items-center gap-1.5 py-1 px-3 rounded-full bg-gray-950 border border-gray-900 text-[10px] font-mono text-gray-500 mx-auto">
                        <Clock size={12} className="text-pink-400 animate-pulse" />
                        <span>Nouveau quiz dans : {formatCooldown(quizCooldownTimeLeft)}</span>
                      </div>
                    )}
                  </div>
                ) : quizFinished ? (
                  /* Quiz End screen */
                  <div className="py-8 text-center space-y-5 animate-fade-in">
                    <div className="w-16 h-16 bg-green-950/20 border border-green-500/20 rounded-full flex items-center justify-center mx-auto shadow-inner">
                      <CheckCircle2 className="text-green-400 animate-pulse" size={32} />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-black text-white uppercase tracking-wider">
                        {language === 'fr' ? 'Quiz terminé !' : 'Quiz Completed!'}
                      </h4>
                      <p className="text-xs text-gray-400">
                        {language === 'fr' ? `Votre score final : ${quizScore} / 3` : `Your final score: ${quizScore} / 3`}
                      </p>
                    </div>

                    {quizReward && (
                      <div className="p-4 rounded-2xl bg-gray-900 border border-gray-800 max-w-xs mx-auto space-y-2">
                        <div className="text-[11px] text-gray-300">
                          {language === 'fr' ? 'Récompenses créditées :' : 'Rewards credited:'}
                        </div>
                        <div className="flex justify-center items-center gap-4">
                          <div className="text-center">
                            <span className="block text-green-400 font-black text-sm">+{quizReward.rewardUsdt.toFixed(2)} USDT</span>
                            <span className="text-[8px] font-mono text-gray-500">SOLDE</span>
                          </div>
                          <div className="w-[1px] h-6 bg-gray-800" />
                          <div className="text-center">
                            <span className="block text-pink-400 font-black text-sm">+{quizReward.rewardXp} XP</span>
                            <span className="text-[8px] font-mono text-gray-500">XP GRANTED</span>
                          </div>
                        </div>
                        {quizReward.leveledUp && (
                          <span className="block text-[8px] text-yellow-400 font-bold uppercase tracking-wider mt-1">
                            🏆 PASSAGE AU NIVEAU {currentUser.level + 1} !
                          </span>
                        )}
                      </div>
                    )}

                    <button
                      onClick={resetQuizUI}
                      className="py-2 px-4 rounded-xl bg-gray-900 border border-gray-800 text-xs font-bold text-gray-300 hover:text-white transition cursor-pointer mx-auto flex items-center gap-1"
                    >
                      <RotateCcw size={12} />
                      <span>{language === 'fr' ? 'Rejouer pour s\'entraîner' : 'Replay for training'}</span>
                    </button>
                  </div>
                ) : (
                  /* Quiz Playing flow */
                  <div className="space-y-4 animate-fade-in py-2">
                    {/* Header step progress */}
                    <div className="flex justify-between items-center text-[10px] font-mono text-gray-500">
                      <span>QUESTION {currentQuizStep + 1} SUR 3</span>
                      <span className="font-bold text-pink-400">{Math.round(((currentQuizStep) / 3) * 100)}% COMPLET</span>
                    </div>
                    {/* Progress Bar */}
                    <div className="h-1.5 w-full bg-gray-950 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-pink-500 transition-all duration-500"
                        style={{ width: `${((currentQuizStep + 1) / 3) * 100}%` }}
                      />
                    </div>

                    {/* Question text */}
                    <h4 className="text-xs font-bold text-white leading-relaxed mt-2">
                      {language === 'fr' ? QUIZ_QUESTIONS[currentQuizStep].question_fr : QUIZ_QUESTIONS[currentQuizStep].question_en}
                    </h4>

                    {/* Options list */}
                    <div className="space-y-3 pt-2">
                      {QUIZ_QUESTIONS[currentQuizStep].options.map((opt, idx) => {
                        const isSelected = selectedAnswer === idx;
                        const isCorrectAnswer = idx === QUIZ_QUESTIONS[currentQuizStep].correct;
                        return (
                          <button
                            key={idx}
                            onClick={() => handleQuizAnswerSelect(idx)}
                            disabled={quizAnswered}
                            className={`w-full p-3.5 rounded-xl text-left text-xs transition-all flex items-center justify-between border cursor-pointer ${
                              quizAnswered
                                ? isCorrectAnswer
                                  ? 'bg-green-950/20 border-green-500/40 text-green-300'
                                  : isSelected
                                    ? 'bg-red-950/20 border-red-500/40 text-red-300'
                                    : 'bg-gray-900/10 border-gray-900/80 text-gray-500 opacity-60'
                                : isSelected
                                  ? 'bg-pink-950/15 border-pink-500/50 text-pink-300 font-bold shadow-md shadow-pink-500/5'
                                  : 'bg-gray-900/10 border-gray-900 hover:border-gray-800 text-gray-300'
                            }`}
                          >
                            <span>{opt}</span>
                            {quizAnswered && isCorrectAnswer && (
                              <CheckCircle2 size={14} className="text-green-400 shrink-0 ml-2" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Feedback explanation after answer is submitted */}
                    {quizAnswered && (
                      <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-900 text-[10px] text-gray-400 leading-relaxed animate-fade-in">
                        <span className="font-bold text-white block mb-0.5">ℹ️ Explication :</span>
                        {language === 'fr' ? QUIZ_QUESTIONS[currentQuizStep].explanation_fr : QUIZ_QUESTIONS[currentQuizStep].explanation_en}
                      </div>
                    )}

                    {/* Next step buttons */}
                    <div className="pt-2">
                      {!quizAnswered ? (
                        <button
                          onClick={handleValidateQuizStep}
                          disabled={selectedAnswer === null}
                          className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1 transition cursor-pointer ${
                            selectedAnswer === null
                              ? 'bg-gray-900 text-gray-500 border border-gray-850 cursor-not-allowed'
                              : 'bg-pink-600 hover:bg-pink-500 text-white shadow-lg shadow-pink-600/15'
                          }`}
                        >
                          <span>{language === 'fr' ? 'Valider ma Réponse' : 'Submit Answer'}</span>
                        </button>
                      ) : (
                        <button
                          onClick={handleNextQuizQuestion}
                          className="w-full py-2.5 rounded-xl bg-gray-900 hover:bg-gray-800 text-xs font-bold text-white border border-gray-800 flex items-center justify-center gap-1 transition cursor-pointer"
                        >
                          <span>{currentQuizStep === QUIZ_QUESTIONS.length - 1 ? 'Terminer le Quiz' : 'Question Suivante'}</span>
                          <ChevronRight size={14} />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* TASK 3: Predict BTC Price UP/DOWN (Bento wide 12 cols) */}
          <div className="bg-gray-950/45 border border-gray-900 rounded-3xl p-6 shadow-xl relative overflow-hidden">
            <div className="absolute inset-0 bg-radial-at-t from-emerald-500/5 to-transparent pointer-events-none" />
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              {/* Game explanation */}
              <div className="lg:col-span-4 space-y-3">
                <div className="flex items-center gap-2.5">
                  <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                    <TrendingUp size={16} />
                  </span>
                  <h3 className="font-display font-black text-base text-white">
                    {language === 'fr' ? 'Predictor Pro : BTC/USDT' : 'Predictor Pro: BTC/USDT'}
                  </h3>
                </div>
                <p className="text-xs text-gray-400 leading-relaxed">
                  {language === 'fr'
                    ? "Devinez si le cours du Bitcoin (BTC) sera à la HAUSSE 📈 ou à la BAISSE 📉 dans les 15 secondes suivantes. Une prédiction correcte vous rapporte instantanément +0.50 USDT et +30 XP !"
                    : "Predict whether the Bitcoin (BTC) price will go UP 📈 or DOWN 📉 in the next 15 seconds. A correct guess immediately yields +0.50 USDT and +30 XP!"}
                </p>
                
                {/* Visual statistics */}
                <div className="p-3 bg-gray-900/50 border border-gray-850 rounded-2xl flex items-center justify-between text-[10px] font-mono">
                  <span className="text-gray-500">Frais de participation :</span>
                  <span className="text-green-400 font-bold uppercase">GRATUIT / SANS FRAIS</span>
                </div>
              </div>

              {/* Central Price feed visualizer */}
              <div className="lg:col-span-4 flex flex-col items-center justify-center p-6 bg-gray-900/10 border border-gray-900 rounded-3xl min-h-[160px] relative">
                
                {/* Live glow layer */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full bg-emerald-500/5 blur-xl pointer-events-none" />
                
                <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest block font-bold mb-1">
                  🔴 LIVE TICKER FEED (BTC/USDT)
                </span>
                
                <div className="font-mono font-black text-3xl text-white tracking-tight flex items-center gap-1.5 animate-pulse">
                  <span>${btcLivePrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                </div>
                
                <div className="text-[9px] font-mono text-emerald-400 flex items-center gap-1 mt-1.5 bg-emerald-950/20 px-2 py-0.5 rounded-full border border-emerald-500/10">
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                  </span>
                  <span>Flux temps réel simulé</span>
                </div>
              </div>

              {/* Action options */}
              <div className="lg:col-span-4 space-y-4">
                
                {predictError && (
                  <div className="p-3 rounded-xl bg-red-950/20 border border-red-500/30 text-[11px] text-red-400 flex items-center gap-2">
                    <AlertCircle size={14} className="shrink-0" />
                    <span>{predictError}</span>
                  </div>
                )}

                {/* If prediction is pending validation */}
                {userPredictionResult === 'pending' ? (
                  <div className="p-4 rounded-2xl bg-gray-900 border border-gray-850 space-y-3">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-400">Votre prédiction :</span>
                      <span className={`font-black uppercase py-0.5 px-2 rounded-md ${
                        userPredictionChoice === 'UP' ? 'bg-green-500/15 text-green-400 border border-green-500/20' : 'bg-red-500/15 text-red-400 border border-red-500/20'
                      }`}>
                        {userPredictionChoice === 'UP' ? 'HAUSSE 📈' : 'BAISSE 📉'}
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-400">Prix de départ :</span>
                      <span className="font-mono text-white font-bold">${userPredictionBtcPrice.toFixed(2)}</span>
                    </div>

                    {/* Countdown or Resolve button */}
                    {predictRemainingSeconds > 0 ? (
                      <div className="w-full py-2 px-3 rounded-xl bg-gray-950 border border-gray-900 text-center text-xs font-mono text-gray-400 flex items-center justify-center gap-2">
                        <Clock size={14} className="animate-pulse text-emerald-400" />
                        <span>Clôture du marché dans {predictRemainingSeconds}s...</span>
                      </div>
                    ) : (
                      <button
                        onClick={handleVerifyPredict}
                        disabled={verifyingPredict}
                        className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-black text-xs uppercase tracking-wider transition cursor-pointer shadow-lg shadow-emerald-500/15 animate-pulse flex items-center justify-center gap-1.5"
                      >
                        {verifyingPredict ? (
                          <span className="w-4 h-4 border-2 border-gray-950/20 border-t-gray-950 rounded-full animate-spin" />
                        ) : (
                          <>
                            <Trophy size={14} />
                            <span>Vérifier ma prédiction</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                ) : verifyResult ? (
                  /* Resolve result */
                  <div className={`p-4 rounded-2xl border text-center space-y-2 animate-fade-in ${
                    verifyResult.result === 'won' 
                      ? 'bg-green-950/20 border-green-500/30' 
                      : 'bg-red-950/10 border-red-500/20'
                  }`}>
                    <div className="text-xs font-extrabold flex justify-center items-center gap-1">
                      {verifyResult.result === 'won' ? (
                        <>
                          <CheckCircle2 className="text-green-400" size={16} />
                          <span className="text-green-400">PRÉDICTOR GAGNÉ !</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="text-red-400" size={16} />
                          <span className="text-red-400">PRÉDICTOR PERDU</span>
                        </>
                      )}
                    </div>
                    
                    <p className="text-[11px] text-gray-400">
                      Départ : <span className="font-mono text-white">${verifyResult.initialPrice.toFixed(2)}</span> | Clôture : <span className="font-mono text-white">${verifyResult.finalPrice.toFixed(2)}</span>
                    </p>

                    <div className="text-[11px] text-gray-300">
                      {verifyResult.result === 'won' ? (
                        <>
                          Vous gagnez <span className="text-green-400 font-bold">+{verifyResult.rewardUsdt.toFixed(2)} USDT</span> et <span className="text-brand-cyan font-bold">+{verifyResult.rewardXp} XP</span> !
                        </>
                      ) : (
                        <>
                          Consolation : <span className="text-brand-cyan font-bold">+{verifyResult.rewardXp} XP</span> de participation.
                        </>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        setVerifyResult(null);
                        setUserPredictionResult(null);
                      }}
                      className="py-1.5 px-3 rounded-lg bg-gray-900 hover:bg-gray-800 text-[10px] font-bold text-gray-300 hover:text-white border border-gray-800 transition cursor-pointer mx-auto block"
                    >
                      Refaire un défi
                    </button>
                  </div>
                ) : (
                  /* No prediction active */
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      onClick={() => handleBtcPredict('UP')}
                      disabled={predicting}
                      className="p-4 rounded-2xl bg-green-950/10 hover:bg-green-950/20 border border-green-500/20 hover:border-green-500/50 transition duration-300 flex flex-col items-center gap-1.5 group cursor-pointer"
                    >
                      <TrendingUp className="text-green-400 group-hover:scale-110 transition" size={24} />
                      <span className="text-[10px] font-black text-green-400 uppercase tracking-wider">PRÉDIRE EN HAUSSE</span>
                    </button>

                    <button
                      onClick={() => handleBtcPredict('DOWN')}
                      disabled={predicting}
                      className="p-4 rounded-2xl bg-red-950/10 hover:bg-red-950/20 border border-red-500/20 hover:border-red-500/50 transition duration-300 flex flex-col items-center gap-1.5 group cursor-pointer"
                    >
                      <TrendingDown className="text-red-400 group-hover:scale-110 transition" size={24} />
                      <span className="text-[10px] font-black text-red-400 uppercase tracking-wider">PRÉDIRE EN BAISSE</span>
                    </button>
                  </div>
                )}

              </div>

            </div>
          </div>

        </div>
      )}

    </div>
  );
}
