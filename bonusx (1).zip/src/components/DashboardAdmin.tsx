import React, { useState, useEffect } from 'react';
import { Users, Coins, CheckSquare, Clock, ShieldCheck, Activity, Award } from 'lucide-react';
import { api } from '../lib/api';

interface AdminStats {
  totalUsers: number;
  blockedUsers: number;
  pendingWithdrawalsCount: number;
  approvedWithdrawalsAmount: number;
  pendingSubmissionsCount: number;
  totalMissions: number;
  activeMissions: number;
  totalRewardsDistributed: number;
}

export default function DashboardAdmin() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAdminStats = async () => {
    try {
      const statsRes = await api.getAdminStats();
      const txRes = await api.getAdminTransactions();
      setStats(statsRes);
      setTransactions(txRes.transactions.slice(0, 8)); // Top 8 transactions
    } catch (err) {
      console.error('Erreur admin stats fetch', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminStats();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-3">
        <div className="w-8 h-8 border-2 border-brand-cyan/20 border-t-brand-cyan rounded-full animate-spin" />
        <span className="text-xs text-gray-500 font-mono uppercase tracking-widest">Calcul des statistiques globales...</span>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Title */}
      <div>
        <h2 className="font-display font-bold text-2xl text-white">Dashboard Administration</h2>
        <p className="text-xs text-gray-400">Suivi d'activité globale, audit financier et métriques de validation en temps réel.</p>
      </div>

      {/* Grid: Admin stats cards */}
      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Stat 1: Total Users */}
          <div className="glass-card rounded-2xl p-6 border border-gray-800/80 bg-gradient-to-br from-indigo-950/20 to-slate-900/40 flex items-center justify-between shadow-md">
            <div className="space-y-1.5">
              <span className="text-[10px] text-gray-500 font-mono uppercase tracking-wider block">Membres Actifs</span>
              <h3 className="font-display font-bold text-3xl text-white">{stats.totalUsers}</h3>
              <span className="text-[10px] text-red-400 font-mono">{stats.blockedUsers} comptes suspendus</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
              <Users size={20} />
            </div>
          </div>

          {/* Stat 2: Distributed USDC */}
          <div className="glass-card rounded-2xl p-6 border border-gray-800/80 bg-gradient-to-br from-cyan-950/20 to-slate-900/40 flex items-center justify-between shadow-md">
            <div className="space-y-1.5">
              <span className="text-[10px] text-gray-500 font-mono uppercase tracking-wider block">Récompenses versées</span>
              <h3 className="font-display font-bold text-2xl text-glow-neon text-white">
                {stats.totalRewardsDistributed.toFixed(2)} <span className="text-xs text-brand-cyan font-mono">USDC</span>
              </h3>
              <span className="text-[10px] text-green-400 font-mono">Total distribué</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-brand-cyan/15 border border-brand-cyan/30 text-brand-cyan">
              <Coins size={20} />
            </div>
          </div>

          {/* Stat 3: Pending Task submissions */}
          <div className="glass-card rounded-2xl p-6 border border-gray-800/80 bg-gradient-to-br from-yellow-950/20 to-slate-900/40 flex items-center justify-between shadow-md">
            <div className="space-y-1.5">
              <span className="text-[10px] text-gray-500 font-mono uppercase tracking-wider block">Preuves en attente</span>
              <h3 className="font-display font-bold text-3xl text-yellow-400">{stats.pendingSubmissionsCount}</h3>
              <span className="text-[10px] text-yellow-500 font-mono">Tâches à valider</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-yellow-500/10 border border-yellow-500/30 text-yellow-500">
              <CheckSquare size={20} />
            </div>
          </div>

          {/* Stat 4: Pending withdrawals */}
          <div className="glass-card rounded-2xl p-6 border border-gray-800/80 bg-gradient-to-br from-red-950/20 to-slate-900/40 flex items-center justify-between shadow-md">
            <div className="space-y-1.5">
              <span className="text-[10px] text-gray-500 font-mono uppercase tracking-wider block">Retraits en attente</span>
              <h3 className="font-display font-bold text-3xl text-red-400">{stats.pendingWithdrawalsCount}</h3>
              <span className="text-[10px] text-red-400 font-mono">Payouts à traiter</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400">
              <Clock size={20} />
            </div>
          </div>

        </div>
      )}

      {/* Grid: Global Stats details vs Recent Transactions System logs */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        
        {/* Left: General admin parameters summary (Covers 2 cols) */}
        <div className="lg:col-span-2 glass-card rounded-2xl p-6 border border-gray-800/80 shadow-md">
          <div className="pb-3 border-b border-gray-900 mb-4">
            <h4 className="font-display font-bold text-base text-white">Bounties en ligne</h4>
            <p className="text-xs text-gray-500">Missions configurées sur BonusX</p>
          </div>

          {stats && (
            <div className="space-y-4 font-mono text-xs text-gray-400">
              <div className="p-3 bg-gray-900/40 rounded-xl border border-gray-900 flex justify-between">
                <span>Total de missions</span>
                <span className="text-white font-bold">{stats.totalMissions}</span>
              </div>
              <div className="p-3 bg-gray-900/40 rounded-xl border border-gray-900 flex justify-between">
                <span>Missions actives</span>
                <span className="text-brand-cyan font-bold">{stats.activeMissions}</span>
              </div>
              <div className="p-3 bg-gray-900/40 rounded-xl border border-gray-900 flex justify-between">
                <span>Retraits payés</span>
                <span className="text-green-400 font-bold">{stats.approvedWithdrawalsAmount.toFixed(2)} USDC</span>
              </div>
            </div>
          )}

          <div className="mt-8 p-4 rounded-xl bg-gradient-to-r from-brand-blue/15 to-brand-cyan/15 border border-brand-cyan/20 text-[11px] text-gray-300 space-y-1">
            <p className="font-bold text-white mb-1">💡 Console d'Audit Admin</p>
            <p className="leading-relaxed">En tant qu'administrateur, vous disposez de tous les droits de modification de solde, blocage, et d'approbation manuelle.</p>
          </div>
        </div>

        {/* Right: Master Transactions Ledger (Covers 3 cols) */}
        <div className="lg:col-span-3 glass-card rounded-3xl p-6 border border-gray-800/80 shadow-xl flex flex-col">
          <div className="pb-3 border-b border-gray-800/60 mb-4 flex items-center gap-2">
            <Activity className="text-brand-cyan animate-pulse" size={16} />
            <h4 className="font-display font-bold text-base text-white">Journal Master Transactions</h4>
          </div>

          <div className="flex-1 space-y-3.5 overflow-y-auto max-h-[340px]">
            {transactions.length === 0 ? (
              <div className="text-center py-16 text-xs text-gray-600 font-mono">
                Aucune transaction globale détectée.
              </div>
            ) : (
              transactions.map((tx) => (
                <div 
                  key={tx.id} 
                  className="p-3 bg-gray-950/60 rounded-xl border border-gray-900 flex items-center justify-between text-xs transition hover:border-gray-800"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{tx.user?.username || 'Anonyme'}</span>
                      <span className="text-[10px] text-gray-500 font-mono">({tx.user?.email})</span>
                    </div>
                    <p className="text-gray-400 text-[11px]">{tx.description}</p>
                    <span className="text-[9px] text-gray-600 font-mono">
                      {new Date(tx.createdAt).toLocaleString('fr-FR')}
                    </span>
                  </div>
                  <div className="text-right shrink-0">
                    <span className={`font-mono font-bold ${tx.amountUsdc > 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {tx.amountUsdc > 0 ? '+' : ''}{tx.amountUsdc.toFixed(2)} USDC
                    </span>
                    <span className="text-[9px] text-gray-600 font-mono block uppercase">{tx.type}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
