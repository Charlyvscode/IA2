import React, { useState, useEffect } from 'react';
import { Users, ShieldAlert, Ban, Unlock, Edit, CheckCircle2, AlertCircle, Coins, Plus, Minus } from 'lucide-react';
import { User } from '../types';
import { api } from '../lib/api';

export default function UsersAdmin() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Account adjustments modal states
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [xpToAdjust, setXpToAdjust] = useState('');
  const [usdcToAdjust, setUsdcToAdjust] = useState('');
  const [adjustmentComment, setAdjustmentComment] = useState('');
  
  const [adjusting, setAdjusting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const fetchUsers = async () => {
    try {
      const res = await api.getAdminUsers();
      setUsers(res.users);
    } catch (err) {
      console.error('Erreur admin users fetch', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleToggleBlock = async (user: User) => {
    if (!window.confirm(`Êtes-vous sûr de vouloir ${user.isBlocked ? 'DÉBLOQUER' : 'BLOQUER'} le compte de ${user.username} ?`)) {
      return;
    }

    try {
      const res = await api.toggleBlockUser(user.id);
      if (res.success) {
        // Refresh users list
        fetchUsers();
      }
    } catch (err: any) {
      alert(err.message || 'Erreur lors du blocage.');
    }
  };

  const handleAdjustSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) return;
    setErrorMsg('');
    setSuccessMsg('');
    setAdjusting(true);

    const xpNum = Number(xpToAdjust || 0);
    const usdcNum = Number(usdcToAdjust || 0);

    if (xpNum === 0 && usdcNum === 0) {
      setErrorMsg('Veuillez saisir un ajustement d\'XP ou d\'USDC.');
      setAdjusting(false);
      return;
    }

    try {
      const res = await api.adjustUser(selectedUser.id, {
        xpAmount: xpNum,
        usdcAmount: usdcNum,
        comment: adjustmentComment.trim()
      });

      if (res.success) {
        setSuccessMsg('Compte utilisateur ajusté avec succès !');
        setXpToAdjust('');
        setUsdcToAdjust('');
        setAdjustmentComment('');
        fetchUsers();
        setTimeout(() => {
          setSelectedUser(null);
          setSuccessMsg('');
        }, 1500);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Erreur lors de l\'ajustement.');
    } finally {
      setAdjusting(false);
    }
  };

  const getFilteredUsers = () => {
    if (!searchQuery) return users;
    return users.filter(u => 
      u.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
      u.email.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Title & Search bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="font-display font-bold text-2xl text-white">Gestion des Utilisateurs</h2>
          <p className="text-xs text-gray-400 font-normal">Supervise, bloque/débloque et ajuste manuellement les soldes ou l'XP des utilisateurs de BonusX.</p>
        </div>

        {/* Search input bar */}
        <div className="w-full md:w-80">
          <input
            type="text"
            placeholder="Rechercher par pseudo ou email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-gray-900 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-brand-cyan transition"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-3">
          <div className="w-8 h-8 border-2 border-brand-cyan/20 border-t-brand-cyan rounded-full animate-spin" />
          <span className="text-xs text-gray-500 font-mono uppercase tracking-widest">Chargement des comptes...</span>
        </div>
      ) : (
        <div className="glass-card rounded-2xl p-6 border border-gray-800/80 shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-gray-400">
              <thead>
                <tr className="border-b border-gray-900 text-[10px] uppercase font-mono tracking-wider text-gray-500">
                  <th className="py-3 px-4">Utilisateur</th>
                  <th className="py-3 px-4">Niveau / XP</th>
                  <th className="py-3 px-4">Solde USDC</th>
                  <th className="py-3 px-4">Adresse Portefeuille</th>
                  <th className="py-3 px-4">Date d'inscription</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-900/60">
                {getFilteredUsers().length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-12 text-gray-600 font-mono">
                      Aucun utilisateur trouvé.
                    </td>
                  </tr>
                ) : (
                  getFilteredUsers().map((u) => (
                    <tr key={u.id} className={`hover:bg-white/2 transition ${u.isBlocked ? 'bg-red-950/10' : ''}`}>
                      
                      {/* Name / Email */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${u.isBlocked ? 'bg-red-950/40 border border-red-500/40 text-red-400' : 'bg-gray-900 border border-gray-800 text-brand-cyan'}`}>
                            {u.username.substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-semibold text-white flex items-center gap-1.5">
                              <span>{u.username}</span>
                              {u.isBlocked && (
                                <span className="py-0.5 px-1.5 rounded bg-red-500/20 text-[9px] font-bold text-red-400 font-mono">BLOQUÉ</span>
                              )}
                            </p>
                            <p className="text-[10px] text-gray-500 font-mono">{u.email}</p>
                          </div>
                        </div>
                      </td>

                      {/* Level / XP */}
                      <td className="py-3.5 px-4 font-mono">
                        <span className="py-0.5 px-1.5 rounded bg-brand-cyan/10 border border-brand-cyan/20 text-[10px] font-bold text-brand-cyan mr-2">
                          LVL {u.level}
                        </span>
                        <span className="text-[11px] text-gray-300">{u.xp} XP</span>
                      </td>

                      {/* Solde USDC */}
                      <td className="py-3.5 px-4 font-mono font-bold text-green-400">
                        {u.usdcBalance.toFixed(2)} USDC
                      </td>

                      {/* Wallet */}
                      <td className="py-3.5 px-4 font-mono text-gray-500 text-[11px]">
                        {u.walletAddress ? (
                          <span className="text-gray-300">{u.walletAddress.substring(0, 8)}...{u.walletAddress.slice(-6)}</span>
                        ) : (
                          <span className="italic text-gray-700">Aucun wallet lié</span>
                        )}
                      </td>

                      {/* Created date */}
                      <td className="py-3.5 px-4 font-mono text-[11px] text-gray-500">
                        {new Date(u.createdAt).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric'
                        })}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center justify-center gap-2">
                          
                          {/* Adjust values button */}
                          <button
                            onClick={() => {
                              setSelectedUser(u);
                              setXpToAdjust('');
                              setUsdcToAdjust('');
                              setAdjustmentComment('');
                              setErrorMsg('');
                              setSuccessMsg('');
                            }}
                            id={`adjust-user-btn-${u.id}`}
                            className="p-1.5 rounded-lg bg-gray-900 hover:bg-gray-800 border border-gray-800 text-gray-300 hover:text-white transition cursor-pointer"
                            title="Ajuster solde / XP"
                          >
                            <Edit size={14} />
                          </button>

                          {/* Block account button */}
                          <button
                            onClick={() => handleToggleBlock(u)}
                            id={`toggle-block-user-btn-${u.id}`}
                            className={`p-1.5 rounded-lg border transition cursor-pointer ${
                              u.isBlocked 
                                ? 'bg-green-950/20 hover:bg-green-950/40 border-green-900/30 text-green-400 hover:text-green-300'
                                : 'bg-red-950/20 hover:bg-red-950/40 border-red-900/30 text-red-400 hover:text-red-300'
                            }`}
                            title={u.isBlocked ? 'Débloquer le compte' : 'Suspendre le compte'}
                          >
                            {u.isBlocked ? <Unlock size={14} /> : <Ban size={14} />}
                          </button>

                        </div>
                      </td>

                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Adjust Solde / XP Modal Overlay */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-md glass-card rounded-3xl border border-gray-800 p-8 shadow-2xl relative">
            
            {/* Close Button */}
            <button 
              onClick={() => setSelectedUser(null)}
              id="close-adjust-modal-btn"
              className="absolute top-6 right-6 text-gray-400 hover:text-white transition cursor-pointer"
            >
              <Unlock size={20} className="rotate-45" /> {/* Just an X fallback */}
            </button>

            {/* Header */}
            <div className="mb-6 space-y-1">
              <span className="py-0.5 px-2.5 rounded bg-brand-cyan/15 text-[10px] font-mono font-bold uppercase text-brand-cyan">
                Ajustement Administratif
              </span>
              <h3 className="font-display font-bold text-lg text-white">Ajuster le compte de {selectedUser.username}</h3>
              <p className="text-xs text-gray-400">Ajoutez ou déduisez directement des USDC ou des XP. Précisez des valeurs négatives pour les soustractions.</p>
            </div>

            {/* Quick Balance Status banner */}
            <div className="p-3 rounded-xl bg-gray-950/60 border border-gray-900 text-xs font-mono text-gray-400 flex justify-between mb-6">
              <span>Solde actuel : <b className="text-green-400">{selectedUser.usdcBalance.toFixed(2)} USDC</b></span>
              <span>XP actuel : <b className="text-brand-cyan">{selectedUser.xp} XP</b></span>
            </div>

            {/* Error / Success state */}
            {errorMsg && (
              <div className="mb-4 p-3 rounded-lg bg-red-950/30 border border-red-500/30 text-xs text-red-400 flex items-center gap-2">
                <AlertCircle size={14} />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="mb-4 p-3 rounded-lg bg-green-950/30 border border-green-500/30 text-xs text-green-400 flex items-center gap-2">
                <CheckCircle2 size={14} />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleAdjustSubmit} className="space-y-4">
              
              <div className="grid grid-cols-2 gap-4">
                
                {/* Adjust USDC Amount Input */}
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-2 font-mono">
                    Ajuster USDC
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="Ex: 10 ou -5"
                    value={usdcToAdjust}
                    onChange={(e) => setUsdcToAdjust(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-700 font-mono focus:outline-none focus:border-brand-cyan transition text-center"
                  />
                </div>

                {/* Adjust XP Amount Input */}
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-2 font-mono">
                    Ajuster XP
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="Ex: 250 ou -100"
                    value={xpToAdjust}
                    onChange={(e) => setXpToAdjust(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-700 font-mono focus:outline-none focus:border-brand-cyan transition text-center"
                  />
                </div>

              </div>

              {/* Adjustment Reason Comment */}
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-2 font-mono">
                  Raison de l'ajustement (Sera notifiée)
                </label>
                <input
                  type="text"
                  placeholder="Ex : Récompense exceptionnelle pour quiz sans bug"
                  value={adjustmentComment}
                  onChange={(e) => setAdjustmentComment(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-700 focus:outline-none focus:border-brand-cyan transition"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setSelectedUser(null)}
                  id="cancel-adjust-btn"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-gray-900 hover:bg-gray-800 text-xs font-semibold text-white transition cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={adjusting}
                  id="confirm-adjust-btn"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-brand-blue to-brand-cyan hover:brightness-110 text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {adjusting ? (
                    <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Confirmer</span>
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
