// API communication helper for BonusX

const API_BASE = ((import.meta as any).env?.VITE_API_BASE_URL as string) || ''; // Same domain or configurable PHP API url

export function getSessionToken(): string | null {
  return localStorage.getItem('bonusx_session');
}

export function setSessionToken(token: string | null) {
  if (token) {
    localStorage.setItem('bonusx_session', token);
  } else {
    localStorage.removeItem('bonusx_session');
  }
}

async function request(endpoint: string, options: RequestInit = {}) {
  const token = getSessionToken();
  const headers = new Headers(options.headers || {});
  
  if (token) {
    headers.set('Authorization', `Session ${token}`);
  }
  
  if (options.body && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Une erreur est survenue lors du traitement.');
  }

  return data;
}

export const api = {
  // Auth
  login: (body: any) => request('/api/auth/login', { method: 'POST', body: JSON.stringify(body) }),
  register: (body: any) => request('/api/auth/register', { method: 'POST', body: JSON.stringify(body) }),
  me: () => request('/api/auth/me'),

  // User Profile Settings
  updateWallet: (walletAddress: string) => request('/api/user/update-wallet', { method: 'POST', body: JSON.stringify({ walletAddress }) }),
  updateSettings: (body: any) => request('/api/user/update-settings', { method: 'POST', body: JSON.stringify(body) }),

  // Bonus Daily Claim
  claimDaily: () => request('/api/user/claim-daily', { method: 'POST' }),

  // Auto-filling Claim Gauge
  getGaugeState: () => request('/api/gauge/state'),
  claimGauge: (claimCurrency: string) => request('/api/user/claim-gauge', { method: 'POST', body: JSON.stringify({ claimCurrency }) }),
  getAdminGauge: () => request('/api/admin/gauge'),
  updateAdminGauge: (body: { durationMinutes: number; rewardAmount: number; xpReward: number }) => request('/api/admin/gauge', { method: 'POST', body: JSON.stringify(body) }),

  // Daily retention tasks
  dailySpin: () => request('/api/user/daily-spin', { method: 'POST' }),
  dailyQuiz: (score: number) => request('/api/user/daily-quiz', { method: 'POST', body: JSON.stringify({ score }) }),
  dailyPredict: (prediction: 'UP' | 'DOWN', currentPrice: number) => request('/api/user/daily-predict', { method: 'POST', body: JSON.stringify({ prediction, currentPrice }) }),
  verifyPredict: () => request('/api/user/verify-predict', { method: 'POST' }),

  // User Missions
  getMissions: () => request('/api/missions'),
  submitMission: (missionId: string, proofText: string) => request('/api/missions/submit', { method: 'POST', body: JSON.stringify({ missionId, proofText }) }),
  getMySubmissions: () => request('/api/user/my-missions'),

  // User Rewards & Withdrawals
  getMyBonus: () => request('/api/user/my-bonus'),
  getMyWithdrawals: () => request('/api/user/my-withdrawals'),
  requestWithdrawal: (amountUsdc: number, walletAddress: string) => request('/api/user/request-withdrawal', { method: 'POST', body: JSON.stringify({ amountUsdc, walletAddress }) }),

  // Referrals & Leaderboard
  getReferrals: () => request('/api/user/referrals'),
  getLeaderboard: () => request('/api/leaderboard'),

  // Notifications
  getNotifications: () => request('/api/user/notifications'),
  markNotificationsAsRead: () => request('/api/user/notifications/read', { method: 'POST' }),

  // ==========================================
  // ADMIN EXCLUSIVE API CALLS
  // ==========================================
  getAdminStats: () => request('/api/admin/stats'),
  getAdminUsers: () => request('/api/admin/users'),
  adjustUser: (userId: string, body: { xpAmount: number; usdcAmount: number; comment?: string }) => request(`/api/admin/users/${userId}/adjust`, { method: 'POST', body: JSON.stringify(body) }),
  toggleBlockUser: (userId: string) => request(`/api/admin/users/${userId}/toggle-block`, { method: 'POST' }),

  getAdminMissions: () => request('/api/admin/missions'),
  createAdminMission: (body: any) => request('/api/admin/missions', { method: 'POST', body: JSON.stringify(body) }),
  updateAdminMission: (missionId: string, body: any) => request(`/api/admin/missions/${missionId}`, { method: 'PUT', body: JSON.stringify(body) }),
  deleteAdminMission: (missionId: string) => request(`/api/admin/missions/${missionId}`, { method: 'DELETE' }),

  getAdminSubmissions: () => request('/api/admin/submissions'),
  processSubmission: (submissionId: string, action: 'approve' | 'reject', adminComment?: string) => request(`/api/admin/submissions/${submissionId}/process`, { method: 'POST', body: JSON.stringify({ action, adminComment }) }),

  getAdminWithdrawals: () => request('/api/admin/withdrawals'),
  processWithdrawal: (withdrawalId: string, action: 'approve' | 'reject') => request(`/api/admin/withdrawals/${withdrawalId}/process`, { method: 'POST', body: JSON.stringify({ action }) }),

  getAdminTransactions: () => request('/api/admin/transactions'),
  getAdminLevels: () => request('/api/admin/levels'),
  updateAdminLevel: (body: any) => request('/api/admin/levels', { method: 'POST', body: JSON.stringify(body) })
};
