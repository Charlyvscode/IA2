import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'fr' | 'en';

interface LanguageContextProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, variables?: Record<string, string | number>) => string;
}

const translations: Record<Language, Record<string, any>> = {
  fr: {
    common: {
      level: "Niveau",
      level_abbr: "NIV",
      xp: "XP",
      max: "MAX",
      save: "Sauvegarder",
      close: "Fermer",
      disconnect: "Déconnecter",
      connect_wallet: "Connecter wallet",
      wallet_connected: "Portefeuille connecté",
      error: "Erreur",
      success: "Succès",
      loading: "Chargement...",
      admin_panel: "🔑 PANEL DE GESTION ADMINISTRATIVE ACTIVE",
      solde: "SOLDE",
      logout: "Se déconnecter",
      status: "Statut",
      status_pending: "En attente",
      status_approved: "Approuvé",
      status_rejected: "Refusé",
      date: "Date",
      action: "Action",
      comment: "Commentaire",
      back: "Retour",
      search: "Rechercher...",
      no_data: "Aucune donnée disponible"
    },
    menu: {
      user_title: "Menu Utilisateur",
      admin_title: "Menu Administrateur",
      home: "Accueil",
      missions: "Missions",
      my_bonus: "Mes Bonus",
      leaderboard: "Classement",
      referrals: "Parrainage",
      settings: "Paramètres",
      admin_dashboard: "Dashboard Admin",
      admin_users: "Utilisateurs",
      admin_submissions: "Validation",
      admin_missions: "Missions Admin",
      admin_rewards: "Récompenses",
      admin_withdrawals: "Retraits",
      admin_transactions: "Transactions",
      admin_settings: "Paramètres Admin",
      admin_mode: "Mode Administrateur",
      access_user: "👉 Accéder à l'Espace User",
      access_admin: "👉 Panel d'Administration"
    },
    auth: {
      title_register: "Créer un compte BonusX",
      title_login: "Se connecter à BonusX",
      subtitle_register: "Rejoins-nous et commence à accumuler des USDC réels !",
      subtitle_login: "Entre tes accès pour réclamer tes récompenses Web3",
      email: "Adresse Email",
      username: "Pseudo Unique",
      password: "Mot de passe",
      referral_optional: "Code de parrainage (Optionnel - Offre +5.00 USDC !)",
      no_account: "Tu n'as pas de compte ?",
      have_account: "Tu as déjà un compte ?",
      btn_register: "Créer mon Compte Premium",
      btn_login: "Se connecter maintenant",
      error_all_fields: "Veuillez remplir tous les champs obligatoires.",
      error_invalid_credentials: "Identifiants invalides ou incorrects.",
      success_welcome: "Bienvenue sur BonusX ! Compte initialisé.",
      processing: "Traitement en cours..."
    },
    header: {
      level_up_progress: "Plus que {xp} XP pour passer au Niveau {nextLevel}",
      wallet_modal_title: "Connecter un portefeuille",
      wallet_modal_desc: "Connecte ton portefeuille Polygon / EVM pour réclamer directement tes USDC accumulés de manière non-custodial.",
      wallet_placeholder: "Adresse Publique de Réception (0x...)",
      wallet_invalid: "Adresse EVM (Polygon/Ethereum) invalide. Doit comporter 42 caractères et commencer par 0x.",
      wallet_success: "Portefeuille connecté avec succès !",
      wallet_disconnected_msg: "Portefeuille déconnecté.",
      notifications_title: "Notifications",
      mark_all_read: "Tout marquer comme lu",
      no_notifications: "Aucune notification reçue.",
      time_format: "fr-FR"
    },
    dashboard: {
      available_balance: "Solde Disponible",
      balance_desc: "Dollar crypto instantanément retirable",
      current_level: "Niveau Actuel",
      xp_accumulated: "{xp} XP Accumulés",
      activity_title: "Missions & Filleuls",
      missions_validated: "Missions validées",
      referrals_count: "Filleuls inscrits",
      daily_bonus_title: "Réclame ton Bonus Quotidien !",
      daily_bonus_desc: "Gagne entre 0.25 et 1.50 USDC de manière totalement gratuite toutes les 12 heures.",
      bonus_claimed: "Bonus récupéré !",
      bonus_claimed_desc: "Tu as reçu +{usdc} USDC et +{xp} XP.",
      level_up_congrats: "🎉 NIVEAU SUPÉRIEUR ATTEINT !",
      level_up_desc: "Tu passes au niveau supérieur et gagnes +{reward} USDC de bonus !",
      claim_daily_btn: "Réclamer le Bonus USDC",
      syncing: "Synchronisation Web3...",
      cooldown_info: "Recharge : 12 heures • Sans frais de gaz (Gasless)",
      history_title: "Historique Récent",
      history_desc: "Dernières récompenses de ton compte",
      no_transactions: "Aucune transaction pour le moment. Réclame ton premier bonus pour débuter !",
      polygon_tx: "Polygon TX"
    },
    missions: {
      title: "Missions Disponibles",
      desc: "Accomplis des tâches simples de notre écosystème de partenaires pour débloquer des USDC et de l'XP.",
      filter_all: "Toutes les Missions",
      filter_social: "Réseaux Sociaux",
      filter_video: "Vidéos & Tutos",
      filter_quiz: "Quiz & Sécurité",
      filter_crypto: "Web3 & Crypto",
      filter_other: "Autres",
      reward_label: "Récompense",
      action_btn: "Lancer la Mission",
      proof_label: "Soumettre une Preuve d'Accomplissement",
      proof_desc: "Inscris ici ton pseudo, ID, capture d'écran textuelle ou lien de transaction pour que l'administrateur valide ton action.",
      proof_placeholder: "Ex: Mon pseudo Twitter est @AlexCrypto_X et j'ai retweeté votre post à 14h10...",
      submit_btn: "Envoyer la Preuve pour Validation",
      status_pending_desc: "En attente de validation par l'équipe d'administration.",
      status_approved_desc: "Félicitations ! Ton action a été validée et créditée.",
      status_rejected_desc: "Ta soumission a été rejetée. Motif : {comment}",
      resubmit_btn: "Soumettre une nouvelle preuve",
      no_missions: "Aucune mission active disponible dans cette catégorie.",
      already_submitted: "Tu as déjà soumis une preuve pour cette mission.",
      already_completed: "Tu as déjà accompli cette mission avec succès.",
      submitting: "Envoi en cours..."
    },
    bonus: {
      title: "Gestion des Bonus & Retraits",
      desc: "Suis tes gains en temps réel et retire tes USDC directement sur ton portefeuille non-custodial.",
      total_claimed: "Total Récompenses",
      pending_withdrawals: "Retraits en Attente",
      completed_withdrawals: "Retraits Effectués",
      request_withdrawal_title: "Demander un Retrait",
      request_withdrawal_desc: "Saisis le montant de USDC que tu souhaites transférer sur ton portefeuille. Minimum de retrait : 5.00 USDC.",
      withdrawal_amount_label: "Montant à retirer (USDC)",
      withdrawal_wallet_label: "Adresse de portefeuille EVM (Réseau Polygon)",
      no_wallet_alert: "Tu dois connecter ton adresse de portefeuille dans l'en-tête de la page avant d'initier un retrait.",
      min_withdrawal_error: "Le montant minimum de retrait est de 5.00 USDC.",
      insufficient_balance: "Solde insuffisant pour demander ce montant.",
      withdrawal_success: "Demande de retrait soumise avec succès ! Elle sera traitée dans les plus brefs délais.",
      withdraw_btn: "Confirmer le Retrait USDC",
      tx_history_title: "Journal Complet des Transactions",
      withdrawal_history_title: "Historique des Demandes de Retraits",
      tx_empty: "Aucune transaction enregistrée.",
      withdrawal_empty: "Aucune demande de retrait effectuée.",
      withdrawn_to: "Retrait vers {wallet}"
    },
    leaderboard: {
      title: "Classement de la Communauté",
      desc: "Affronte les autres membres de BonusX, monte de niveau et décroche des bonus supplémentaires en rejoignant le sommet.",
      table_rank: "Rang",
      table_user: "Utilisateur",
      table_level: "Niveau",
      table_xp: "XP Total",
      table_earnings: "Gains USDC",
      search_placeholder: "Rechercher un membre par pseudo...",
      no_users: "Aucun utilisateur ne correspond à votre recherche.",
      top_players_title: "Top 3 des Champions BonusX"
    },
    referrals: {
      title: "Programme de Parrainage Elite",
      desc: "Invite tes amis à rejoindre BonusX et construis un réseau passif. Reçois un bonus instantané pour chaque inscription valide.",
      your_code: "Ton Code de Parrainage",
      copy_btn: "Copier le Code",
      copied: "Copié !",
      share_msg: "Rejoins-moi sur BonusX, réalise des missions simples pour gagner des USDC réels ! Inscris-toi avec mon code : {code}",
      stats_title: "Tes Statistiques de Parrainage",
      friends_referred: "Amis Parrainés",
      commission_earned: "Commissions Générées",
      invite_card_title: "Partage ton lien unique",
      invite_card_desc: "Envoie ton code de parrainage à tes contacts ou partage-le sur les réseaux sociaux.",
      friend_list_title: "Membres parrainés actifs",
      friend_joined: "Rejoint le",
      friend_earned: "Gains générés : {amount} USDC"
    },
    settings: {
      title: "Paramètres de Sécurité",
      desc: "Gère les informations de ton compte utilisateur, modifie ton pseudo de profil et sécurise ton mot de passe.",
      profile_info: "Informations de Profil",
      username_label: "Nom d'utilisateur (Pseudo)",
      email_label: "Adresse Email de contact (Non modifiable)",
      security_title: "Sécurité & Mot de Passe",
      new_password_label: "Nouveau Mot de passe",
      password_placeholder: "Laisse vide pour ne pas modifier",
      save_settings_btn: "Sauvegarder les modifications",
      settings_updated_success: "Paramètres du compte mis à jour avec succès !",
      settings_updated_error: "Erreur lors de la mise à jour."
    },
    admin: {
      dashboard_title: "Centre de Contrôle Administratif",
      stats_total_users: "Utilisateurs Inscrits",
      stats_blocked: "Comptes Bloqués",
      stats_rewards: "Récompenses Distribuées",
      stats_pending_submissions: "Preuves à Valider",
      stats_pending_withdrawals: "Retraits à Valider",
      stats_active_missions: "Missions Actives",
      quick_actions: "Actions Rapides d'Administration",
      recent_activity: "Activité Globale Récente",
      users_management_title: "Gestion des Comptes Utilisateurs",
      user_status_blocked: "Banni",
      user_status_active: "Actif",
      adjust_balance_title: "Ajustement de Compte",
      adjust_comment: "Motif ou Commentaire administratif",
      btn_adjust: "Ajuster le Compte",
      btn_toggle_block: "Bloquer/Débloquer",
      btn_delete: "Supprimer",
      missions_management_title: "Création & Gestion des Missions",
      btn_create_mission: "Créer une Nouvelle Mission",
      mission_title_label: "Titre de la Mission",
      mission_desc_label: "Description de la Mission",
      mission_reward_usdc: "Récompense USDC",
      mission_reward_xp: "Récompense XP",
      mission_category: "Catégorie",
      mission_action_url: "Lien d'Action (URL)",
      mission_status_active: "Mission Active et Visible",
      submissions_management_title: "Validation des Preuves Soumises",
      proof_submitted_by: "Soumis par {username} pour la mission {mission}",
      btn_approve: "Approuver la Preuve",
      btn_reject: "Rejeter la Preuve",
      reject_comment_placeholder: "Indique le motif du rejet de la preuve...",
      withdrawals_management_title: "Gestion des Retraits USDC",
      withdraw_request_by: "Demande de retrait de {amount} USDC par {username}",
      btn_process_approve: "Approuver & Payer",
      btn_process_reject: "Rejeter & Rembourser",
      transactions_management_title: "Journal Global d'Audit des Transactions",
      configs_title: "Configuration des Niveaux de la Plateforme"
    }
  },
  en: {
    common: {
      level: "Level",
      level_abbr: "LVL",
      xp: "XP",
      max: "MAX",
      save: "Save Changes",
      close: "Close",
      disconnect: "Disconnect",
      connect_wallet: "Connect Wallet",
      wallet_connected: "Wallet Connected",
      error: "Error",
      success: "Success",
      loading: "Loading...",
      admin_panel: "🔑 ADMINISTRATIVE MANAGEMENT PANEL ACTIVE",
      solde: "BALANCE",
      logout: "Log Out",
      status: "Status",
      status_pending: "Pending",
      status_approved: "Approved",
      status_rejected: "Rejected",
      date: "Date",
      action: "Action",
      comment: "Comment",
      back: "Back",
      search: "Search...",
      no_data: "No data available"
    },
    menu: {
      user_title: "User Menu",
      admin_title: "Admin Menu",
      home: "Home",
      missions: "Missions",
      my_bonus: "My Bonuses",
      leaderboard: "Leaderboard",
      referrals: "Referrals",
      settings: "Settings",
      admin_dashboard: "Admin Dashboard",
      admin_users: "Users Hub",
      admin_submissions: "Submissions",
      admin_missions: "Manage Missions",
      admin_rewards: "Rewards System",
      admin_withdrawals: "Withdrawals",
      admin_transactions: "Ledger Audit",
      admin_settings: "Admin Settings",
      admin_mode: "Admin Mode",
      access_user: "👉 Go to User Space",
      access_admin: "👉 Go to Admin Panel"
    },
    auth: {
      title_register: "Create a BonusX Account",
      title_login: "Login to BonusX",
      subtitle_register: "Join us and start accumulating real USDC!",
      subtitle_login: "Enter your credentials to claim your Web3 rewards",
      email: "Email Address",
      username: "Unique Username",
      password: "Password",
      referral_optional: "Referral Code (Optional - Earn +5.00 USDC!)",
      no_account: "Don't have an account?",
      have_account: "Already have an account?",
      btn_register: "Create Premium Account",
      btn_login: "Sign In Now",
      error_all_fields: "Please fill in all required fields.",
      error_invalid_credentials: "Invalid or incorrect credentials.",
      success_welcome: "Welcome to BonusX! Account initialized.",
      processing: "Processing..."
    },
    header: {
      level_up_progress: "Only {xp} XP left to reach Level {nextLevel}",
      wallet_modal_title: "Connect a Wallet",
      wallet_modal_desc: "Connect your Polygon / EVM wallet to withdraw your accumulated USDC in a secure, non-custodial way.",
      wallet_placeholder: "Public Receipt Address (0x...)",
      wallet_invalid: "Invalid EVM (Polygon/Ethereum) address. Must be 42 characters and start with 0x.",
      wallet_success: "Wallet successfully connected!",
      wallet_disconnected_msg: "Wallet disconnected.",
      notifications_title: "Notifications",
      mark_all_read: "Mark all as read",
      no_notifications: "No notifications received.",
      time_format: "en-US"
    },
    dashboard: {
      available_balance: "Available Balance",
      balance_desc: "Crypto dollar instantly withdrawable",
      current_level: "Current Level",
      xp_accumulated: "{xp} XP Accumulated",
      activity_title: "Missions & Referrals",
      missions_validated: "Missions completed",
      referrals_count: "Registered referrals",
      daily_bonus_title: "Claim your Daily Bonus!",
      daily_bonus_desc: "Earn between 0.25 and 1.50 USDC completely free every 12 hours.",
      bonus_claimed: "Bonus claimed!",
      bonus_claimed_desc: "You received +{usdc} USDC and +{xp} XP.",
      level_up_congrats: "🎉 NEW LEVEL REACHED!",
      level_up_desc: "You leveled up and unlocked a +{reward} USDC bonus reward!",
      claim_daily_btn: "Claim USDC Bonus",
      syncing: "Web3 Synchronization...",
      cooldown_info: "Cooldown: 12 Hours • Gasless Transaction",
      history_title: "Recent History",
      history_desc: "Latest rewards credited to your account",
      no_transactions: "No transactions yet. Claim your first bonus to get started!",
      polygon_tx: "Polygon TX"
    },
    missions: {
      title: "Available Missions",
      desc: "Complete simple tasks from our ecosystem partners to unlock USDC and XP.",
      filter_all: "All Missions",
      filter_social: "Social Media",
      filter_video: "Videos & Tutorials",
      filter_quiz: "Quizzes & Safety",
      filter_crypto: "Web3 & Crypto",
      filter_other: "Others",
      reward_label: "Reward",
      action_btn: "Launch Mission",
      proof_label: "Submit Proof of Completion",
      proof_desc: "Submit your username, social ID, text proof, or transaction hash here for administrative validation.",
      proof_placeholder: "e.g., My Twitter handle is @AlexCrypto_X and I retweeted your post at 2:10 PM...",
      submit_btn: "Submit Proof for Review",
      status_pending_desc: "Awaiting review by the administrative team.",
      status_approved_desc: "Congratulations! Your proof has been approved and credited.",
      status_rejected_desc: "Your proof was rejected. Reason: {comment}",
      resubmit_btn: "Submit a new proof",
      no_missions: "No active missions available in this category.",
      already_submitted: "You have already submitted proof for this mission.",
      already_completed: "You have already completed this mission successfully.",
      submitting: "Submitting..."
    },
    bonus: {
      title: "Rewards & Withdrawals Management",
      desc: "Track your earnings in real time and withdraw your USDC directly to your non-custodial wallet.",
      total_claimed: "Total Rewards Earned",
      pending_withdrawals: "Pending Withdrawals",
      completed_withdrawals: "Completed Withdrawals",
      request_withdrawal_title: "Request a Withdrawal",
      request_withdrawal_desc: "Enter the amount of USDC you wish to transfer. Minimum withdrawal: 5.00 USDC.",
      withdrawal_amount_label: "Amount to withdraw (USDC)",
      withdrawal_wallet_label: "EVM Wallet Address (Polygon Network)",
      no_wallet_alert: "You must connect your wallet address in the header before initiating a withdrawal.",
      min_withdrawal_error: "Minimum withdrawal amount is 5.00 USDC.",
      insufficient_balance: "Insufficient balance to request this amount.",
      withdrawal_success: "Withdrawal request submitted successfully! It will be processed shortly.",
      withdraw_btn: "Confirm USDC Withdrawal",
      tx_history_title: "Complete Transactions Ledger",
      withdrawal_history_title: "Withdrawal Requests History",
      tx_empty: "No transactions recorded.",
      withdrawal_empty: "No withdrawal requests initiated.",
      withdrawn_to: "Withdrawn to {wallet}"
    },
    leaderboard: {
      title: "Community Leaderboard",
      desc: "Compete with other BonusX members, level up, and lock in extra bonuses by reaching the top.",
      table_rank: "Rank",
      table_user: "User",
      table_level: "Level",
      table_xp: "Total XP",
      table_earnings: "USDC Earned",
      search_placeholder: "Search user by handle...",
      no_users: "No users matching your search.",
      top_players_title: "Top 3 BonusX Champions"
    },
    referrals: {
      title: "Elite Referral Program",
      desc: "Invite your friends to BonusX and build passive income. Receive an instant bonus for each valid registration.",
      your_code: "Your Referral Code",
      copy_btn: "Copy Code",
      copied: "Copied!",
      share_msg: "Join me on BonusX, complete simple tasks to earn real USDC! Sign up with my code: {code}",
      stats_title: "Your Referral Stats",
      friends_referred: "Friends Referred",
      commission_earned: "Generated Commissions",
      invite_card_title: "Share your unique code",
      invite_card_desc: "Send your referral code to your friends or share it on social networks.",
      friend_list_title: "Active Referred Friends",
      friend_joined: "Joined on",
      friend_earned: "Earned for you: {amount} USDC"
    },
    settings: {
      title: "Account & Security",
      desc: "Manage your account credentials, update your profile handle, and secure your password.",
      profile_info: "Profile Details",
      username_label: "Username",
      email_label: "Contact Email (Cannot be changed)",
      security_title: "Security & Credentials",
      new_password_label: "New Password",
      password_placeholder: "Leave empty to keep current password",
      save_settings_btn: "Save Settings Changes",
      settings_updated_success: "Account settings updated successfully!",
      settings_updated_error: "Error updating settings."
    },
    admin: {
      dashboard_title: "Admin Control Center",
      stats_total_users: "Total Users",
      stats_blocked: "Suspended Accounts",
      stats_rewards: "Total Distributed",
      stats_pending_submissions: "Pending Verification",
      stats_pending_withdrawals: "Pending Cashouts",
      stats_active_missions: "Active Missions",
      quick_actions: "Admin Quick Actions",
      recent_activity: "Recent Global Activity",
      users_management_title: "Users Administration Hub",
      user_status_blocked: "Banned",
      user_status_active: "Active",
      adjust_balance_title: "Manual Account Adjustment",
      adjust_comment: "Admin adjustment comment or reason",
      btn_adjust: "Adjust Account State",
      btn_toggle_block: "Toggle Suspension",
      btn_delete: "Delete Account",
      missions_management_title: "Missions Configuration Hub",
      btn_create_mission: "Create New Partner Mission",
      mission_title_label: "Mission Title",
      mission_desc_label: "Mission Description",
      mission_reward_usdc: "Reward USDC",
      mission_reward_xp: "Reward XP",
      mission_category: "Category",
      mission_action_url: "Action Button Link",
      mission_status_active: "Mission Active and Listed",
      submissions_management_title: "Proofs Verification Queue",
      proof_submitted_by: "Proof from {username} for mission {mission}",
      btn_approve: "Approve and Credit",
      btn_reject: "Reject Proof",
      reject_comment_placeholder: "Enter review rejection comments...",
      withdrawals_management_title: "USDC Cashouts Approval",
      withdraw_request_by: "Cashout of {amount} USDC requested by {username}",
      btn_process_approve: "Approve & Settle",
      btn_process_reject: "Reject & Refund",
      transactions_management_title: "Global Audit Transaction Logs",
      configs_title: "Global Platform Levels Configuration"
    }
  }
};

const LanguageContext = createContext<LanguageContextProps | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('bonusx_lang');
    return (saved === 'en' || saved === 'fr') ? saved as Language : 'fr';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('bonusx_lang', lang);
  };

  const t = (key: string, variables?: Record<string, string | number>): string => {
    const keys = key.split('.');
    let current: any = translations[language];

    for (const k of keys) {
      if (current && typeof current === 'object' && k in current) {
        current = current[k];
      } else {
        // Fallback to FR language if not found in EN or incomplete
        let fallback: any = translations['fr'];
        for (const fk of keys) {
          if (fallback && typeof fallback === 'object' && fk in fallback) {
            fallback = fallback[fk];
          } else {
            fallback = null;
            break;
          }
        }
        if (typeof fallback === 'string') {
          current = fallback;
          break;
        }
        return key; // Return key if not found
      }
    }

    if (typeof current !== 'string') {
      return key;
    }

    let result = current;
    if (variables) {
      Object.entries(variables).forEach(([vKey, vVal]) => {
        result = result.replace(new RegExp(`{${vKey}}`, 'g'), String(vVal));
      });
    }

    return result;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
