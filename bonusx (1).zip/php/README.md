# 🚀 Guide d'Exportation & Déploiement PHP - BonusX

Ce dossier contient l'intégralité du **backend réécrit en PHP**, conçu spécifiquement pour être déployé en un clic sur un **serveur mutualisé ou partagé** (Hostinger, OVH, o2switch, GoDaddy, Ionos, etc.).

Le backend PHP implémente exactement les mêmes **31 points d'accès (endpoints) API** que la version Node.js/TypeScript, utilise le même sel de hachage pour les mots de passe et le même format de stockage de données, garantissant une migration fluide sans perte de données.

---

## 📂 Structure des Fichiers PHP

Voici les fichiers du dossier `/php` à téléverser sur votre serveur :
1. **`index.php`** : Point d'entrée unique et routeur API complet. Gère le CORS, l'authentification par session, les claims de bonus, les parrainages, les missions et l'administration.
2. **`.htaccess`** : Fichier de configuration Apache qui redirige élégamment les appels d'API (ex: `/api/auth/login`) vers le routeur PHP.
3. **`db-store.json`** (auto-généré) : Base de données portable sous forme de fichier JSON (contenant les utilisateurs, les missions, les transactions et la configuration des niveaux). S'auto-amorce lors du premier lancement avec des données de test si absent.
4. **`sessions.json`** (auto-généré) : Fichier de gestion des jetons de sessions actives et de leurs expirations.
5. **`last-claims.json`** (auto-généré) : Fichier de suivi du cooldown des 12 heures pour le bonus quotidien des utilisateurs.

---

## 🛠️ Instructions d'Installation et Déploiement (Étape par Étape)

### Étape 1 : Configurer l'URL de l'API dans le Frontend
Dans le dossier racine du projet React, éditez ou créez un fichier `.env.production` et ajoutez-y l'adresse où sera hébergée votre API PHP :
```env
VITE_API_BASE_URL="https://votre-domaine.com/php"
```
*(Si vous placez les fichiers du dossier `/php` directement dans un dossier nommé `api` à la racine de votre site web, utilisez `"https://votre-domaine.com/api"`)*.

### Étape 2 : Compiler le Frontend React
Compilez votre application pour générer les fichiers statiques optimisés pour la production :
```bash
npm run build
```
Cette commande génère un dossier `/dist` à la racine du projet, contenant tout le code HTML, CSS, Javascript et les images optimisés.

### Étape 3 : Téléverser sur votre Serveur Partagé (FTP)
Connectez-vous à votre hébergement via un client FTP (comme FileZilla) ou via le Gestionnaire de Fichiers de votre hébergeur (cPanel / hPanel) :
1. Copiez l'intégralité du contenu du dossier `/dist` et collez-le à la racine publique de votre serveur (généralement le dossier `public_html` ou `www`).
2. Créez un dossier nommé `php` (ou `api`) à cette même racine.
3. Téléversez-y les fichiers PHP suivants :
   - `index.php`
   - `.htaccess`

### Étape 4 : Configurer les Permissions d'Écriture (Chmod)
Étant donné que cette version utilise une base de données JSON portable (ne nécessitant aucune configuration de serveur SQL complexe !), PHP doit pouvoir écrire dans ce dossier pour créer et modifier les fichiers JSON.
Dans votre client FTP ou Gestionnaire de fichiers :
- Faites un clic droit sur le dossier `php` (ou `api`) contenant `index.php`.
- Choisissez **Droits d'accès au fichier (Permissions / Chmod)**.
- Définissez la valeur numérique sur **`775`** (ou **`777`** si votre hébergeur est très restrictif) afin de donner les droits d'écriture à PHP.
- Une fois la première connexion effectuée, les fichiers `db-store.json`, `sessions.json` et `last-claims.json` seront créés automatiquement et fonctionneront en parfaite autonomie !

---

## 🛡️ Sécurité et Fiabilité du Stockage JSON
Le script `index.php` intègre un mécanisme de **verrouillage de fichier exclusif** (`LOCK_EX` de PHP) lors de chaque écriture. Cela empêche toute corruption des fichiers de données en cas de requêtes simultanées de plusieurs utilisateurs.

De plus, le sel de hachage utilisé pour les mots de passe est cryptographiquement identique à celui du projet Node.js de départ :
```php
const HASH_SALT = 'BonusXPremiumPlatformSecretSalt2026';
```
Cela signifie que tous les comptes de démonstration pré-configurés fonctionnent immédiatement en PHP :
- **Compte Administrateur** : `admin@bonusx.com` / Mot de passe : `admin123`
- **Utilisateur Démo** : `user@bonusx.com` / Mot de passe : `user123`

---

## 🗄️ Évolution future : Schéma de Base de Données Relational (MySQL)

Si votre application grandit et que vous souhaitez migrer de la base de données JSON portable vers une base de données **MySQL** standard (très simple à activer sur les hébergements partagés), voici la structure SQL correspondante que vous pourrez créer :

```sql
-- Table des Utilisateurs
CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    xp INT DEFAULT 0,
    level INT DEFAULT 1,
    usdc_balance DECIMAL(15, 4) DEFAULT 0.0000,
    wallet_address VARCHAR(100) NULL,
    is_blocked BOOLEAN DEFAULT FALSE,
    is_admin BOOLEAN DEFAULT FALSE,
    referral_code VARCHAR(50) UNIQUE NOT NULL,
    referred_by VARCHAR(50) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des Mots de Passe Hachés
CREATE TABLE user_passwords (
    user_id VARCHAR(50) PRIMARY KEY,
    password_hash VARCHAR(255) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table des Missions
CREATE TABLE missions (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    reward_usdc DECIMAL(10, 2) NOT NULL,
    reward_xp INT NOT NULL,
    category VARCHAR(50) NOT NULL,
    action_url VARCHAR(255) DEFAULT '#',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des Preuves de Missions soumises par les utilisateurs
CREATE TABLE user_missions (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    mission_id VARCHAR(50) NOT NULL,
    proof_text TEXT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    admin_comment TEXT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE CASCADE
);

-- Table des Retraits USDC
CREATE TABLE withdrawals (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    amount_usdc DECIMAL(15, 4) NOT NULL,
    wallet_address VARCHAR(100) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table des Transactions (Historique des gains et retraits)
CREATE TABLE transactions (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    amount_usdc DECIMAL(15, 4) NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'mission_reward', 'referral_bonus', 'bonus_claim', 'withdrawal', etc.
    description VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table des Notifications Utilisateurs
CREATE TABLE notifications (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    type VARCHAR(30) DEFAULT 'info', -- 'success', 'alert', 'info', 'bonus_available'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table de Configuration des Niveaux
CREATE TABLE level_configs (
    level INT PRIMARY KEY,
    xp_required INT NOT NULL,
    reward_usdc DECIMAL(10, 2) NOT NULL
);

-- Insertion des configurations de niveau par défaut
INSERT INTO level_configs (level, xp_required, reward_usdc) VALUES
(1, 0, 0.00),
(2, 300, 2.00),
(3, 800, 5.00),
(4, 1500, 10.00),
(5, 2500, 15.00),
(6, 4000, 25.00),
(7, 6000, 40.00),
(8, 9000, 60.00),
(9, 13000, 100.00),
(10, 20000, 200.00);
```

### Avantages de MySQL pour le futur :
Pour connecter `index.php` à votre base de données MySQL :
1. Créez une connexion PDO à la base de données :
   ```php
   $pdo = new PDO("mysql:host=localhost;dbname=nom_bdd;charset=utf8", "utilisateur", "mot_de_passe");
   ```
2. Remplacez simplement les fonctions de chargement/sauvegarde JSON par des requêtes de sélection/insertion SQL préparées (ex: `SELECT * FROM users WHERE email = :email`).

Félicitations pour le choix de PHP pour l'hébergement partagé ! Votre application BonusX est désormais 100% universelle, légère et prête à être partagée avec le monde entier à moindre coût !
