<?php
/**
 * BonusX - Complete PHP Backend API Router
 * Highly secure, zero-dependency, and designed for shared hosting.
 * Fully compatible with the db-store.json schema and password hashes of server.ts.
 */

// 1. CORS headers to allow connection from React/Vite development server or separate hosting domains
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

// Stop early on preflight OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 2. Paths Configuration
$db_file = __DIR__ . '/db-store.json';
$sessions_file = __DIR__ . '/sessions.json';
$last_claims_file = __DIR__ . '/last-claims.json';

// Ensure files exist or seed
if (!file_exists($db_file)) {
    seedDatabase($db_file);
}
if (!file_exists($sessions_file)) {
    file_put_contents($sessions_file, json_encode([], JSON_PRETTY_PRINT));
}
if (!file_exists($last_claims_file)) {
    file_put_contents($last_claims_file, json_encode([], JSON_PRETTY_PRINT));
}

// 3. Database Helpers with File Locking
function loadDatabase($file) {
    $raw = file_get_contents($file);
    $data = json_decode($raw, true);
    if (!$data) {
        return seedDatabase($file);
    }
    return $data;
}

function saveDatabase($file, $db) {
    $raw = json_encode($db, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    file_put_contents($file, $raw, LOCK_EX);
}

function loadSessions($file) {
    if (!file_exists($file)) return [];
    $raw = file_get_contents($file);
    return json_decode($raw, true) ?: [];
}

function saveSessions($file, $sessions) {
    file_put_contents($file, json_encode($sessions, JSON_PRETTY_PRINT), LOCK_EX);
}

function loadLastClaims($file) {
    if (!file_exists($file)) return [];
    $raw = file_get_contents($file);
    return json_decode($raw, true) ?: [];
}

function saveLastClaims($file, $claims) {
    file_put_contents($file, json_encode($claims, JSON_PRETTY_PRINT), LOCK_EX);
}

// 4. Seeding Logic (identical to server.ts)
function seedDatabase($file) {
    $adminId = 'admin-1';
    $userId1 = 'user-alex';
    $userId2 = 'user-bob';
    $userId3 = 'user-alice';

    $hashPassword = function($password) {
        $hashSalt = 'BonusXPremiumPlatformSecretSalt2026';
        return hash('sha256', $password . $hashSalt);
    };

    $now = time();

    $initialUsers = [
        [
            'id' => $adminId,
            'email' => 'admin@bonusx.com',
            'username' => 'BonusXAdmin',
            'xp' => 0,
            'level' => 1,
            'usdcBalance' => 1000.0,
            'isBlocked' => false,
            'isAdmin' => true,
            'referralCode' => 'ADMINX',
            'createdAt' => date('c', $now - 30 * 24 * 3600)
        ],
        [
            'id' => $userId1,
            'email' => 'user@bonusx.com',
            'username' => 'AlexCrypto',
            'xp' => 1250,
            'level' => 3,
            'usdcBalance' => 78.5,
            'walletAddress' => '0x71C7656EC7ab88b098defB751B7401B5f6d1476B',
            'isBlocked' => false,
            'isAdmin' => false,
            'referralCode' => 'ALEX50',
            'createdAt' => date('c', $now - 15 * 24 * 3600)
        ],
        [
            'id' => $userId2,
            'email' => 'bob@bonusx.com',
            'username' => 'BobWeb3',
            'xp' => 450,
            'level' => 2,
            'usdcBalance' => 14.2,
            'walletAddress' => '0x8626f6940E2eb28930eFb4CeF49B2d1F2C9C1199',
            'isBlocked' => false,
            'isAdmin' => false,
            'referralCode' => 'BOB_OP',
            'referredBy' => 'ALEX50',
            'createdAt' => date('c', $now - 5 * 24 * 3600)
        ],
        [
            'id' => $userId3,
            'email' => 'alice@bonusx.com',
            'username' => 'AliceUSDC',
            'xp' => 150,
            'level' => 1,
            'usdcBalance' => 5.0,
            'isBlocked' => false,
            'isAdmin' => false,
            'referralCode' => 'ALICE_99',
            'referredBy' => 'ALEX50',
            'createdAt' => date('c', $now - 2 * 24 * 3600)
        ]
    ];

    $initialPasswords = [
        $adminId => $hashPassword('admin123'),
        $userId1 => $hashPassword('user123'),
        $userId2 => $hashPassword('bob123'),
        $userId3 => $hashPassword('alice123')
    ];

    $initialMissions = [
        [
            'id' => 'm-twitter',
            'title' => 'Suivre BonusX sur X (Twitter)',
            'description' => 'Abonne-toi à notre compte officiel @BonusX_Crypto pour recevoir les dernières mises à jour du projet et de la plateforme.',
            'rewardUsdc' => 1.50,
            'rewardXp' => 100,
            'category' => 'social',
            'actionUrl' => 'https://x.com/BonusX_Crypto',
            'isActive' => true,
            'createdAt' => date('c', $now - 10 * 24 * 3600)
        ],
        [
            'id' => 'm-telegram',
            'title' => 'Rejoindre notre canal Telegram',
            'description' => 'Rejoins le groupe Telegram officiel de BonusX pour échanger avec la communauté et participer aux airdrops exclusifs.',
            'rewardUsdc' => 2.00,
            'rewardXp' => 150,
            'category' => 'social',
            'actionUrl' => 'https://t.me/BonusX_Crypto',
            'isActive' => true,
            'createdAt' => date('c', $now - 10 * 24 * 3600)
        ],
        [
            'id' => 'm-video',
            'title' => 'Regarder le guide "Introduction au Web3 et USDC"',
            'description' => 'Regarde la vidéo de 3 minutes expliquant le fonctionnement du dollar numérique USDC et comment configurer ton premier portefeuille crypto.',
            'rewardUsdc' => 3.50,
            'rewardXp' => 250,
            'category' => 'video',
            'actionUrl' => 'https://youtube.com',
            'isActive' => true,
            'createdAt' => date('c', $now - 9 * 24 * 3600)
        ],
        [
            'id' => 'm-quiz',
            'title' => 'Compléter le Quiz de Sécurité DeFi',
            'description' => 'Réponds à notre quiz de 5 questions sur la sécurité dans la finance décentralisée pour vérifier tes connaissances et éviter les arnaques.',
            'rewardUsdc' => 5.00,
            'rewardXp' => 300,
            'category' => 'quiz',
            'actionUrl' => '#quiz',
            'isActive' => true,
            'createdAt' => date('c', $now - 8 * 24 * 3600)
        ],
        [
            'id' => 'm-crypto',
            'title' => 'Effectuer un premier transfert de test',
            'description' => 'Soumets l\'adresse d\'un portefeuille crypto EVM pour prouver ton autonomie en crypto et débloquer un bonus premium.',
            'rewardUsdc' => 10.00,
            'rewardXp' => 500,
            'category' => 'crypto',
            'actionUrl' => '#wallet',
            'isActive' => true,
            'createdAt' => date('c', $now - 5 * 24 * 3600)
        ]
    ];

    $initialUserMissions = [
        [
            'id' => 'um-1',
            'userId' => $userId1,
            'missionId' => 'm-twitter',
            'proofText' => '@AlexCrypto_X - Abonnés à 14h02',
            'status' => 'approved',
            'submittedAt' => date('c', $now - 12 * 24 * 3600),
            'processedAt' => date('c', $now - 11 * 24 * 3600),
            'adminComment' => 'Compte vérifié avec succès.'
        ],
        [
            'id' => 'um-2',
            'userId' => $userId1,
            'missionId' => 'm-telegram',
            'proofText' => 'Telegram ID: t.me/alex_web3',
            'status' => 'approved',
            'submittedAt' => date('c', $now - 12 * 24 * 3600),
            'processedAt' => date('c', $now - 11 * 24 * 3600),
            'adminComment' => 'Présence dans le canal validée.'
        ],
        [
            'id' => 'um-3',
            'userId' => $userId2,
            'missionId' => 'm-twitter',
            'proofText' => '@BobWeb3_Official',
            'status' => 'pending',
            'submittedAt' => date('c', $now - 1 * 24 * 3600)
        ],
        [
            'id' => 'um-4',
            'userId' => $userId3,
            'missionId' => 'm-telegram',
            'proofText' => 'AliceTelegramCrypto',
            'status' => 'rejected',
            'submittedAt' => date('c', $now - 2 * 24 * 3600),
            'processedAt' => date('c', $now - 1 * 24 * 3600),
            'adminComment' => 'Ce nom d\'utilisateur ne figure pas dans le groupe Telegram.'
        ]
    ];

    $initialWithdrawals = [
        [
            'id' => 'w-1',
            'userId' => $userId1,
            'amountUsdc' => 25.0,
            'walletAddress' => '0x71C7656EC7ab88b098defB751B7401B5f6d1476B',
            'status' => 'approved',
            'requestedAt' => date('c', $now - 8 * 24 * 3600),
            'processedAt' => date('c', $now - 7 * 24 * 3600)
        ],
        [
            'id' => 'w-2',
            'userId' => $userId1,
            'amountUsdc' => 15.0,
            'walletAddress' => '0x71C7656EC7ab88b098defB751B7401B5f6d1476B',
            'status' => 'pending',
            'requestedAt' => date('c', $now - 12 * 3600)
        ]
    ];

    $initialTransactions = [
        [
            'id' => 'tx-1',
            'userId' => $userId1,
            'amountUsdc' => 1.5,
            'type' => 'mission_reward',
            'description' => 'Mission validée : Suivre BonusX sur X (Twitter)',
            'createdAt' => date('c', $now - 11 * 24 * 3600)
        ],
        [
            'id' => 'tx-2',
            'userId' => $userId1,
            'amountUsdc' => 2.0,
            'type' => 'mission_reward',
            'description' => 'Mission validée : Rejoindre notre canal Telegram',
            'createdAt' => date('c', $now - 11 * 24 * 3600)
        ],
        [
            'id' => 'tx-3',
            'userId' => $userId1,
            'amountUsdc' => -25.0,
            'type' => 'withdrawal',
            'description' => 'Retrait USDC vers 0x71C7...476B',
            'createdAt' => date('c', $now - 8 * 24 * 3600)
        ],
        [
            'id' => 'tx-4',
            'userId' => $userId1,
            'amountUsdc' => 10.0,
            'type' => 'referral_bonus',
            'description' => 'Bonus parrainage : Inscription de BobWeb3',
            'createdAt' => date('c', $now - 5 * 24 * 3600)
        ],
        [
            'id' => 'tx-5',
            'userId' => $userId2,
            'amountUsdc' => 5.0,
            'type' => 'referral_bonus',
            'description' => 'Bonus de bienvenue parrainage (Parrainé par AlexCrypto)',
            'createdAt' => date('c', $now - 5 * 24 * 3600)
        ],
        [
            'id' => 'tx-6',
            'userId' => $userId1,
            'amountUsdc' => 5.0,
            'type' => 'referral_bonus',
            'description' => 'Bonus parrainage : Inscription de AliceUSDC',
            'createdAt' => date('c', $now - 2 * 24 * 3600)
        ]
    ];

    $initialNotifications = [
        [
            'id' => 'n-1',
            'userId' => $userId1,
            'title' => '🎉 Bienvenue sur BonusX !',
            'message' => 'Débute tes premières missions de réseaux sociaux pour débloquer tes premiers USDC.',
            'isRead' => true,
            'type' => 'success',
            'createdAt' => date('c', $now - 15 * 24 * 3600)
        ],
        [
            'id' => 'n-2',
            'userId' => $userId1,
            'title' => 'Missions validées !',
            'message' => 'L\'équipe a approuvé tes preuves pour Twitter et Telegram. Tu as reçu 3.50 USDC et +250 XP.',
            'isRead' => false,
            'type' => 'success',
            'createdAt' => date('c', $now - 11 * 24 * 3600)
        ],
        [
            'id' => 'n-3',
            'userId' => $userId1,
            'title' => 'Nouveau filleul actif',
            'message' => 'Félicitations, BobWeb3 s\'est inscrit avec ton code. Tu as reçu 10.00 USDC de bonus !',
            'isRead' => false,
            'type' => 'bonus_available',
            'createdAt' => date('c', $now - 5 * 24 * 3600)
        ],
        [
            'id' => 'n-4',
            'userId' => $userId3,
            'title' => 'Mission refusée',
            'message' => 'Ta preuve pour Telegram a été refusée car ton pseudo n\'a pas été trouvé dans notre canal.',
            'isRead' => false,
            'type' => 'alert',
            'createdAt' => date('c', $now - 1 * 24 * 3600)
        ]
    ];

    $defaultLevelConfigs = [
        ['level' => 1, 'xpRequired' => 0, 'rewardUsdc' => 0],
        ['level' => 2, 'xpRequired' => 300, 'rewardUsdc' => 2.0],
        ['level' => 3, 'xpRequired' => 800, 'rewardUsdc' => 5.0],
        ['level' => 4, 'xpRequired' => 1500, 'rewardUsdc' => 10.0],
        ['level' => 5, 'xpRequired' => 2500, 'rewardUsdc' => 15.0],
        ['level' => 6, 'xpRequired' => 4000, 'rewardUsdc' => 25.0],
        ['level' => 7, 'xpRequired' => 6000, 'rewardUsdc' => 40.0],
        ['level' => 8, 'xpRequired' => 9000, 'rewardUsdc' => 60.0],
        ['level' => 9, 'xpRequired' => 13000, 'rewardUsdc' => 100.0],
        ['level' => 10, 'xpRequired' => 20000, 'rewardUsdc' => 200.0]
    ];

    $db = [
        'users' => $initialUsers,
        'passwords' => $initialPasswords,
        'missions' => $initialMissions,
        'userMissions' => $initialUserMissions,
        'withdrawals' => $initialWithdrawals,
        'transactions' => $initialTransactions,
        'levelConfigs' => $defaultLevelConfigs,
        'notifications' => $initialNotifications
    ];

    saveDatabase($file, $db);
    return $db;
}

// 5. Shared Cryptography & Helper Functions
const HASH_SALT = 'BonusXPremiumPlatformSecretSalt2026';
function hashPassword($password) {
    return hash('sha256', $password . HASH_SALT);
}

function generateRandomHex($bytes) {
    return bin2hex(random_bytes($bytes));
}

function addXpToUser(&$db, &$user, $xpToAdd) {
    $oldLevel = $user['level'];
    $user['xp'] += $xpToAdd;
    
    $newLevel = $oldLevel;
    $rewardGiven = 0.0;
    
    $configs = $db['levelConfigs'];
    usort($configs, function($a, $b) {
        return $a['level'] - $b['level'];
    });
    
    foreach ($configs as $config) {
        if ($user['xp'] >= $config['xpRequired']) {
            $newLevel = max($newLevel, $config['level']);
        }
    }
    
    $leveledUp = false;
    if ($newLevel > $oldLevel) {
        $leveledUp = true;
        $user['level'] = $newLevel;
        
        for ($l = $oldLevel + 1; $l <= $newLevel; $l++) {
            foreach ($db['levelConfigs'] as $config) {
                if ($config['level'] === $l) {
                    $rewardGiven += (float)$config['rewardUsdc'];
                    break;
                }
            }
        }
        
        if ($rewardGiven > 0) {
            $user['usdcBalance'] += $rewardGiven;
            $db['transactions'][] = [
                'id' => 'tx-lvl-' . generateRandomHex(4),
                'userId' => $user['id'],
                'amountUsdc' => $rewardGiven,
                'type' => 'bonus_claim',
                'description' => "Récompense de passage au niveau $newLevel !",
                'createdAt' => date('c')
            ];
        }
        
        $db['notifications'][] = [
            'id' => 'notif-' . generateRandomHex(8),
            'userId' => $user['id'],
            'title' => "🏆 Niveau Supérieur : Niveau $newLevel !",
            'message' => "Félicitations, tu as atteint le niveau $newLevel ! Tu remportes un bonus de $rewardGiven USDC !",
            'isRead' => false,
            'type' => 'success',
            'createdAt' => date('c')
        ];
    }
    
    return [
        'leveledUp' => $leveledUp,
        'xpGranted' => $xpToAdd,
        'rewardGiven' => $rewardGiven
    ];
}

// 6. Routing and Endpoint Resolution
$route = isset($_GET['route']) ? $_GET['route'] : null;
if (!$route) {
    $requestUri = $_SERVER['REQUEST_URI'];
    if (strpos($requestUri, '?') !== false) {
        $requestUri = substr($requestUri, 0, strpos($requestUri, '?'));
    }
    
    $scriptName = $_SERVER['SCRIPT_NAME'];
    $scriptDir = dirname($scriptName);
    
    if ($scriptDir !== '/' && strpos($requestUri, $scriptDir) === 0) {
        $route = substr($requestUri, strlen($scriptDir));
    } else {
        $route = $requestUri;
    }
}

if ($route && $route[0] !== '/') {
    $route = '/' . $route;
}

// Fallback if URL rewrite doesn't run and they pass route as query
if (!$route) {
    $route = '/';
}

$method = $_SERVER['REQUEST_METHOD'];
$db = loadDatabase($db_file);
$input = json_decode(file_get_contents('php://input'), true) ?: [];

// Get auth headers
$headers = getallheaders();
$authHeader = null;
foreach ($headers as $key => $value) {
    if (strtolower($key) === 'authorization') {
        $authHeader = $value;
        break;
    }
}

// Authenticated session context variables
$currentUser = null;
$currentUserId = null;
$isAdmin = false;

// Middleware helper
function requireAuth() {
    global $authHeader, $db, $sessions_file, $currentUser, $currentUserId, $isAdmin;
    if (!$authHeader || strpos($authHeader, 'Session ') !== 0) {
        http_response_code(401);
        echo json_encode(['error' => 'Non autorisé. Veuillez vous connecter.']);
        exit();
    }
    
    $token = substr($authHeader, 8);
    $sessions = loadSessions($sessions_file);
    
    // Cleanup expired sessions
    $now = time() * 1000;
    $changed = false;
    foreach ($sessions as $t => $sess) {
        if ($sess['expiresAt'] < $now) {
            unset($sessions[$t]);
            $changed = true;
        }
    }
    if ($changed) {
        saveSessions($sessions_file, $sessions);
    }
    
    if (!isset($sessions[$token])) {
        http_response_code(401);
        echo json_encode(['error' => 'Session expirée ou invalide. Reconnectez-vous.']);
        exit();
    }
    
    $userId = $sessions[$token]['userId'];
    $userFound = null;
    foreach ($db['users'] as $u) {
        if ($u['id'] === $userId) {
            $userFound = $u;
            break;
        }
    }
    
    if (!$userFound) {
        http_response_code(401);
        echo json_encode(['error' => 'Utilisateur introuvable.']);
        exit();
    }
    
    if ($userFound['isBlocked']) {
        http_response_code(403);
        echo json_encode(['error' => 'Ce compte a été suspendu par l\'administrateur.']);
        exit();
    }
    
    $currentUser = $userFound;
    $currentUserId = $userId;
    $isAdmin = $userFound['isAdmin'];
}

function requireAdmin() {
    requireAuth();
    global $isAdmin;
    if (!$isAdmin) {
        http_response_code(403);
        echo json_encode(['error' => 'Accès interdit. Droits administrateur requis.']);
        exit();
    }
}

// Synchronize current user changes to database
function saveCurrentUser($user) {
    global $db, $db_file;
    foreach ($db['users'] as $key => $u) {
        if ($u['id'] === $user['id']) {
            $db['users'][$key] = $user;
            break;
        }
    }
    saveDatabase($db_file, $db);
}

// 7. Endpoint Definitions
switch (true) {
    // ----------------------------------------------------
    // AUTHENTICATION ENDPOINTS
    // ----------------------------------------------------
    case ($method === 'POST' && $route === '/api/auth/register'):
        $email = isset($input['email']) ? trim($input['email']) : '';
        $username = isset($input['username']) ? trim($input['username']) : '';
        $password = isset($input['password']) ? trim($input['password']) : '';
        $referralCode = isset($input['referralCode']) ? trim($input['referralCode']) : '';

        if (empty($email) || empty($username) || empty($password)) {
            http_response_code(400);
            echo json_encode(['error' => 'Tous les champs obligatoires (email, pseudo, mot de passe) doivent être remplis.']);
            exit();
        }

        foreach ($db['users'] as $u) {
            if (strtolower($u['email']) === strtolower($email)) {
                http_response_code(400);
                echo json_encode(['error' => 'Cette adresse email est déjà enregistrée.']);
                exit();
            }
            if (strtolower($u['username']) === strtolower($username)) {
                http_response_code(400);
                echo json_encode(['error' => 'Ce nom d\'utilisateur est déjà pris.']);
                exit();
            }
        }

        $newUserId = 'user-' . generateRandomHex(8);
        $userReferralCode = 'BX-' . strtoupper(substr($username, 0, 4)) . strtoupper(generateRandomHex(3));

        $referredByCode = null;
        $referralBonusGiven = false;

        if (!empty($referralCode)) {
            foreach ($db['users'] as $key => $u) {
                if (strtoupper($u['referralCode']) === strtoupper($referralCode) && !$u['isAdmin']) {
                    $referredByCode = $u['referralCode'];
                    // Give 10 USDC to referrer
                    $db['users'][$key]['usdcBalance'] += 10.0;

                    // Referral Transaction
                    $db['transactions'][] = [
                        'id' => 'tx-ref-' . generateRandomHex(4),
                        'userId' => $u['id'],
                        'amountUsdc' => 10.0,
                        'type' => 'referral_bonus',
                        'description' => "Bonus parrainage : Inscription de $username",
                        'createdAt' => date('c')
                    ];

                    // Referral Notification
                    $db['notifications'][] = [
                        'id' => 'notif-ref-' . generateRandomHex(8),
                        'userId' => $u['id'],
                        'title' => '👥 Nouveau parrainage actif !',
                        'message' => "Félicitations, $username a rejoint BonusX avec ton code. Tu as reçu 10.00 USDC de bonus.",
                        'isRead' => false,
                        'type' => 'bonus_available',
                        'createdAt' => date('c')
                    ];

                    $referralBonusGiven = true;
                    break;
                }
            }
        }

        $newUser = [
            'id' => $newUserId,
            'email' => strtolower($email),
            'username' => $username,
            'xp' => 0,
            'level' => 1,
            'usdcBalance' => $referralBonusGiven ? 5.0 : 0.0,
            'isBlocked' => false,
            'isAdmin' => false,
            'referralCode' => $userReferralCode,
            'referredBy' => $referredByCode,
            'createdAt' => date('c')
        ];

        $db['users'][] = $newUser;
        $db['passwords'][$newUserId] = hashPassword($password);

        if ($referralBonusGiven) {
            $db['transactions'][] = [
                'id' => 'tx-wel-' . generateRandomHex(4),
                'userId' => $newUserId,
                'amountUsdc' => 5.0,
                'type' => 'referral_bonus',
                'description' => 'Bonus de bienvenue parrainage',
                'createdAt' => date('c')
            ];
        }

        $db['notifications'][] = [
            'id' => 'notif-wel-' . generateRandomHex(8),
            'userId' => $newUserId,
            'title' => '🎉 Bienvenue sur BonusX !',
            'message' => "Merci de nous rejoindre. " . ($referralBonusGiven ? 'Ton bonus de 5.00 USDC a été crédité. ' : '') . "Découvre la liste des missions pour gagner tes premiers USDC !",
            'isRead' => false,
            'type' => 'success',
            'createdAt' => date('c')
        ];

        saveDatabase($db_file, $db);

        // Session creation
        $token = generateRandomHex(32);
        $sessions = loadSessions($sessions_file);
        $sessions[$token] = [
            'userId' => $newUserId,
            'isAdmin' => false,
            'expiresAt' => (time() + 24 * 3600) * 1000 // ms
        ];
        saveSessions($sessions_file, $sessions);

        echo json_encode([
            'token' => $token,
            'user' => $newUser
        ]);
        break;

    case ($method === 'POST' && $route === '/api/auth/login'):
        $email = isset($input['email']) ? trim($input['email']) : '';
        $password = isset($input['password']) ? trim($input['password']) : '';

        if (empty($email) || empty($password)) {
            http_response_code(400);
            echo json_encode(['error' => 'Veuillez saisir votre adresse email et votre mot de passe.']);
            exit();
        }

        $user = null;
        foreach ($db['users'] as $u) {
            if (strtolower($u['email']) === strtolower($email)) {
                $user = $u;
                break;
            }
        }

        if (!$user) {
            http_response_code(401);
            echo json_encode(['error' => 'Identifiants invalides.']);
            exit();
        }

        $hash = hashPassword($password);
        if (!isset($db['passwords'][$user['id']]) || $db['passwords'][$user['id']] !== $hash) {
            http_response_code(401);
            echo json_encode(['error' => 'Identifiants invalides.']);
            exit();
        }

        if ($user['isBlocked']) {
            http_response_code(403);
            echo json_encode(['error' => 'Ce compte a été bloqué par un administrateur.']);
            exit();
        }

        $token = generateRandomHex(32);
        $sessions = loadSessions($sessions_file);
        $sessions[$token] = [
            'userId' => $user['id'],
            'isAdmin' => $user['isAdmin'],
            'expiresAt' => (time() + 24 * 3600) * 1000
        ];
        saveSessions($sessions_file, $sessions);

        echo json_encode([
            'token' => $token,
            'user' => $user
        ]);
        break;

    case ($method === 'GET' && $route === '/api/auth/me'):
        requireAuth();
        echo json_encode(['user' => $currentUser]);
        break;

    // ----------------------------------------------------
    // USER SETTINGS & WALLET
    // ----------------------------------------------------
    case ($method === 'POST' && $route === '/api/user/update-wallet'):
        requireAuth();
        $walletAddress = isset($input['walletAddress']) ? trim($input['walletAddress']) : '';

        if (!empty($walletAddress) && strpos($walletAddress, '0x') !== 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Format de portefeuille invalide. Doit commencer par 0x (Réseau EVM / Polygon).']);
            exit();
        }

        $currentUser['walletAddress'] = !empty($walletAddress) ? $walletAddress : null;
        saveCurrentUser($currentUser);

        echo json_encode(['success' => true, 'user' => $currentUser]);
        break;

    case ($method === 'POST' && $route === '/api/user/update-settings'):
        requireAuth();
        $username = isset($input['username']) ? trim($input['username']) : '';
        $password = isset($input['password']) ? trim($input['password']) : '';

        if (!empty($username) && strlen($username) >= 3) {
            foreach ($db['users'] as $u) {
                if (strtolower($u['username']) === strtolower($username) && $u['id'] !== $currentUserId) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Ce pseudo est déjà utilisé.']);
                    exit();
                }
            }
            $currentUser['username'] = $username;
        }

        if (!empty($password) && strlen($password) >= 6) {
            $db['passwords'][$currentUserId] = hashPassword($password);
        }

        saveCurrentUser($currentUser);
        echo json_encode(['success' => true, 'user' => $currentUser]);
        break;

    // ----------------------------------------------------
    // DAILY CLAIM BONUS
    // ----------------------------------------------------
    case ($method === 'POST' && $route === '/api/user/claim-daily'):
        requireAuth();
        $claims = loadLastClaims($last_claims_file);
        $now = time() * 1000; // ms
        $COOLDOWN = 12 * 3600 * 1000; // 12 hours in ms

        $lastClaim = isset($claims[$currentUserId]) ? $claims[$currentUserId] : 0;
        if ($now - $lastClaim < $COOLDOWN) {
            $remainingMs = $COOLDOWN - ($now - $lastClaim);
            $hours = floor($remainingMs / (3600 * 1000));
            $minutes = floor(($remainingMs % (3600 * 1000)) / (60 * 1000));

            http_response_code(429);
            echo json_encode(['error' => "Tu as déjà réclamé ton bonus récemment. Reviens dans {$hours}h {$minutes}m."]);
            exit();
        }

        // Random USDC bonus between 0.25 and 1.50
        $bonusUsdc = round(0.25 + (mt_rand() / mt_getrandmax()) * 1.25, 2);
        $xpReward = 20;

        $currentUser['usdcBalance'] += $bonusUsdc;
        $xpResults = addXpToUser($db, $currentUser, $xpReward);

        $claims[$currentUserId] = $now;
        saveLastClaims($last_claims_file, $claims);

        // Daily Transaction
        $db['transactions'][] = [
            'id' => 'tx-daily-' . generateRandomHex(4),
            'userId' => $currentUserId,
            'amountUsdc' => $bonusUsdc,
            'type' => 'bonus_claim',
            'description' => 'Bonus quotidien réclamé avec succès !',
            'createdAt' => date('c')
        ];

        // Daily Notification
        $db['notifications'][] = [
            'id' => 'notif-daily-' . generateRandomHex(8),
            'userId' => $currentUserId,
            'title' => '🎁 Bonus Quotidien Réclamé !',
            'message' => "Félicitations, tu as gagné {$bonusUsdc} USDC et +{$xpReward} XP.",
            'isRead' => false,
            'type' => 'success',
            'createdAt' => date('c')
        ];

        saveCurrentUser($currentUser);

        echo json_encode([
            'success' => true,
            'bonusUsdc' => $bonusUsdc,
            'xpReward' => $xpReward,
            'leveledUp' => $xpResults['leveledUp'],
            'levelUpReward' => $xpResults['rewardGiven'],
            'user' => $currentUser
        ]);
        break;

    // ----------------------------------------------------
    // MISSIONS ENDPOINTS
    // ----------------------------------------------------
    case ($method === 'GET' && $route === '/api/missions'):
        requireAuth();
        $activeMissions = [];
        foreach ($db['missions'] as $m) {
            if ($m['isActive']) {
                $activeMissions[] = $m;
            }
        }
        echo json_encode(['missions' => $activeMissions]);
        break;

    case ($method === 'POST' && $route === '/api/missions/submit'):
        requireAuth();
        $missionId = isset($input['missionId']) ? $input['missionId'] : '';
        $proofText = isset($input['proofText']) ? trim($input['proofText']) : '';

        if (empty($missionId) || empty($proofText)) {
            http_response_code(400);
            echo json_encode(['error' => 'La preuve ou l\'ID de mission est manquant.']);
            exit();
        }

        $mission = null;
        foreach ($db['missions'] as $m) {
            if ($m['id'] === $missionId && $m['isActive']) {
                $mission = $m;
                break;
            }
        }

        if (!$mission) {
            http_response_code(404);
            echo json_encode(['error' => 'Mission introuvable ou inactive.']);
            exit();
        }

        // Check if already submitted and pending/approved
        $existingIndex = -1;
        $existing = null;
        foreach ($db['userMissions'] as $idx => $um) {
            if ($um['userId'] === $currentUserId && $um['missionId'] === $missionId) {
                $existing = $um;
                $existingIndex = $idx;
                break;
            }
        }

        if ($existing) {
            if ($existing['status'] === 'pending') {
                http_response_code(400);
                echo json_encode(['error' => 'Tu as déjà soumis une preuve pour cette mission. Elle est en cours de validation.']);
                exit();
            }
            if ($existing['status'] === 'approved') {
                http_response_code(400);
                echo json_encode(['error' => 'Tu as déjà accompli cette mission avec succès.']);
                exit();
            }
        }

        $userMissionId = 'um-' . generateRandomHex(8);
        $submission = [
            'id' => $userMissionId,
            'userId' => $currentUserId,
            'missionId' => $missionId,
            'proofText' => $proofText,
            'status' => 'pending',
            'submittedAt' => date('c')
        ];

        if ($existingIndex !== -1 && $existing['status'] === 'rejected') {
            // Overwrite rejected one
            $db['userMissions'][$existingIndex] = $submission;
        } else {
            $db['userMissions'][] = $submission;
        }

        saveDatabase($db_file, $db);
        echo json_encode(['success' => true, 'submission' => $submission]);
        break;

    case ($method === 'GET' && $route === '/api/user/my-missions'):
        requireAuth();
        $myMissions = [];
        foreach ($db['userMissions'] as $um) {
            if ($um['userId'] === $currentUserId) {
                $myMissions[] = $um;
            }
        }
        echo json_encode(['submissions' => $myMissions]);
        break;

    // ----------------------------------------------------
    // USER TRANSACTION HISTORY
    // ----------------------------------------------------
    case ($method === 'GET' && $route === '/api/user/my-bonus'):
        requireAuth();
        $myBonus = [];
        foreach ($db['transactions'] as $tx) {
            if ($tx['userId'] === $currentUserId && $tx['type'] !== 'withdrawal') {
                $myBonus[] = $tx;
            }
        }
        echo json_encode(['bonuses' => $myBonus]);
        break;

    // ----------------------------------------------------
    // WITHDRAWALS ENDPOINTS
    // ----------------------------------------------------
    case ($method === 'GET' && $route === '/api/user/my-withdrawals'):
        requireAuth();
        $myWithdrawals = [];
        foreach ($db['withdrawals'] as $w) {
            if ($w['userId'] === $currentUserId) {
                $myWithdrawals[] = $w;
            }
        }
        echo json_encode(['withdrawals' => $myWithdrawals]);
        break;

    case ($method === 'POST' && $route === '/api/user/request-withdrawal'):
        requireAuth();
        $amountUsdc = isset($input['amountUsdc']) ? (float)$input['amountUsdc'] : 0.0;
        $walletAddress = isset($input['walletAddress']) ? trim($input['walletAddress']) : '';

        if ($amountUsdc <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Le montant de retrait doit être supérieur à zéro.']);
            exit();
        }

        if ($amountUsdc > $currentUser['usdcBalance']) {
            http_response_code(400);
            echo json_encode(['error' => 'Solde insuffisant pour ce retrait.']);
            exit();
        }

        if (empty($walletAddress) || strpos($walletAddress, '0x') !== 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Adresse de portefeuille EVM (Polygon) invalide.']);
            exit();
        }

        $withdrawalId = 'w-' . generateRandomHex(8);
        $withdrawal = [
            'id' => $withdrawalId,
            'userId' => $currentUserId,
            'amountUsdc' => $amountUsdc,
            'walletAddress' => $walletAddress,
            'status' => 'pending',
            'requestedAt' => date('c')
        ];

        // Deduct from balance immediately to lock it
        $currentUser['usdcBalance'] -= $amountUsdc;

        $db['withdrawals'][] = $withdrawal;

        // Log transaction
        $db['transactions'][] = [
            'id' => 'tx-w-' . generateRandomHex(4),
            'userId' => $currentUserId,
            'amountUsdc' => -$amountUsdc,
            'type' => 'withdrawal',
            'description' => "Demande de retrait USDC initiée vers " . substr($walletAddress, 0, 6) . "..." . substr($walletAddress, -4),
            'createdAt' => date('c')
        ];

        // Create notification
        $db['notifications'][] = [
            'id' => 'notif-w-' . generateRandomHex(8),
            'userId' => $currentUserId,
            'title' => '📤 Demande de Retrait Reçue',
            'message' => "Ta demande de retrait de $amountUsdc USDC est en cours d'examen par notre équipe.",
            'isRead' => false,
            'type' => 'info',
            'createdAt' => date('c')
        ];

        saveCurrentUser($currentUser);

        echo json_encode(['success' => true, 'withdrawal' => $withdrawal, 'user' => $currentUser]);
        break;

    // ----------------------------------------------------
    // LEADERBOARD ENDPOINT
    // ----------------------------------------------------
    case ($method === 'GET' && $route === '/api/leaderboard'):
        $leaderboard = [];
        foreach ($db['users'] as $u) {
            if (!$u['isAdmin']) {
                $leaderboard[] = [
                    'id' => $u['id'],
                    'username' => $u['username'],
                    'level' => $u['level'],
                    'xp' => $u['xp'],
                    'usdcBalance' => $u['usdcBalance']
                ];
            }
        }

        // Sort descending by XP
        usort($leaderboard, function($a, $b) {
            return $b['xp'] - $a['xp'];
        });

        echo json_encode(['leaderboard' => $leaderboard]);
        break;

    // ----------------------------------------------------
    // REFERRALS ENDPOINTS
    // ----------------------------------------------------
    case ($method === 'GET' && $route === '/api/user/referrals'):
        requireAuth();
        $referredUsers = [];
        $referralsCount = 0;

        foreach ($db['users'] as $u) {
            if ($u['referredBy'] === $currentUser['referralCode']) {
                $referredUsers[] = [
                    'username' => $u['username'],
                    'level' => $u['level'],
                    'joinedAt' => $u['createdAt'],
                    'earnedForReferrer' => 10.0
                ];
                $referralsCount++;
            }
        }

        $totalEarnedUsdc = $referralsCount * 10.0;

        echo json_encode([
            'referralCode' => $currentUser['referralCode'],
            'referralsCount' => $referralsCount,
            'totalEarnedUsdc' => $totalEarnedUsdc,
            'referredUsers' => $referredUsers
        ]);
        break;

    // ----------------------------------------------------
    // NOTIFICATIONS
    // ----------------------------------------------------
    case ($method === 'GET' && $route === '/api/user/notifications'):
        requireAuth();
        $myNotifications = [];
        foreach ($db['notifications'] as $n) {
            if ($n['userId'] === $currentUserId) {
                $myNotifications[] = $n;
            }
        }
        echo json_encode(['notifications' => $myNotifications]);
        break;

    case ($method === 'POST' && $route === '/api/user/notifications/read'):
        requireAuth();
        $changed = false;
        foreach ($db['notifications'] as $key => $n) {
            if ($n['userId'] === $currentUserId && !$n['isRead']) {
                $db['notifications'][$key]['isRead'] = true;
                $changed = true;
            }
        }
        if ($changed) {
            saveDatabase($db_file, $db);
        }
        echo json_encode(['success' => true]);
        break;


    // ====================================================
    // ADMINISTRATOR EXCLUSIVE ENDPOINTS
    // ====================================================

    // Admin Stats
    case ($method === 'GET' && $route === '/api/admin/stats'):
        requireAdmin();
        $totalUsers = 0;
        $blockedUsers = 0;
        $pendingWithdrawalsCount = 0;
        $approvedWithdrawalsAmount = 0.0;
        $pendingSubmissionsCount = 0;
        $totalMissions = count($db['missions']);
        $activeMissions = 0;
        $totalRewardsDistributed = 0.0;

        foreach ($db['users'] as $u) {
            if (!$u['isAdmin']) {
                $totalUsers++;
                if ($u['isBlocked']) {
                    $blockedUsers++;
                }
            }
        }

        foreach ($db['withdrawals'] as $w) {
            if ($w['status'] === 'pending') {
                $pendingWithdrawalsCount++;
            } else if ($w['status'] === 'approved') {
                $approvedWithdrawalsAmount += (float)$w['amountUsdc'];
            }
        }

        foreach ($db['userMissions'] as $um) {
            if ($um['status'] === 'pending') {
                $pendingSubmissionsCount++;
            }
        }

        foreach ($db['missions'] as $m) {
            if ($m['isActive']) {
                $activeMissions++;
            }
        }

        foreach ($db['transactions'] as $tx) {
            if ($tx['amountUsdc'] > 0 && $tx['type'] !== 'withdrawal') {
                $totalRewardsDistributed += (float)$tx['amountUsdc'];
            }
        }

        echo json_encode([
            'totalUsers' => $totalUsers,
            'blockedUsers' => $blockedUsers,
            'pendingWithdrawalsCount' => $pendingWithdrawalsCount,
            'approvedWithdrawalsAmount' => $approvedWithdrawalsAmount,
            'pendingSubmissionsCount' => $pendingSubmissionsCount,
            'totalMissions' => $totalMissions,
            'activeMissions' => $activeMissions,
            'totalRewardsDistributed' => $totalRewardsDistributed
        ]);
        break;

    // Admin Users List
    case ($method === 'GET' && $route === '/api/admin/users'):
        requireAdmin();
        $allUsers = [];
        foreach ($db['users'] as $u) {
            if (!$u['isAdmin']) {
                $allUsers[] = $u;
            }
        }
        echo json_encode(['users' => $allUsers]);
        break;

    // Admin User Adjustment (XP / USDC)
    case ($method === 'POST' && preg_match('#^/api/admin/users/([^/]+)/adjust$#', $route, $matches)):
        requireAdmin();
        $targetUserId = $matches[1];
        $xpAmount = isset($input['xpAmount']) ? (int)$input['xpAmount'] : 0;
        $usdcAmount = isset($input['usdcAmount']) ? (float)$input['usdcAmount'] : 0.0;
        $comment = isset($input['comment']) ? trim($input['comment']) : '';

        $targetUserIdx = -1;
        foreach ($db['users'] as $idx => $u) {
            if ($u['id'] === $targetUserId) {
                $targetUserIdx = $idx;
                break;
            }
        }

        if ($targetUserIdx === -1) {
            http_response_code(404);
            echo json_encode(['error' => 'Utilisateur introuvable.']);
            exit();
        }

        if ($xpAmount !== 0) {
            addXpToUser($db, $db['users'][$targetUserIdx], $xpAmount);
        }

        if ($usdcAmount !== 0) {
            $db['users'][$targetUserIdx]['usdcBalance'] += $usdcAmount;
            
            // Transaction log
            $db['transactions'][] = [
                'id' => 'tx-adj-' . generateRandomHex(4),
                'userId' => $targetUserId,
                'amountUsdc' => $usdcAmount,
                'type' => 'admin_adjustment',
                'description' => "Ajustement administratif : " . ($usdcAmount > 0 ? '+' : '') . "{$usdcAmount} USDC. " . $comment,
                'createdAt' => date('c')
            ];
        }

        // Notification log
        $db['notifications'][] = [
            'id' => 'notif-adj-' . generateRandomHex(8),
            'userId' => $targetUserId,
            'title' => '⚙️ Ajustement de compte',
            'message' => "L'équipe administrative a ajusté ton compte : " . ($xpAmount !== 0 ? (($xpAmount > 0 ? '+' : '') . "{$xpAmount} XP ") : '') . ($usdcAmount !== 0 ? (($usdcAmount > 0 ? '+' : '') . "{$usdcAmount} USDC ") : '') . (!empty($comment) ? ". Motif : {$comment}" : ''),
            'isRead' => false,
            'type' => 'info',
            'createdAt' => date('c')
        ];

        saveDatabase($db_file, $db);
        echo json_encode(['success' => true, 'user' => $db['users'][$targetUserIdx]]);
        break;

    // Admin Toggle Block User
    case ($method === 'POST' && preg_match('#^/api/admin/users/([^/]+)/toggle-block$#', $route, $matches)):
        requireAdmin();
        $targetUserId = $matches[1];

        $targetUserIdx = -1;
        foreach ($db['users'] as $idx => $u) {
            if ($u['id'] === $targetUserId) {
                $targetUserIdx = $idx;
                break;
            }
        }

        if ($targetUserIdx === -1) {
            http_response_code(404);
            echo json_encode(['error' => 'Utilisateur introuvable.']);
            exit();
        }

        if ($db['users'][$targetUserIdx]['isAdmin']) {
            http_response_code(400);
            echo json_encode(['error' => 'Action impossible sur un compte administrateur.']);
            exit();
        }

        $db['users'][$targetUserIdx]['isBlocked'] = !$db['users'][$targetUserIdx]['isBlocked'];
        saveDatabase($db_file, $db);

        echo json_encode(['success' => true, 'isBlocked' => $db['users'][$targetUserIdx]['isBlocked']]);
        break;

    // Admin CRUD Missions
    case ($method === 'GET' && $route === '/api/admin/missions'):
        requireAdmin();
        echo json_encode(['missions' => $db['missions']]);
        break;

    case ($method === 'POST' && $route === '/api/admin/missions'):
        requireAdmin();
        $title = isset($input['title']) ? trim($input['title']) : '';
        $description = isset($input['description']) ? trim($input['description']) : '';
        $rewardUsdc = isset($input['rewardUsdc']) ? (float)$input['rewardUsdc'] : 0.0;
        $rewardXp = isset($input['rewardXp']) ? (int)$input['rewardXp'] : 0;
        $category = isset($input['category']) ? trim($input['category']) : '';
        $actionUrl = isset($input['actionUrl']) ? trim($input['actionUrl']) : '#';
        $isActive = isset($input['isActive']) ? (bool)$input['isActive'] : true;

        if (empty($title) || empty($description) || empty($category)) {
            http_response_code(400);
            echo json_encode(['error' => 'Veuillez renseigner tous les champs obligatoires de la mission.']);
            exit();
        }

        $newMission = [
            'id' => 'm-' . generateRandomHex(6),
            'title' => $title,
            'description' => $description,
            'rewardUsdc' => $rewardUsdc,
            'rewardXp' => $rewardXp,
            'category' => $category,
            'actionUrl' => $actionUrl,
            'isActive' => $isActive,
            'createdAt' => date('c')
        ];

        $db['missions'][] = $newMission;
        saveDatabase($db_file, $db);

        http_response_code(201);
        echo json_encode(['success' => true, 'mission' => $newMission]);
        break;

    case ($method === 'PUT' && preg_match('#^/api/admin/missions/([^/]+)$#', $route, $matches)):
        requireAdmin();
        $missionId = $matches[1];

        $missionIdx = -1;
        foreach ($db['missions'] as $idx => $m) {
            if ($m['id'] === $missionId) {
                $missionIdx = $idx;
                break;
            }
        }

        if ($missionIdx === -1) {
            http_response_code(404);
            echo json_encode(['error' => 'Mission introuvable.']);
            exit();
        }

        $m = $db['missions'][$missionIdx];
        $db['missions'][$missionIdx] = [
            'id' => $m['id'],
            'title' => isset($input['title']) ? trim($input['title']) : $m['title'],
            'description' => isset($input['description']) ? trim($input['description']) : $m['description'],
            'rewardUsdc' => isset($input['rewardUsdc']) ? (float)$input['rewardUsdc'] : $m['rewardUsdc'],
            'rewardXp' => isset($input['rewardXp']) ? (int)$input['rewardXp'] : $m['rewardXp'],
            'category' => isset($input['category']) ? trim($input['category']) : $m['category'],
            'actionUrl' => isset($input['actionUrl']) ? trim($input['actionUrl']) : $m['actionUrl'],
            'isActive' => isset($input['isActive']) ? (bool)$input['isActive'] : $m['isActive'],
            'createdAt' => $m['createdAt']
        ];

        saveDatabase($db_file, $db);
        echo json_encode(['success' => true, 'mission' => $db['missions'][$missionIdx]]);
        break;

    case ($method === 'DELETE' && preg_match('#^/api/admin/missions/([^/]+)$#', $route, $matches)):
        requireAdmin();
        $missionId = $matches[1];

        $initialCount = count($db['missions']);
        $db['missions'] = array_values(array_filter($db['missions'], function($m) use ($missionId) {
            return $m['id'] !== $missionId;
        }));

        if (count($db['missions']) === $initialCount) {
            http_response_code(404);
            echo json_encode(['error' => 'Mission introuvable.']);
            exit();
        }

        saveDatabase($db_file, $db);
        echo json_encode(['success' => true]);
        break;

    // Admin Task Submissions Verification List
    case ($method === 'GET' && $route === '/api/admin/submissions'):
        requireAdmin();
        $richSubmissions = [];

        foreach ($db['userMissions'] as $um) {
            $userFound = null;
            foreach ($db['users'] as $u) {
                if ($u['id'] === $um['userId']) {
                    $userFound = ['username' => $u['username'], 'email' => $u['email']];
                    break;
                }
            }

            $missionFound = null;
            foreach ($db['missions'] as $m) {
                if ($m['id'] === $um['missionId']) {
                    $missionFound = ['title' => $m['title'], 'rewardUsdc' => $m['rewardUsdc'], 'rewardXp' => $m['rewardXp']];
                    break;
                }
            }

            $richSubmissions[] = array_merge($um, [
                'user' => $userFound,
                'mission' => $missionFound
            ]);
        }

        echo json_encode(['submissions' => $richSubmissions]);
        break;

    // Admin Process Submission (Approve / Reject)
    case ($method === 'POST' && preg_match('#^/api/admin/submissions/([^/]+)/process$#', $route, $matches)):
        requireAdmin();
        $submissionId = $matches[1];
        $action = isset($input['action']) ? trim($input['action']) : '';
        $adminComment = isset($input['adminComment']) ? trim($input['adminComment']) : '';

        if ($action !== 'approve' && $action !== 'reject') {
            http_response_code(400);
            echo json_encode(['error' => 'Action invalide. Doit être approve ou reject.']);
            exit();
        }

        $subIdx = -1;
        foreach ($db['userMissions'] as $idx => $um) {
            if ($um['id'] === $submissionId) {
                $subIdx = $idx;
                break;
            }
        }

        if ($subIdx === -1) {
            http_response_code(404);
            echo json_encode(['error' => 'Preuve de tâche introuvable.']);
            exit();
        }

        if ($db['userMissions'][$subIdx]['status'] !== 'pending') {
            http_response_code(400);
            echo json_encode(['error' => 'Cette preuve a déjà été traitée.']);
            exit();
        }

        $userId = $db['userMissions'][$subIdx]['userId'];
        $missionId = $db['userMissions'][$subIdx]['missionId'];

        $userKey = -1;
        foreach ($db['users'] as $key => $u) {
            if ($u['id'] === $userId) {
                $userKey = $key;
                break;
            }
        }

        $missionFound = null;
        foreach ($db['missions'] as $m) {
            if ($m['id'] === $missionId) {
                $missionFound = $m;
                break;
            }
        }

        if ($userKey === -1 || !$missionFound) {
            http_response_code(404);
            echo json_encode(['error' => 'L\'utilisateur ou la mission associée est introuvable.']);
            exit();
        }

        if ($action === 'approve') {
            $db['userMissions'][$subIdx]['status'] = 'approved';
            $db['userMissions'][$subIdx]['processedAt'] = date('c');
            $db['userMissions'][$subIdx]['adminComment'] = !empty($adminComment) ? $adminComment : 'Preuve approuvée avec succès !';

            // Credit user reward
            $db['users'][$userKey]['usdcBalance'] += (float)$missionFound['rewardUsdc'];
            $xpResults = addXpToUser($db, $db['users'][$userKey], (int)$missionFound['rewardXp']);

            // Reward Transaction log
            $db['transactions'][] = [
                'id' => 'tx-approve-' . generateRandomHex(4),
                'userId' => $userId,
                'amountUsdc' => (float)$missionFound['rewardUsdc'],
                'type' => 'mission_reward',
                'description' => "Validation mission : " . $missionFound['title'],
                'createdAt' => date('c')
            ];

            // Reward Notification
            $db['notifications'][] = [
                'id' => 'notif-appr-' . generateRandomHex(8),
                'userId' => $userId,
                'title' => '✅ Mission validée !',
                'message' => "Félicitations, ta preuve pour \"{$missionFound['title']}\" a été acceptée. Tu as reçu {$missionFound['rewardUsdc']} USDC et +{$missionFound['rewardXp']} XP !",
                'isRead' => false,
                'type' => 'success',
                'createdAt' => date('c')
            ];
        } else {
            $db['userMissions'][$subIdx]['status'] = 'rejected';
            $db['userMissions'][$subIdx]['processedAt'] = date('c');
            $db['userMissions'][$subIdx]['adminComment'] = !empty($adminComment) ? $adminComment : 'Preuve refusée. Veuillez vérifier les détails demandés.';

            // Rejection Notification
            $db['notifications'][] = [
                'id' => 'notif-rejc-' . generateRandomHex(8),
                'userId' => $userId,
                'title' => '❌ Mission refusée',
                'message' => "Ta preuve pour la mission \"{$missionFound['title']}\" a été refusée par l'administrateur. Raison : " . $db['userMissions'][$subIdx]['adminComment'],
                'isRead' => false,
                'type' => 'alert',
                'createdAt' => date('c')
            ];
        }

        saveDatabase($db_file, $db);
        echo json_encode(['success' => true, 'submission' => $db['userMissions'][$subIdx]]);
        break;

    // Admin Withdrawals List
    case ($method === 'GET' && $route === '/api/admin/withdrawals'):
        requireAdmin();
        $richWithdrawals = [];
        foreach ($db['withdrawals'] as $w) {
            $userFound = null;
            foreach ($db['users'] as $u) {
                if ($u['id'] === $w['userId']) {
                    $userFound = ['username' => $u['username'], 'email' => $u['email']];
                    break;
                }
            }
            $richWithdrawals[] = array_merge($w, ['user' => $userFound]);
        }
        echo json_encode(['withdrawals' => $richWithdrawals]);
        break;

    // Admin Process Withdrawal Request (Approve / Reject)
    case ($method === 'POST' && preg_match('#^/api/admin/withdrawals/([^/]+)/process$#', $route, $matches)):
        requireAdmin();
        $withdrawalId = $matches[1];
        $action = isset($input['action']) ? trim($input['action']) : '';

        $wIdx = -1;
        foreach ($db['withdrawals'] as $idx => $w) {
            if ($w['id'] === $withdrawalId) {
                $wIdx = $idx;
                break;
            }
        }

        if ($wIdx === -1) {
            http_response_code(404);
            echo json_encode(['error' => 'Demande de retrait introuvable.']);
            exit();
        }

        if ($db['withdrawals'][$wIdx]['status'] !== 'pending') {
            http_response_code(400);
            echo json_encode(['error' => 'Cette demande de retrait a déjà été traitée.']);
            exit();
        }

        $userId = $db['withdrawals'][$wIdx]['userId'];
        $userKey = -1;
        foreach ($db['users'] as $key => $u) {
            if ($u['id'] === $userId) {
                $userKey = $key;
                break;
            }
        }

        if ($userKey === -1) {
            http_response_code(404);
            echo json_encode(['error' => 'Utilisateur associé introuvable.']);
            exit();
        }

        if ($action === 'approve') {
            $db['withdrawals'][$wIdx]['status'] = 'approved';
            $db['withdrawals'][$wIdx]['processedAt'] = date('c');

            // Success Notification
            $address = $db['withdrawals'][$wIdx]['walletAddress'];
            $shortAddr = substr($address, 0, 6) . '...' . substr($address, -4);
            $db['notifications'][] = [
                'id' => 'notif-wappr-' . generateRandomHex(8),
                'userId' => $userId,
                'title' => '💸 Retrait traité avec succès !',
                'message' => "Ton retrait de {$db['withdrawals'][$wIdx]['amountUsdc']} USDC a été validé et envoyé vers ton portefeuille $shortAddr.",
                'isRead' => false,
                'type' => 'success',
                'createdAt' => date('c')
            ];
        } else {
            $db['withdrawals'][$wIdx]['status'] = 'rejected';
            $db['withdrawals'][$wIdx]['processedAt'] = date('c');

            // Refund locked funds back to user
            $db['users'][$userKey]['usdcBalance'] += (float)$db['withdrawals'][$wIdx]['amountUsdc'];

            // Refund transaction log
            $db['transactions'][] = [
                'id' => 'tx-wref-' . generateRandomHex(4),
                'userId' => $userId,
                'amountUsdc' => (float)$db['withdrawals'][$wIdx]['amountUsdc'],
                'type' => 'admin_adjustment',
                'description' => "Remboursement de retrait refusé (ID: {$withdrawalId})",
                'createdAt' => date('c')
            ];

            // Refuse Notification
            $db['notifications'][] = [
                'id' => 'notif-wrejc-' . generateRandomHex(8),
                'userId' => $userId,
                'title' => '❌ Retrait refusé',
                'message' => "Ta demande de retrait de {$db['withdrawals'][$wIdx]['amountUsdc']} USDC a été refusée. Le montant a été recrédité sur ton solde disponible.",
                'isRead' => false,
                'type' => 'alert',
                'createdAt' => date('c')
            ];
        }

        saveDatabase($db_file, $db);
        echo json_encode(['success' => true, 'withdrawal' => $db['withdrawals'][$wIdx]]);
        break;

    // Admin Transactions Log
    case ($method === 'GET' && $route === '/api/admin/transactions'):
        requireAdmin();
        $richTransactions = [];
        foreach ($db['transactions'] as $tx) {
            $userFound = null;
            foreach ($db['users'] as $u) {
                if ($u['id'] === $tx['userId']) {
                    $userFound = ['username' => $u['username'], 'email' => $u['email']];
                    break;
                }
            }
            $richTransactions[] = array_merge($tx, ['user' => $userFound]);
        }

        // Sort by date descending
        usort($richTransactions, function($a, $b) {
            return strcmp($b['createdAt'], $a['createdAt']);
        });

        echo json_encode(['transactions' => $richTransactions]);
        break;

    // Admin Level Configurations List
    case ($method === 'GET' && $route === '/api/admin/levels'):
        requireAdmin();
        echo json_encode(['levels' => $db['levelConfigs']]);
        break;

    // Admin Set Level Configuration
    case ($method === 'POST' && $route === '/api/admin/levels'):
        requireAdmin();
        $level = isset($input['level']) ? (int)$input['level'] : null;
        $xpRequired = isset($input['xpRequired']) ? (int)$input['xpRequired'] : null;
        $rewardUsdc = isset($input['rewardUsdc']) ? (float)$input['rewardUsdc'] : null;

        if ($level === null || $xpRequired === null || $rewardUsdc === null) {
            http_response_code(400);
            echo json_encode(['error' => 'Veuillez saisir le niveau, l\'XP requise, et la récompense USDC.']);
            exit();
        }

        $existingIdx = -1;
        foreach ($db['levelConfigs'] as $idx => $l) {
            if ((int)$l['level'] === $level) {
                $existingIdx = $idx;
                break;
            }
        }

        $config = [
            'level' => $level,
            'xpRequired' => $xpRequired,
            'rewardUsdc' => $rewardUsdc
        ];

        if ($existingIdx !== -1) {
            $db['levelConfigs'][$existingIdx] = $config;
        } else {
            $db['levelConfigs'][] = $config;
        }

        // Sort ascending
        usort($db['levelConfigs'], function($a, $b) {
            return $a['level'] - $b['level'];
        });

        saveDatabase($db_file, $db);
        echo json_encode(['success' => true, 'levels' => $db['levelConfigs']]);
        break;

    // 404 Route Not Found
    default:
        http_response_code(404);
        echo json_encode(['error' => "Route non trouvée: {$method} {$route}"]);
        break;
}
